#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Human Behavior Simulator Module
---------------------------------
このモジュールは人間らしい操作パターンをシミュレートする機能を提供します。
ランダムな待機時間、タイピングスピードの変動、ミスの発生などを再現し、
自動操作を人間らしく見せるための機能を実装しています。
"""

import time
import random
import logging

# ロガーの設定
logger = logging.getLogger(__name__)

class HumanBehaviorSimulator:
    """人間らしい行動をシミュレートするクラス"""
    
    def __init__(self, config=None):
        """
        初期化メソッド
        
        Args:
            config: 行動シミュレーションの設定情報を含む辞書（オプション）
        """
        self.config = config or {}
        
        # デフォルト設定
        self.typing_speed = self.config.get('typing_speed', {
            'min': 0.05,  # 最小タイピング間隔（秒）
            'max': 0.15   # 最大タイピング間隔（秒）
        })
        
        self.mistake_probability = self.config.get('mistake_probability', 0.02)  # ミス発生確率
        self.correction_delay = self.config.get('correction_delay', {
            'min': 0.2,   # ミス修正までの最小待機時間（秒）
            'max': 0.5    # ミス修正までの最大待機時間（秒）
        })
        
        self.move_speed = self.config.get('move_speed', {
            'min': 0.5,   # 最小移動速度（秒）
            'max': 1.5    # 最大移動速度（秒）
        })
        
        self.decision_time = self.config.get('decision_time', {
            'min': 0.5,   # 最小判断時間（秒）
            'max': 2.0    # 最大判断時間（秒）
        })
        
        self.behavior_profile = self.config.get('behavior_profile', 'normal')
        
        # 行動プロファイルに基づく設定調整
        self._adjust_settings_by_profile()
        
        logger.info("人間行動シミュレーターが初期化されました")
    
    def _adjust_settings_by_profile(self):
        """行動プロファイルに基づいて設定を調整する"""
        if self.behavior_profile == 'careful':
            # 慎重なプロファイル: タイピングが遅く、ミスが少なく、判断に時間がかかる
            self.typing_speed['min'] *= 1.5
            self.typing_speed['max'] *= 1.5
            self.mistake_probability *= 0.5
            self.decision_time['min'] *= 1.5
            self.decision_time['max'] *= 1.5
            
        elif self.behavior_profile == 'hasty':
            # 急いでいるプロファイル: タイピングが速く、ミスが多く、判断が早い
            self.typing_speed['min'] *= 0.7
            self.typing_speed['max'] *= 0.7
            self.mistake_probability *= 1.5
            self.decision_time['min'] *= 0.7
            self.decision_time['max'] *= 0.7
            
        elif self.behavior_profile == 'expert':
            # 熟練者プロファイル: タイピングが速く、ミスが少なく、判断が早い
            self.typing_speed['min'] *= 0.7
            self.typing_speed['max'] *= 0.7
            self.mistake_probability *= 0.3
            self.decision_time['min'] *= 0.7
            self.decision_time['max'] *= 0.7
            
        elif self.behavior_profile == 'novice':
            # 初心者プロファイル: タイピングが遅く、ミスが多く、判断に時間がかかる
            self.typing_speed['min'] *= 1.5
            self.typing_speed['max'] *= 1.5
            self.mistake_probability *= 2.0
            self.decision_time['min'] *= 1.5
            self.decision_time['max'] *= 1.5
    
    def random_wait(self, min_time=None, max_time=None):
        """
        人間らしいランダムな待機時間を再現する
        
        Args:
            min_time: 最小待機時間（秒）、指定がなければデフォルト値を使用
            max_time: 最大待機時間（秒）、指定がなければデフォルト値を使用
        """
        min_time = min_time if min_time is not None else self.decision_time['min']
        max_time = max_time if max_time is not None else self.decision_time['max']
        
        wait_time = random.uniform(min_time, max_time)
        time.sleep(wait_time)
        return wait_time
    
    def human_type(self, element, text):
        """
        人間らしいタイピングをシミュレートする
        
        Args:
            element: テキストを入力するウェブ要素
            text: 入力するテキスト
        """
        for char in text:
            # ミスの発生をシミュレート
            if random.random() < self.mistake_probability:
                # ランダムな誤字を入力
                wrong_char = chr(ord(char) + random.randint(-2, 2))
                element.send_keys(wrong_char)
                
                # 少し待ってから修正
                time.sleep(random.uniform(
                    self.correction_delay['min'], 
                    self.correction_delay['max']
                ))
                
                # バックスペースで削除
                element.send_keys('\b')
            
            # 正しい文字を入力
            element.send_keys(char)
            
            # 人間らしいタイピング間隔
            time.sleep(random.uniform(
                self.typing_speed['min'], 
                self.typing_speed['max']
            ))
    
    def human_click(self, element):
        """
        人間らしいクリック操作をシミュレートする
        
        Args:
            element: クリックするウェブ要素
        """
        # クリック前に少し待機（判断時間）
        self.random_wait(
            self.decision_time['min'] * 0.5, 
            self.decision_time['max'] * 0.5
        )
        
        # クリック実行
        element.click()
        
        # クリック後に少し待機
        self.random_wait(0.1, 0.3)
    
    def get_random_analysis_time(self, complexity=1.0):
        """
        情報分析にかかる人間らしい時間を計算する
        
        Args:
            complexity: 情報の複雑さ（1.0が標準）
            
        Returns:
            float: 分析時間（秒）
        """
        base_time = random.uniform(2.0, 5.0)
        return base_time * complexity
    
    def simulate_distraction(self, probability=0.05, max_time=3.0):
        """
        人間の注意散漫をシミュレートする
        
        Args:
            probability: 注意散漫が発生する確率
            max_time: 最大の注意散漫時間（秒）
            
        Returns:
            bool: 注意散漫が発生したかどうか
        """
        if random.random() < probability:
            distraction_time = random.uniform(0.5, max_time)
            logger.debug(f"注意散漫をシミュレート: {distraction_time:.2f}秒")
            time.sleep(distraction_time)
            return True
        return False
    
    def change_behavior_profile(self, profile):
        """
        行動プロファイルを変更する
        
        Args:
            profile: 新しい行動プロファイル名
            
        Returns:
            bool: 変更が成功したかどうか
        """
        valid_profiles = ['normal', 'careful', 'hasty', 'expert', 'novice']
        
        if profile not in valid_profiles:
            logger.error(f"無効な行動プロファイル: {profile}")
            return False
            
        self.behavior_profile = profile
        self._adjust_settings_by_profile()
        logger.info(f"行動プロファイルを変更しました: {profile}")
        return True
    
    def get_current_profile(self):
        """
        現在の行動プロファイルを取得する
        
        Returns:
            str: 現在の行動プロファイル名
        """
        return self.behavior_profile
