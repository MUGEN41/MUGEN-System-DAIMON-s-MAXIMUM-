#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System (DAIMON's MAXIMUM) - 日次取引管理モジュール
日次利益の計算と上限管理、取引回数の管理、日付リセット機能を提供するモジュール
"""

import os
import sys
import json
import time
import logging
import datetime as dt
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("trade_management.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Trade_Management")

class DailyTradeManager:
    """
    日次取引管理クラス
    日次利益の計算と上限管理、取引回数の管理、日付リセット機能を提供する
    """
    
    def __init__(self, config_path: str = "config/trade_rules_config.json"):
        """
        初期化
        
        Args:
            config_path: 設定ファイルのパス
        """
        self.config_path = Path(config_path)
        self.config_dir = self.config_path.parent
        self.config: Dict[str, Any] = {}
        self.daily_stats: Dict[str, Any] = {
            "date": dt.datetime.now().strftime("%Y-%m-%d"),
            "total_trades": 0,
            "total_profit": 0.0,
            "account_balance": 100000.0,  # 初期残高
            "trade_history": []
        }
        self._ensure_config_dir()
        self._load_config()
        self._load_daily_stats()
    
    def _ensure_config_dir(self) -> None:
        """設定ディレクトリが存在することを確認"""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)
            logger.info(f"設定ディレクトリを作成しました: {self.config_dir}")
    
    def _load_config(self) -> None:
        """設定ファイルを読み込む"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info("取引ルール設定を読み込みました")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
                self.config = {}
        else:
            logger.info("設定ファイルが存在しないため、新規作成します")
            # 初期設定
            self.config = {
                "daily_profit_cap": 600000.0,  # 日次利益上限（円）
                "daily_trade_limit": 100,  # 日次取引回数上限
                "trade_size_percentage": 0.01,  # 取引サイズ（口座残高の割合）
                "amount_rounding": 10,  # 金額の丸め単位（10円単位）
                "enable_martingale": True,  # マーチンゲール戦略の有効化
                "martingale_factor": 2.0,  # マーチンゲール倍率
                "max_martingale_level": 3,  # 最大マーチンゲールレベル
                "profit_target_percentage": 0.8,  # 利益目標（取引サイズの割合）
                "stop_loss_percentage": 1.0,  # 損切り（取引サイズの割合）
                "last_updated": dt.datetime.now().isoformat()
            }
            self._save_config()
    
    def _save_config(self) -> None:
        """設定ファイルを保存する"""
        try:
            # 更新日時を記録
            self.config["last_updated"] = dt.datetime.now().isoformat()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("取引ルール設定を保存しました")
        except Exception as e:
            logger.error(f"設定ファイルの保存に失敗しました: {e}")
    
    def _load_daily_stats(self) -> None:
        """日次統計情報を読み込む"""
        stats_path = self.config_dir / "daily_stats.json"
        
        if stats_path.exists():
            try:
                with open(stats_path, 'r', encoding='utf-8') as f:
                    saved_stats = json.load(f)
                
                # 日付が同じ場合のみ読み込む
                if saved_stats["date"] == dt.datetime.now().strftime("%Y-%m-%d"):
                    self.daily_stats = saved_stats
                    logger.info(f"今日の統計情報を読み込みました: 取引数 {self.daily_stats['total_trades']}, 利益 {self.daily_stats['total_profit']}")
                else:
                    logger.info("日付が変わったため、統計情報をリセットします")
                    # 口座残高のみ引き継ぐ
                    self.daily_stats["account_balance"] = saved_stats["account_balance"]
                    self._save_daily_stats()
            except Exception as e:
                logger.error(f"日次統計情報の読み込みに失敗しました: {e}")
        else:
            logger.info("日次統計情報が存在しないため、新規作成します")
            self._save_daily_stats()
    
    def _save_daily_stats(self) -> None:
        """日次統計情報を保存する"""
        try:
            stats_path = self.config_dir / "daily_stats.json"
            
            with open(stats_path, 'w', encoding='utf-8') as f:
                json.dump(self.daily_stats, f, indent=4, ensure_ascii=False)
            logger.info("日次統計情報を保存しました")
        except Exception as e:
            logger.error(f"日次統計情報の保存に失敗しました: {e}")
    
    def reset_daily_stats(self) -> None:
        """日次統計情報をリセットする"""
        account_balance = self.daily_stats["account_balance"]
        
        self.daily_stats = {
            "date": dt.datetime.now().strftime("%Y-%m-%d"),
            "total_trades": 0,
            "total_profit": 0.0,
            "account_balance": account_balance,
            "trade_history": []
        }
        
        self._save_daily_stats()
        logger.info("日次統計情報をリセットしました")
    
    def check_daily_reset(self) -> bool:
        """
        日付が変わったかどうかを確認し、必要に応じて統計情報をリセットする
        
        Returns:
            bool: リセットが行われたかどうか
        """
        current_date = dt.datetime.now().strftime("%Y-%m-%d")
        
        if current_date != self.daily_stats["date"]:
            logger.info(f"日付が変わりました: {self.daily_stats['date']} -> {current_date}")
            self.reset_daily_stats()
            return True
        
        return False
    
    def can_trade_today(self) -> bool:
        """
        今日まだ取引可能かどうかを確認する
        
        Returns:
            bool: 取引可能かどうか
        """
        # 日付が変わっていないか確認
        self.check_daily_reset()
        
        # 日次取引回数上限に達していないか確認
        daily_trade_limit = self.config.get("daily_trade_limit", 100)
        if self.daily_stats["total_trades"] >= daily_trade_limit:
            logger.info(f"日次取引回数上限に達しました: {self.daily_stats['total_trades']} >= {daily_trade_limit}")
            return False
        
        # 日次利益上限に達していないか確認
        daily_profit_cap = self.config.get("daily_profit_cap", 600000.0)
        if self.daily_stats["total_profit"] >= daily_profit_cap:
            logger.info(f"日次利益上限に達しました: {self.daily_stats['total_profit']} >= {daily_profit_cap}")
            return False
        
        return True
    
    def calculate_trade_size(self) -> float:
        """
        取引サイズを計算する
        
        Returns:
            float: 取引サイズ（円）
        """
        trade_size_percentage = self.config.get("trade_size_percentage", 0.01)
        amount_rounding = self.config.get("amount_rounding", 10)
        
        # 口座残高の一定割合を取引サイズとする
        trade_size = self.daily_stats["account_balance"] * trade_size_percentage
        
        # 指定された単位で四捨五入
        trade_size = round(trade_size / amount_rounding) * amount_rounding
        
        return max(amount_rounding, trade_size)  # 最小取引サイズは丸め単位と同じ
    
    def calculate_martingale_size(self, base_size: float, level: int) -> float:
        """
        マーチンゲール戦略に基づく取引サイズを計算する
        
        Args:
            base_size: 基本取引サイズ
            level: マーチンゲールレベル
        
        Returns:
            float: マーチンゲール調整後の取引サイズ
        """
        if not self.config.get("enable_martingale", True) or level <= 0:
            return base_size
        
        martingale_factor = self.config.get("martingale_factor", 2.0)
        max_level = self.config.get("max_martingale_level", 3)
        amount_rounding = self.config.get("amount_rounding", 10)
        
        # レベルを制限
        level = min(level, max_level)
        
        # マーチンゲール倍率を適用
        martingale_size = base_size * (martingale_factor ** level)
        
        # 指定された単位で四捨五入
        martingale_size = round(martingale_size / amount_rounding) * amount_rounding
        
        # 口座残高の10%を超えないようにする
        max_size = self.daily_stats["account_balance"] * 0.1
        martingale_size = min(martingale_size, max_size)
        
        return max(amount_rounding, martingale_size)  # 最小取引サイズは丸め単位と同じ
    
    def format_amount(self, amount: float) -> float:
        """
        金額を指定された単位で四捨五入する
        
        Args:
            amount: 金額
        
        Returns:
            float: 四捨五入された金額
        """
        amount_rounding = self.config.get("amount_rounding", 10)
        return round(amount / amount_rounding) * amount_rounding
    
    def record_trade(self, profit: float, timestamp: dt.datetime = None) -> None:
        """
        取引を記録する
        
        Args:
            profit: 利益（負の場合は損失）
            timestamp: タイムスタンプ（指定しない場合は現在時刻）
        """
        if timestamp is None:
            timestamp = dt.datetime.now()
        
        # 日付が変わっていないか確認
        self.check_daily_reset()
        
        # 金額を整形
        profit = self.format_amount(profit)
        
        # 口座残高を更新
        self.daily_stats["account_balance"] += profit
        
        # 取引記録
        trade_record = {
            "timestamp": timestamp.isoformat(),
            "profit": profit,
            "account_balance": self.daily_stats["account_balance"]
        }
        
        self.daily_stats["trade_history"].append(trade_record)
        self.daily_stats["total_trades"] += 1
        self.daily_stats["total_profit"] += profit
        
        logger.info(f"取引を記録しました: 利益 {profit}, 残高 {self.daily_stats['account_balance']}, 今日の取引数 {self.daily_stats['total_trades']}, 今日の利益 {self.daily_stats['total_profit']}")
        
        # 統計情報を保存
        self._save_daily_stats()
    
    def get_daily_stats(self) -> Dict[str, Any]:
        """
        日次統計情報を取得する
        
        Returns:
            Dict[str, Any]: 日次統計情報
        """
        # 日付が変わっていないか確認
        self.check_daily_reset()
        
        return self.daily_stats
    
    def get_remaining_trades(self) -> int:
        """
        残りの取引可能回数を取得する
        
        Returns:
            int: 残りの取引可能回数
        """
        # 日付が変わっていないか確認
        self.check_daily_reset()
        
        daily_trade_limit = self.config.get("daily_trade_limit", 100)
        return max(0, daily_trade_limit - self.daily_stats["total_trades"])
    
    def get_remaining_profit_cap(self) -> float:
        """
        残りの利益上限を取得する
        
        Returns:
            float: 残りの利益上限
        """
        # 日付が変わっていないか確認
        self.check_daily_reset()
        
        daily_profit_cap = self.config.get("daily_profit_cap", 600000.0)
        return max(0.0, daily_profit_cap - self.daily_stats["total_profit"])
    
    def update_account_balance(self, new_balance: float) -> None:
        """
        口座残高を更新する
        
        Args:
            new_balance: 新しい口座残高
        """
        old_balance = self.daily_stats["account_balance"]
        self.daily_stats["account_balance"] = new_balance
        
        logger.info(f"口座残高を更新しました: {old_balance} -> {new_balance}")
        
        # 統計情報を保存
        self._save_daily_stats()
    
    def get_trade_summary(self) -> Dict[str, Any]:
        """
        取引サマリーを取得する
        
        Returns:
            Dict[str, Any]: 取引サマリー
        """
        # 日付が変わっていないか確認
        self.check_daily_reset()
        
        return {
            "date": self.daily_stats["date"],
            "total_trades": self.daily_stats["total_trades"],
            "total_profit": self.daily_stats["total_profit"],
            "account_balance": self.daily_stats["account_balance"],
            "remaining_trades": self.get_remaining_trades(),
            "remaining_profit_cap": self.get_remaining_profit_cap(),
            "can_trade_today": self.can_trade_today()
        }
