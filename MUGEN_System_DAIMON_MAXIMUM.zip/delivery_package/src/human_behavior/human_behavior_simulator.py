#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System (DAIMON's MAXIMUM) - 人間行動シミュレーションモジュール
人間らしい行動パターン・感情・ミスを再現し、検知を回避するモジュール
"""

import os
import sys
import json
import time
import random
import logging
import numpy as np
import datetime as dt
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("human_behavior.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Human_Behavior_Simulator")

class HumanBehaviorSimulator:
    """
    人間行動シミュレーションクラス
    人間らしい行動パターン・感情・ミスを再現し、検知を回避する
    """
    
    def __init__(self, config_path: str = "config/behavior_config.json"):
        """
        初期化
        
        Args:
            config_path: 設定ファイルのパス
        """
        self.config_path = Path(config_path)
        self.config_dir = self.config_path.parent
        self.config: Dict[str, Any] = {}
        self.behavior_profiles: List[Dict[str, Any]] = []
        self.current_profile: Dict[str, Any] = {}
        self.current_state: Dict[str, Any] = {
            "emotional_state": "neutral",  # neutral, excited, cautious, frustrated
            "focus_level": 0.8,  # 0.0-1.0
            "fatigue_level": 0.0,  # 0.0-1.0
            "session_start_time": dt.datetime.now(),
            "last_activity_time": dt.datetime.now(),
            "activity_history": [],
            "error_probability": 0.01,  # 1%の確率でミスを発生
            "trade_history": [],
            "consecutive_wins": 0,
            "consecutive_losses": 0,
        }
        self._ensure_config_dir()
        self._load_config()
        self._load_behavior_profiles()
        self._select_initial_profile()
    
    def _ensure_config_dir(self) -> None:
        """設定ディレクトリが存在することを確認"""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)
            logger.info(f"設定ディレクトリを作成しました: {self.config_dir}")
    
    def _load_config(self) -> None:
        """設定ファイルを読み込む"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info("行動シミュレーション設定を読み込みました")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
                self.config = {}
        else:
            logger.info("設定ファイルが存在しないため、新規作成します")
            # 初期設定
            self.config = {
                "enabled": True,
                "behavior_settings": {
                    "activity_pattern": {
                        "enabled": True,
                        "working_hours_variation": True,
                        "break_simulation": True,
                        "day_of_week_patterns": True
                    },
                    "emotional_simulation": {
                        "enabled": True,
                        "loss_reaction": True,
                        "win_streak_confidence": True,
                        "market_event_caution": True
                    },
                    "error_simulation": {
                        "enabled": True,
                        "misclick_simulation": True,
                        "correction_behavior": True,
                        "typo_simulation": True
                    },
                    "network_simulation": {
                        "enabled": True,
                        "latency_variation": True,
                        "connection_instability": True,
                        "bandwidth_patterns": True
                    }
                },
                "profile_variation": {
                    "enabled": True,
                    "gradual_changes": True,
                    "personality_consistency": True
                },
                "last_updated": dt.datetime.now().isoformat()
            }
            self._save_config()
    
    def _save_config(self) -> None:
        """設定ファイルを保存する"""
        try:
            # 更新日時を記録
            self.config["last_updated"] = dt.datetime.now().isoformat()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("行動シミュレーション設定を保存しました")
        except Exception as e:
            logger.error(f"設定ファイルの保存に失敗しました: {e}")
    
    def _load_behavior_profiles(self) -> None:
        """行動プロファイルを読み込む"""
        profiles_path = self.config_dir / "behavior_profiles.json"
        
        if profiles_path.exists():
            try:
                with open(profiles_path, 'r', encoding='utf-8') as f:
                    self.behavior_profiles = json.load(f)
                logger.info(f"{len(self.behavior_profiles)}個の行動プロファイルを読み込みました")
            except Exception as e:
                logger.error(f"行動プロファイルの読み込みに失敗しました: {e}")
                self._generate_behavior_profiles()
        else:
            logger.info("行動プロファイルが存在しないため、新規生成します")
            self._generate_behavior_profiles()
    
    def _generate_behavior_profiles(self) -> None:
        """行動プロファイルを生成する"""
        # 性格タイプ
        personality_types = [
            "cautious",  # 慎重型
            "aggressive",  # 積極型
            "analytical",  # 分析型
            "emotional",  # 感情型
            "balanced"  # バランス型
        ]
        
        # 取引スタイル
        trading_styles = [
            "day_trader",  # デイトレーダー
            "swing_trader",  # スイングトレーダー
            "scalper",  # スキャルパー
            "position_trader",  # ポジショントレーダー
            "mixed"  # 混合型
        ]
        
        # 活動時間帯
        activity_periods = [
            {"name": "morning_person", "peak_hours": [9, 10, 11, 12]},
            {"name": "afternoon_person", "peak_hours": [13, 14, 15, 16]},
            {"name": "evening_person", "peak_hours": [17, 18, 19, 20]},
            {"name": "night_owl", "peak_hours": [21, 22, 23, 0]},
            {"name": "all_day", "peak_hours": [9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]}
        ]
        
        # 曜日パターン
        weekday_patterns = [
            {"name": "weekday_active", "active_days": [0, 1, 2, 3, 4]},  # 平日活発
            {"name": "weekend_active", "active_days": [5, 6]},  # 週末活発
            {"name": "all_week", "active_days": [0, 1, 2, 3, 4, 5, 6]},  # 一週間活発
            {"name": "midweek_focus", "active_days": [1, 2, 3]},  # 週の中日に集中
            {"name": "random_days", "active_days": random.sample(range(7), random.randint(3, 5))}  # ランダムな日
        ]
        
        # エラー率
        error_rates = [0.005, 0.01, 0.015, 0.02, 0.025]
        
        # 集中力持続時間（分）
        focus_durations = [30, 45, 60, 90, 120]
        
        # 休憩パターン
        break_patterns = [
            {"name": "frequent_short", "frequency": 20, "duration": 5},  # 20分ごとに5分休憩
            {"name": "moderate", "frequency": 45, "duration": 10},  # 45分ごとに10分休憩
            {"name": "long_sessions", "frequency": 90, "duration": 15},  # 90分ごとに15分休憩
            {"name": "irregular", "frequency": "variable", "min_freq": 15, "max_freq": 60, "min_dur": 3, "max_dur": 15}  # 不規則
        ]
        
        # 感情反応パターン
        emotional_patterns = [
            {"name": "stable", "loss_reaction": 0.2, "win_excitement": 0.2},  # 安定型
            {"name": "volatile", "loss_reaction": 0.8, "win_excitement": 0.8},  # 変動型
            {"name": "loss_sensitive", "loss_reaction": 0.9, "win_excitement": 0.3},  # 損失敏感型
            {"name": "win_excited", "loss_reaction": 0.3, "win_excitement": 0.9},  # 勝利興奮型
            {"name": "moderate", "loss_reaction": 0.5, "win_excitement": 0.5}  # 中庸型
        ]
        
        # プロファイル生成
        self.behavior_profiles = []
        for i in range(10):  # 10個のプロファイルを生成
            personality = random.choice(personality_types)
            trading_style = random.choice(trading_styles)
            activity_period = random.choice(activity_periods)
            weekday_pattern = random.choice(weekday_patterns)
            error_rate = random.choice(error_rates)
            focus_duration = random.choice(focus_durations)
            break_pattern = random.choice(break_patterns)
            emotional_pattern = random.choice(emotional_patterns)
            
            # 性格に基づいて一部パラメータを調整
            if personality == "cautious":
                error_rate *= 0.7  # 慎重なので誤操作が少ない
                if trading_style == "scalper":
                    trading_style = "day_trader"  # 慎重な人はスキャルピングを避ける傾向
            elif personality == "aggressive":
                if trading_style == "position_trader":
                    trading_style = "scalper"  # 積極的な人はスキャルピングを好む傾向
                if emotional_pattern["name"] == "stable":
                    emotional_pattern = next(p for p in emotional_patterns if p["name"] == "volatile")
            elif personality == "analytical":
                focus_duration *= 1.3  # 分析型は集中力が長い
                if break_pattern["name"] == "frequent_short":
                    break_pattern = next(p for p in break_patterns if p["name"] == "long_sessions")
            elif personality == "emotional":
                if emotional_pattern["name"] == "stable":
                    emotional_pattern = next(p for p in emotional_patterns if p["name"] in ["volatile", "loss_sensitive", "win_excited"])
            
            profile = {
                "id": f"profile_{i}",
                "name": f"Profile {i+1}",
                "personality": personality,
                "trading_style": trading_style,
                "activity_period": activity_period,
                "weekday_pattern": weekday_pattern,
                "error_rate": error_rate,
                "focus_duration": focus_duration,
                "break_pattern": break_pattern,
                "emotional_pattern": emotional_pattern,
                "typing_speed": random.randint(30, 100),  # 1分あたりの単語数
                "decision_speed": random.uniform(0.5, 3.0),  # 決断までの平均秒数
                "mouse_movement_style": random.choice(["direct", "curved", "hesitant", "precise"]),
                "created_at": dt.datetime.now().isoformat(),
            }
            self.behavior_profiles.append(profile)
        
        # プロファイルを保存
        profiles_path = self.config_dir / "behavior_profiles.json"
        try:
            with open(profiles_path, 'w', encoding='utf-8') as f:
                json.dump(self.behavior_profiles, f, indent=4, ensure_ascii=False)
            logger.info(f"{len(self.behavior_profiles)}個の行動プロファイルを生成・保存しました")
        except Exception as e:
            logger.error(f"行動プロファイルの保存に失敗しました: {e}")
    
    def _select_initial_profile(self) -> None:
        """初期プロファイルを選択する"""
        if not self.behavior_profiles:
            logger.error("行動プロファイルが存在しません")
            return
        
        # ランダムにプロファイルを選択
        self.current_profile = random.choice(self.behavior_profiles)
        logger.info(f"初期プロファイルを選択しました: {self.current_profile['id']} ({self.current_profile['personality']} {self.current_profile['trading_style']})")
    
    def update_state(self) -> bool:
        """
        現在の状態を更新する
        時間経過、取引結果などに基づいて感情や疲労度を更新
        
        Returns:
            bool: 休憩が必要かどうか
        """
        now = dt.datetime.now()
        time_since_last_activity = (now - dt.datetime.fromisoformat(self.current_state["last_activity_time"].isoformat())).total_seconds() / 60  # 分単位
        
        # 疲労度の更新
        session_duration = (now - dt.datetime.fromisoformat(self.current_state["session_start_time"].isoformat())).total_seconds() / 60  # 分単位
        focus_duration = self.current_profile["focus_duration"]
        
        # 集中力の持続時間を超えると疲労度が上昇
        if session_duration > focus_duration:
            fatigue_increase = 0.05 * (time_since_last_activity / 10)  # 10分ごとに5%疲労度上昇
            self.current_state["fatigue_level"] = min(1.0, self.current_state["fatigue_level"] + fatigue_increase)
        
        # 休憩が必要かどうかを判断
        break_needed = self._check_if_break_needed()
        
        # 感情状態の更新
        self._update_emotional_state()
        
        # エラー確率の更新
        self._update_error_probability()
        
        # 最終活動時間を更新
        self.current_state["last_activity_time"] = now
        
        logger.info(f"状態を更新しました: 感情={self.current_state['emotional_state']}, 疲労度={self.current_state['fatigue_level']:.2f}, エラー確率={self.current_state['error_probability']:.3f}")
        
        return break_needed
    
    def _check_if_break_needed(self) -> bool:
        """
        休憩が必要かどうかを判断する
        
        Returns:
            bool: 休憩が必要かどうか
        """
        if not self.config.get("behavior_settings", {}).get("activity_pattern", {}).get("break_simulation", True):
            return False
        
        now = dt.datetime.now()
        session_duration = (now - dt.datetime.fromisoformat(self.current_state["session_start_time"].isoformat())).total_seconds() / 60  # 分単位
        
        break_pattern = self.current_profile["break_pattern"]
        
        if break_pattern["name"] == "irregular":
            # 不規則な休憩パターン
            if random.random() < 0.1:  # 10%の確率でランダムに休憩
                return True
            
            # 疲労度が高い場合も休憩
            if self.current_state["fatigue_level"] > 0.7:
                return True
            
            return False
        else:
            # 規則的な休憩パターン
            frequency = break_pattern["frequency"]
            
            # 指定された頻度で休憩
            if session_duration % frequency < 1:  # 1分以内の誤差を許容
                return True
            
            # 疲労度が高い場合も休憩
            if self.current_state["fatigue_level"] > 0.8:
                return True
            
            return False
    
    def _update_emotional_state(self) -> None:
        """感情状態を更新する"""
        if not self.config.get("behavior_settings", {}).get("emotional_simulation", {}).get("enabled", True):
            return
        
        # 取引履歴から感情状態を更新
        if self.current_state["trade_history"]:
            # 最新の取引結果
            recent_trades = self.current_state["trade_history"][-5:]  # 直近5件
            wins = sum(1 for t in recent_trades if t["result"] == "win")
            losses = len(recent_trades) - wins
            
            emotional_pattern = self.current_profile["emotional_pattern"]
            loss_reaction = emotional_pattern["loss_reaction"]
            win_excitement = emotional_pattern["win_excitement"]
            
            # 連勝・連敗状態の確認
            if self.current_state["consecutive_wins"] >= 3:
                # 3連勝以上で興奮状態
                if random.random() < win_excitement:
                    self.current_state["emotional_state"] = "excited"
                    logger.info(f"{self.current_state['consecutive_wins']}連勝により興奮状態になりました")
            elif self.current_state["consecutive_losses"] >= 2:
                # 2連敗以上でフラストレーション状態
                if random.random() < loss_reaction:
                    self.current_state["emotional_state"] = "frustrated"
                    logger.info(f"{self.current_state['consecutive_losses']}連敗によりフラストレーション状態になりました")
            else:
                # それ以外は通常状態に徐々に戻る
                if random.random() < 0.3:  # 30%の確率で状態が変化
                    self.current_state["emotional_state"] = "neutral"
                    logger.info("感情状態が通常に戻りました")
        
        # 市場イベントによる感情変化
        if hasattr(self, "market_event") and self.market_event:
            if self.market_event["impact"] == "high":
                # 重要イベント発生時は慎重になる
                self.current_state["emotional_state"] = "cautious"
                logger.info(f"重要な市場イベント「{self.market_event['name']}」により慎重状態になりました")
    
    def _update_error_probability(self) -> None:
        """エラー確率を更新する"""
        if not self.config.get("behavior_settings", {}).get("error_simulation", {}).get("enabled", True):
            return
        
        # 基本エラー率
        base_error_rate = self.current_profile["error_rate"]
        
        # 疲労度によるエラー率の増加
        fatigue_factor = 1.0 + (self.current_state["fatigue_level"] * 2.0)  # 疲労度が最大の場合、エラー率は3倍になる
        
        # 感情状態によるエラー率の調整
        emotion_factor = 1.0
        if self.current_state["emotional_state"] == "excited":
            emotion_factor = 1.5  # 興奮状態ではエラー率が1.5倍
        elif self.current_state["emotional_state"] == "frustrated":
            emotion_factor = 2.0  # フラストレーション状態ではエラー率が2倍
        elif self.current_state["emotional_state"] == "cautious":
            emotion_factor = 0.7  # 慎重状態ではエラー率が0.7倍
        
        # 最終的なエラー確率を計算
        self.current_state["error_probability"] = min(0.2, base_error_rate * fatigue_factor * emotion_factor)  # 最大20%まで
    
    def should_make_error(self) -> bool:
        """
        エラーを発生させるべきかどうかを判断する
        
        Returns:
            bool: エラーを発生させるべきかどうか
        """
        if not self.config.get("behavior_settings", {}).get("error_simulation", {}).get("enabled", True):
            return False
        
        return random.random() < self.current_state["error_probability"]
    
    def simulate_delay(self, action_type: str = "normal") -> float:
        """
        人間らしい遅延時間をシミュレートする
        
        Args:
            action_type: アクションの種類（"normal", "decision", "correction", "typing"）
        
        Returns:
            float: 遅延時間（秒）
        """
        if not self.config.get("behavior_settings", {}).get("activity_pattern", {}).get("enabled", True):
            return 0.0
        
        # 基本遅延時間
        base_delay = 0.0
        
        if action_type == "normal":
            base_delay = random.uniform(0.5, 2.0)
        elif action_type == "decision":
            base_delay = self.current_profile["decision_speed"] * random.uniform(0.8, 1.2)
        elif action_type == "correction":
            base_delay = random.uniform(1.0, 3.0)
        elif action_type == "typing":
            # タイピング速度に基づく遅延
            words_per_minute = self.current_profile["typing_speed"]
            seconds_per_word = 60.0 / words_per_minute
            base_delay = seconds_per_word * random.uniform(0.8, 1.2)
        
        # 感情状態による遅延の調整
        emotion_factor = 1.0
        if self.current_state["emotional_state"] == "excited":
            emotion_factor = 0.7  # 興奮状態では速く行動
        elif self.current_state["emotional_state"] == "frustrated":
            emotion_factor = 1.3  # フラストレーション状態では遅く行動
        elif self.current_state["emotional_state"] == "cautious":
            emotion_factor = 1.5  # 慎重状態では非常に遅く行動
        
        # 疲労度による遅延の増加
        fatigue_factor = 1.0 + (self.current_state["fatigue_level"] * 0.5)  # 疲労度が最大の場合、遅延は1.5倍になる
        
        # 最終的な遅延時間を計算
        delay = base_delay * emotion_factor * fatigue_factor
        
        return delay
    
    def simulate_mouse_movement(self, start_x: int, start_y: int, end_x: int, end_y: int, steps: int = 10) -> List[Tuple[int, int]]:
        """
        人間らしいマウス移動をシミュレートする
        
        Args:
            start_x: 開始X座標
            start_y: 開始Y座標
            end_x: 終了X座標
            end_y: 終了Y座標
            steps: 移動ステップ数
        
        Returns:
            List[Tuple[int, int]]: 移動経路の座標リスト
        """
        if not self.config.get("behavior_settings", {}).get("activity_pattern", {}).get("enabled", True):
            return [(end_x, end_y)]
        
        # マウス移動スタイルに基づいて経路を生成
        movement_style = self.current_profile["mouse_movement_style"]
        
        # 直線的な移動
        if movement_style == "direct":
            path = []
            for i in range(steps + 1):
                t = i / steps
                x = int(start_x + t * (end_x - start_x))
                y = int(start_y + t * (end_y - start_y))
                path.append((x, y))
            return path
        
        # 曲線的な移動
        elif movement_style == "curved":
            path = []
            # ベジェ曲線の制御点をランダムに設定
            control_x = random.randint(min(start_x, end_x), max(start_x, end_x))
            control_y = random.randint(min(start_y, end_y), max(start_y, end_y))
            
            for i in range(steps + 1):
                t = i / steps
                # 二次ベジェ曲線
                x = int((1-t)**2 * start_x + 2*(1-t)*t * control_x + t**2 * end_x)
                y = int((1-t)**2 * start_y + 2*(1-t)*t * control_y + t**2 * end_y)
                path.append((x, y))
            return path
        
        # 躊躇する移動
        elif movement_style == "hesitant":
            path = []
            # 途中で一時停止するポイントを設定
            pause_point = random.randint(3, steps - 3)
            
            for i in range(steps + 1):
                t = i / steps
                x = int(start_x + t * (end_x - start_x))
                y = int(start_y + t * (end_y - start_y))
                
                # 躊躇するポイントでは同じ座標を複数回追加
                if i == pause_point:
                    for _ in range(3):  # 3回同じ座標を追加
                        path.append((x, y))
                else:
                    path.append((x, y))
            return path
        
        # 精密な移動
        elif movement_style == "precise":
            path = []
            for i in range(steps + 1):
                t = i / steps
                # 最初はゆっくり、最後も慎重に
                if t < 0.2:
                    t = t * 0.5  # 最初は遅く
                elif t > 0.8:
                    t = 0.8 + (t - 0.8) * 0.5  # 最後も遅く
                
                x = int(start_x + t * (end_x - start_x))
                y = int(start_y + t * (end_y - start_y))
                path.append((x, y))
            return path
        
        # デフォルトは直線移動
        else:
            path = []
            for i in range(steps + 1):
                t = i / steps
                x = int(start_x + t * (end_x - start_x))
                y = int(start_y + t * (end_y - start_y))
                path.append((x, y))
            return path
    
    def record_trade_result(self, result: str, amount: float, timestamp: dt.datetime = None) -> None:
        """
        取引結果を記録する
        
        Args:
            result: 取引結果（"win" または "loss"）
            amount: 取引金額
            timestamp: タイムスタンプ（指定しない場合は現在時刻）
        """
        if timestamp is None:
            timestamp = dt.datetime.now()
        
        trade_record = {
            "result": result,
            "amount": amount,
            "timestamp": timestamp.isoformat()
        }
        
        self.current_state["trade_history"].append(trade_record)
        
        # 連勝・連敗カウントの更新
        if result == "win":
            self.current_state["consecutive_wins"] += 1
            self.current_state["consecutive_losses"] = 0
        else:
            self.current_state["consecutive_losses"] += 1
            self.current_state["consecutive_wins"] = 0
        
        logger.info(f"取引結果を記録しました: {result}, 金額: {amount}, 連勝: {self.current_state['consecutive_wins']}, 連敗: {self.current_state['consecutive_losses']}")
    
    def take_break(self, duration: int = None) -> None:
        """
        休憩を取る
        
        Args:
            duration: 休憩時間（秒）、指定しない場合はプロファイルに基づいて決定
        """
        if not self.config.get("behavior_settings", {}).get("activity_pattern", {}).get("break_simulation", True):
            return
        
        if duration is None:
            break_pattern = self.current_profile["break_pattern"]
            if break_pattern["name"] == "irregular":
                duration = random.randint(break_pattern["min_dur"], break_pattern["max_dur"]) * 60  # 分から秒に変換
            else:
                duration = break_pattern["duration"] * 60  # 分から秒に変換
        
        logger.info(f"{duration/60:.1f}分間の休憩を開始します")
        
        # 休憩後の状態更新
        self.current_state["fatigue_level"] = max(0.0, self.current_state["fatigue_level"] - 0.3)  # 疲労度を30%回復
        self.current_state["session_start_time"] = dt.datetime.now()  # セッション開始時間をリセット
        
        logger.info(f"休憩が終了しました。疲労度: {self.current_state['fatigue_level']:.2f}")
    
    def change_profile(self) -> None:
        """行動プロファイルを変更する"""
        if not self.config.get("profile_variation", {}).get("enabled", True):
            return
        
        old_profile = self.current_profile
        
        # 現在のプロファイルとは異なるプロファイルを選択
        available_profiles = [p for p in self.behavior_profiles if p["id"] != old_profile["id"]]
        if not available_profiles:
            logger.warning("変更可能なプロファイルがありません")
            return
        
        self.current_profile = random.choice(available_profiles)
        logger.info(f"行動プロファイルを変更しました: {old_profile['id']} -> {self.current_profile['id']}")
        logger.info(f"新しいプロファイル: {self.current_profile['personality']} {self.current_profile['trading_style']}")
    
    def get_current_state_summary(self) -> Dict[str, Any]:
        """
        現在の状態のサマリーを取得する
        
        Returns:
            Dict[str, Any]: 状態のサマリー
        """
        return {
            "profile_id": self.current_profile.get("id", "unknown"),
            "personality": self.current_profile.get("personality", "unknown"),
            "trading_style": self.current_profile.get("trading_style", "unknown"),
            "emotional_state": self.current_state["emotional_state"],
            "fatigue_level": self.current_state["fatigue_level"],
            "error_probability": self.current_state["error_probability"],
            "consecutive_wins": self.current_state["consecutive_wins"],
            "consecutive_losses": self.current_state["consecutive_losses"],
            "session_duration_minutes": (dt.datetime.now() - dt.datetime.fromisoformat(self.current_state["session_start_time"].isoformat())).total_seconds() / 60
        }
    
    def simulate_typing_error(self, text: str) -> str:
        """
        タイピングエラーをシミュレートする
        
        Args:
            text: 入力テキスト
        
        Returns:
            str: エラーを含む可能性のあるテキスト
        """
        if not self.config.get("behavior_settings", {}).get("error_simulation", {}).get("enabled", True):
            return text
        
        if not self.should_make_error():
            return text
        
        # テキストが短すぎる場合はエラーを発生させない
        if len(text) < 3:
            return text
        
        # エラーの種類をランダムに選択
        error_type = random.choice(["typo", "swap", "double", "omit"])
        
        if error_type == "typo":
            # 1文字をタイプミスに置き換え
            pos = random.randint(0, len(text) - 1)
            char = text[pos]
            
            # キーボード上で隣接するキーを選択
            keyboard_map = {
                'a': 'sqwz', 'b': 'vghn', 'c': 'xdfv', 'd': 'serfcx', 'e': 'wrsdf',
                'f': 'drtgvc', 'g': 'ftyhbv', 'h': 'gyujnb', 'i': 'uojkl', 'j': 'huikmn',
                'k': 'jiolm', 'l': 'kop;', 'm': 'njk,', 'n': 'bhjm', 'o': 'iklp',
                'p': 'ol;[', 'q': 'asw', 'r': 'edft', 's': 'awedxz', 't': 'rfgy',
                'u': 'yhij', 'v': 'cfgb', 'w': 'qase', 'x': 'zsdc', 'y': 'tghu',
                'z': 'asx'
            }
            
            if char.lower() in keyboard_map:
                typo_char = random.choice(keyboard_map[char.lower()])
                if char.isupper():
                    typo_char = typo_char.upper()
                return text[:pos] + typo_char + text[pos+1:]
            
            return text
        
        elif error_type == "swap":
            # 隣接する2文字を入れ替え
            if len(text) < 2:
                return text
            
            pos = random.randint(0, len(text) - 2)
            return text[:pos] + text[pos+1] + text[pos] + text[pos+2:]
        
        elif error_type == "double":
            # 1文字を二重に入力
            pos = random.randint(0, len(text) - 1)
            return text[:pos] + text[pos] + text[pos] + text[pos+1:]
        
        elif error_type == "omit":
            # 1文字を省略
            pos = random.randint(0, len(text) - 1)
            return text[:pos] + text[pos+1:]
        
        return text
    
    def simulate_correction(self, text_with_error: str, original_text: str) -> Tuple[str, float]:
        """
        エラー修正をシミュレートする
        
        Args:
            text_with_error: エラーを含むテキスト
            original_text: 元のテキスト
        
        Returns:
            Tuple[str, float]: 修正されたテキストと修正にかかった時間（秒）
        """
        if text_with_error == original_text:
            return original_text, 0.0
        
        # エラーに気づく確率
        notice_probability = 0.8
        if self.current_state["fatigue_level"] > 0.5:
            notice_probability *= 0.7  # 疲労時は気づきにくい
        
        if random.random() > notice_probability:
            # エラーに気づかない場合
            return text_with_error, 0.0
        
        # エラー修正にかかる時間
        correction_time = self.simulate_delay("correction")
        
        # エラー修正の種類をランダムに選択
        correction_type = random.choice(["full_rewrite", "backspace_to_error"])
        
        if correction_type == "full_rewrite":
            # 全て書き直す
            return original_text, correction_time
        else:
            # エラー箇所まで戻って修正
            # 実際の修正プロセスはシミュレートしないが、時間は計算
            diff_pos = 0
            for i in range(min(len(text_with_error), len(original_text))):
                if text_with_error[i] != original_text[i]:
                    diff_pos = i
                    break
            
            # 追加の修正時間を計算（エラー箇所までの文字数に比例）
            additional_time = diff_pos * 0.1  # 1文字あたり0.1秒
            
            return original_text, correction_time + additional_time
