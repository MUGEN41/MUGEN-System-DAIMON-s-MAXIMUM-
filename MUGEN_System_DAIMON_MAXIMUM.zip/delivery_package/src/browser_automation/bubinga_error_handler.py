#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Bubinga Error Handler Module
---------------------------------
このモジュールはブビンガ（Bubinga）プラットフォーム自動操作時の
エラー検出、ログ記録、自動リカバリー機能を提供します。
"""

import time
import logging
import traceback
from selenium.common.exceptions import (
    TimeoutException, 
    NoSuchElementException, 
    ElementClickInterceptedException,
    StaleElementReferenceException,
    WebDriverException
)

# ロガーの設定
logger = logging.getLogger(__name__)

class BubingaErrorHandler:
    """ブビンガプラットフォームのエラー処理を行うクラス"""
    
    def __init__(self, recovery_system=None, max_retries=3, retry_delay=2):
        """
        初期化メソッド
        
        Args:
            recovery_system: 復旧システムのインスタンス（オプション）
            max_retries: 最大リトライ回数
            retry_delay: リトライ間の待機時間（秒）
        """
        self.recovery_system = recovery_system
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.error_counts = {
            'element_not_found': 0,
            'element_click_intercepted': 0,
            'stale_element': 0,
            'timeout': 0,
            'network': 0,
            'other': 0
        }
        self.last_error = None
        self.last_error_time = 0
        
        logger.info("ブビンガエラーハンドラーが初期化されました")
    
    def handle_error(self, error, operation_name, context=None):
        """
        エラーを処理し、適切なアクションを決定する
        
        Args:
            error: 発生したエラー/例外
            operation_name: エラーが発生した操作の名前
            context: エラーに関連する追加情報（辞書）
            
        Returns:
            dict: エラー処理結果と推奨アクション
        """
        error_type = type(error).__name__
        error_message = str(error)
        stack_trace = traceback.format_exc()
        
        # エラー情報のログ記録
        logger.error(f"操作 '{operation_name}' でエラーが発生しました: {error_type} - {error_message}")
        logger.debug(f"スタックトレース: {stack_trace}")
        
        # エラーカウントの更新
        self._update_error_counts(error)
        
        # エラー情報の保存
        self.last_error = {
            'type': error_type,
            'message': error_message,
            'operation': operation_name,
            'context': context,
            'stack_trace': stack_trace,
            'timestamp': time.time()
        }
        self.last_error_time = time.time()
        
        # エラータイプに基づいて処理方法を決定
        action = self._determine_action(error, operation_name, context)
        
        return action
    
    def _update_error_counts(self, error):
        """
        エラータイプに基づいてカウンターを更新
        
        Args:
            error: 発生したエラー/例外
        """
        if isinstance(error, NoSuchElementException):
            self.error_counts['element_not_found'] += 1
        elif isinstance(error, ElementClickInterceptedException):
            self.error_counts['element_click_intercepted'] += 1
        elif isinstance(error, StaleElementReferenceException):
            self.error_counts['stale_element'] += 1
        elif isinstance(error, TimeoutException):
            self.error_counts['timeout'] += 1
        elif isinstance(error, WebDriverException) and "net::" in str(error):
            self.error_counts['network'] += 1
        else:
            self.error_counts['other'] += 1
    
    def _determine_action(self, error, operation_name, context=None):
        """
        エラータイプに基づいて推奨アクションを決定
        
        Args:
            error: 発生したエラー/例外
            operation_name: エラーが発生した操作の名前
            context: エラーに関連する追加情報（辞書）
            
        Returns:
            dict: 推奨アクションと追加情報
        """
        action = {
            'action': 'retry',  # デフォルトはリトライ
            'retry_count': 0,
            'delay': self.retry_delay,
            'message': '操作をリトライします',
            'alternative_selectors': None,
            'should_refresh': False,
            'should_restart': False
        }
        
        # コンテキストからリトライ回数を取得
        if context and 'retry_count' in context:
            action['retry_count'] = context['retry_count']
        
        # 最大リトライ回数を超えた場合
        if action['retry_count'] >= self.max_retries:
            action['action'] = 'fail'
            action['message'] = f"最大リトライ回数（{self.max_retries}）を超えました"
            return action
        
        # エラータイプに基づいて処理方法を決定
        if isinstance(error, NoSuchElementException):
            # 要素が見つからない場合
            action['message'] = "要素が見つかりません。代替セレクタを試みます"
            action['alternative_selectors'] = self._get_alternative_selectors(context)
            
            # 代替セレクタがない場合はページの更新を試みる
            if not action['alternative_selectors']:
                action['should_refresh'] = True
                action['delay'] = 3  # ページ更新後は少し長めに待機
        
        elif isinstance(error, ElementClickInterceptedException):
            # 要素がクリックできない場合
            action['message'] = "要素がクリックできません。スクロールまたはJavaScriptクリックを試みます"
            action['action'] = 'js_click'
            action['delay'] = 1
        
        elif isinstance(error, StaleElementReferenceException):
            # 要素が古くなった場合
            action['message'] = "要素が古くなっています。ページを更新します"
            action['should_refresh'] = True
            action['delay'] = 3
        
        elif isinstance(error, TimeoutException):
            # タイムアウトの場合
            action['message'] = "操作がタイムアウトしました。待機時間を延長します"
            action['delay'] = self.retry_delay * 2
            
            # 連続したタイムアウトの場合はページを更新
            if self.error_counts['timeout'] > 2:
                action['should_refresh'] = True
                action['delay'] = 5
        
        elif isinstance(error, WebDriverException) and "net::" in str(error):
            # ネットワークエラーの場合
            action['message'] = "ネットワークエラーが発生しました。接続を再試行します"
            action['delay'] = 5
            
            # 連続したネットワークエラーの場合はセッションを再起動
            if self.error_counts['network'] > 2:
                action['should_restart'] = True
                action['message'] = "ネットワークエラーが続いています。セッションを再起動します"
        
        else:
            # その他のエラーの場合
            action['message'] = f"予期せぬエラーが発生しました: {type(error).__name__}"
            action['delay'] = 3
            
            # 重大なエラーの場合はセッションを再起動
            if "crashed" in str(error).lower() or "killed" in str(error).lower():
                action['should_restart'] = True
                action['message'] = "ブラウザがクラッシュした可能性があります。セッションを再起動します"
        
        # リトライ回数を更新
        action['retry_count'] += 1
        
        return action
    
    def _get_alternative_selectors(self, context):
        """
        代替セレクタを取得する
        
        Args:
            context: エラーに関連する追加情報（辞書）
            
        Returns:
            dict: 代替セレクタ情報、または None
        """
        if not context or 'element_dict' not in context:
            return None
        
        element_dict = context.get('element_dict', {})
        element_type = context.get('element_type', '')
        
        # 代替セレクタの定義
        alternatives = {}
        
        # ログイン関連の要素
        if element_type == 'login_email':
            alternatives = {
                'xpath': [
                    '//input[@type="email"]',
                    '//input[@name="email"]',
                    '//input[contains(@placeholder, "Email")]',
                    '//input[contains(@class, "email")]'
                ],
                'css': [
                    'input[type="email"]',
                    'input[name="email"]',
                    'input.email-input',
                    'form input:first-of-type'
                ]
            }
        elif element_type == 'login_password':
            alternatives = {
                'xpath': [
                    '//input[@type="password"]',
                    '//input[@name="password"]',
                    '//input[contains(@placeholder, "Password")]',
                    '//input[contains(@class, "password")]'
                ],
                'css': [
                    'input[type="password"]',
                    'input[name="password"]',
                    'input.password-input',
                    'form input[type="password"]'
                ]
            }
        elif element_type == 'login_button':
            alternatives = {
                'xpath': [
                    '//button[contains(text(), "Login")]',
                    '//button[contains(text(), "Sign in")]',
                    '//button[@type="submit"]',
                    '//input[@type="submit"]',
                    '//button[contains(@class, "login")]',
                    '//div[contains(@class, "login-button")]'
                ],
                'css': [
                    'button[type="submit"]',
                    'input[type="submit"]',
                    'button.login-btn',
                    'button.submit-btn',
                    '.login-button',
                    'form button'
                ]
            }
        
        # 取引関連の要素
        elif element_type == 'asset_dropdown':
            alternatives = {
                'xpath': [
                    '//div[contains(@class, "asset-selector")]',
                    '//div[contains(@class, "instrument-selector")]',
                    '//div[contains(@class, "symbol-selector")]',
                    '//div[contains(text(), "Select asset")]/..',
                    '//div[contains(text(), "Select instrument")]/..'
                ],
                'css': [
                    '.asset-selector',
                    '.instrument-selector',
                    '.symbol-selector',
                    '.asset-dropdown',
                    '.trading-instrument-selector'
                ]
            }
        elif element_type == 'amount_field':
            alternatives = {
                'xpath': [
                    '//input[contains(@placeholder, "Amount")]',
                    '//input[@name="amount"]',
                    '//input[contains(@class, "amount")]',
                    '//label[contains(text(), "Amount")]//following::input[1]',
                    '//div[contains(text(), "Amount")]//following::input[1]'
                ],
                'css': [
                    'input[name="amount"]',
                    'input.amount-input',
                    '.amount-field input',
                    '.trade-amount input',
                    '.investment-amount input'
                ]
            }
        elif element_type == 'high_button':
            alternatives = {
                'xpath': [
                    '//button[contains(@class, "high")]',
                    '//button[contains(@class, "up")]',
                    '//button[contains(text(), "High")]',
                    '//button[contains(text(), "Up")]',
                    '//div[contains(@class, "high-button")]',
                    '//div[contains(@class, "up-button")]'
                ],
                'css': [
                    'button.high-btn',
                    'button.up-btn',
                    '.high-button',
                    '.up-button',
                    '.buy-call-button',
                    '.trade-button-up'
                ]
            }
        elif element_type == 'low_button':
            alternatives = {
                'xpath': [
                    '//button[contains(@class, "low")]',
                    '//button[contains(@class, "down")]',
                    '//button[contains(text(), "Low")]',
                    '//button[contains(text(), "Down")]',
                    '//div[contains(@class, "low-button")]',
                    '//div[contains(@class, "down-button")]'
                ],
                'css': [
                    'button.low-btn',
                    'button.down-btn',
                    '.low-button',
                    '.down-button',
                    '.buy-put-button',
                    '.trade-button-down'
                ]
            }
        
        # 該当する代替セレクタがない場合
        if not alternatives:
            return None
        
        return alternatives
    
    def get_error_statistics(self):
        """
        エラー統計情報を取得する
        
        Returns:
            dict: エラータイプごとの発生回数
        """
        total_errors = sum(self.error_counts.values())
        
        return {
            'total_errors': total_errors,
            'counts': self.error_counts,
            'last_error': self.last_error,
            'last_error_time': self.last_error_time
        }
    
    def reset_error_counts(self):
        """エラーカウンターをリセットする"""
        for key in self.error_counts:
            self.error_counts[key] = 0
        
        logger.info("エラーカウンターがリセットされました")
    
    def should_pause_operations(self):
        """
        操作を一時停止すべきかどうかを判断する
        
        Returns:
            bool: 操作を一時停止すべき場合はTrue
        """
        # 短時間に多数のエラーが発生した場合
        total_recent_errors = sum(self.error_counts.values())
        if total_recent_errors > 10:
            logger.warning(f"短時間に{total_recent_errors}件のエラーが発生しました。操作を一時停止します")
            return True
        
        # ネットワークエラーが連続して発生した場合
        if self.error_counts['network'] > 5:
            logger.warning(f"ネットワークエラーが{self.error_counts['network']}回連続して発生しました。操作を一時停止します")
            return True
        
        # 要素が見つからないエラーが多発した場合
        if self.error_counts['element_not_found'] > 15:
            logger.warning(f"要素が見つからないエラーが{self.error_counts['element_not_found']}回発生しました。操作を一時停止します")
            return True
        
        return False
    
    def execute_with_error_handling(self, func, *args, operation_name=None, context=None, **kwargs):
        """
        エラーハンドリング付きで関数を実行する
        
        Args:
            func: 実行する関数
            *args: 関数に渡す位置引数
            operation_name: 操作の名前（指定がない場合は関数名を使用）
            context: エラーに関連する追加情報（辞書）
            **kwargs: 関数に渡すキーワード引数
            
        Returns:
            関数の戻り値、またはエラー処理結果
        """
        if operation_name is None:
            operation_name = func.__name__
            
        if context is None:
            context = {}
            
        retry_count = 0
        max_retries = self.max_retries
        
        while retry_count <= max_retries:
            try:
                # 関数を実行
                result = func(*args, **kwargs)
                
                # 成功した場合、連続エラーカウントをリセット
                if retry_count > 0:
                    logger.info(f"操作 '{operation_name}' が{retry_count}回目の試行で成功しました")
                
                return result
                
            except Exception as e:
                # エラー処理
                context['retry_count'] = retry_count
                action = self.handle_error(e, operation_name, context)
                
                # 最大リトライ回数を超えた場合
                if action['action'] == 'fail' or retry_count >= max_retries:
                    logger.error(f"操作 '{operation_name}' が{retry_count}回の試行後も失敗しました")
                    raise
                
                # リトライ前の待機
                logger.info(f"{action['message']} ({retry_count + 1}/{max_retries})")
                time.sleep(action['delay'])
                
                # リトライカウントを更新
                retry_count += 1
                
                # コンテキストを更新
                if action['alternative_selectors']:
                    context['alternative_selectors'] = action['alternative_selectors']
                
                # ページの更新が必要な場合
                if action['should_refresh'] and 'driver' in context:
                    logger.info("ページを更新します")
                    context['driver'].refresh()
                    time.sleep(3)  # ページ読み込み待機
                
                # セッションの再起動が必要な場合
                if action['should_restart'] and self.recovery_system:
                    logger.info("セッションを再起動します")
                    self.recovery_system.restart_session()
                    time.sleep(5)  # セッション再起動待機
