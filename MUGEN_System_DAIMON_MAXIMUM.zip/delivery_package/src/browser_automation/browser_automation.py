#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System (DAIMON's MAXIMUM) - ブラウザ自動操作モジュール
The OptionとBi-Winningプラットフォームへの自動エントリーを実現するモジュール
"""

import os
import sys
import json
import time
import random
import logging
import datetime as dt
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple

# Playwrightのインポート
try:
    from playwright.sync_api import sync_playwright, Page, Browser, BrowserContext, ElementHandle
except ImportError:
    logging.error("Playwrightがインストールされていません。'pip install playwright'を実行してください。")
    logging.error("その後、'playwright install'を実行してブラウザをインストールしてください。")
    sys.exit(1)

# OCR用のインポート
try:
    import cv2
    import numpy as np
    import pytesseract
except ImportError:
    logging.error("必要なパッケージがインストールされていません。")
    logging.error("'pip install opencv-python numpy pytesseract'を実行してください。")
    logging.error("また、Tesseract OCRをシステムにインストールする必要があります。")

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("browser_automation.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Browser_Automation")

class BrowserAutomation:
    """
    ブラウザ自動操作クラス
    The OptionとBi-Winningプラットフォームへの自動エントリーを実現する
    """
    
    def __init__(self, config_path: str = "config/browser_automation_config.json", headless: bool = False):
        """
        初期化
        
        Args:
            config_path: 設定ファイルのパス
            headless: ヘッドレスモードで実行するかどうか
        """
        self.config_path = Path(config_path)
        self.config_dir = self.config_path.parent
        self.config: Dict[str, Any] = {}
        self.headless = headless
        self.browser = None
        self.context = None
        self.page = None
        self.platform = None  # 現在のプラットフォーム（"the_option" または "bi_winning"）
        self._ensure_config_dir()
        self._load_config()
    
    def _ensure_config_dir(self) -> None:
        """設定ディレクトリが存在することを確認"""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)
            logger.info(f"設定ディレクトリを作成しました: {self.config_dir}")
    
    def _load_config(self) -> None:
        """設定ファイルを読み込む"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info("ブラウザ自動操作設定を読み込みました")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
                self.config = {}
        else:
            logger.info("設定ファイルが存在しないため、新規作成します")
            # 初期設定
            self.config = {
                "platforms": {
                    "the_option": {
                        "url": "https://theoption.com/",
                        "selectors": {
                            "login_button": "button.login-button",
                            "username_input": "input[name='username']",
                            "password_input": "input[name='password']",
                            "submit_button": "button[type='submit']",
                            "amount_input": "input.trade-amount",
                            "up_button": "button.up-trade",
                            "down_button": "button.down-trade",
                            "confirm_button": "button.confirm-trade",
                            "result_element": "div.trade-result",
                            "balance_element": "div.account-balance"
                        },
                        "credentials": {
                            "username": "",
                            "password": ""
                        }
                    },
                    "bi_winning": {
                        "url": "https://biwinning.com/",
                        "selectors": {
                            "login_button": "a.login",
                            "username_input": "#username",
                            "password_input": "#password",
                            "submit_button": "button.login-submit",
                            "amount_input": "input.amount",
                            "up_button": "button.call-button",
                            "down_button": "button.put-button",
                            "confirm_button": "button.confirm",
                            "result_element": ".trade-result",
                            "balance_element": ".balance"
                        },
                        "credentials": {
                            "username": "",
                            "password": ""
                        }
                    }
                },
                "browser_settings": {
                    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
                    "viewport_width": 1280,
                    "viewport_height": 800,
                    "locale": "ja-JP",
                    "timezone": "Asia/Tokyo",
                    "timeout": 30000,  # ミリ秒
                    "retry_attempts": 3
                },
                "ocr_settings": {
                    "enabled": true,
                    "language": "eng",
                    "confidence_threshold": 80
                },
                "last_updated": dt.datetime.now().isoformat()
            }
            self._save_config()
    
    def _save_config(self) -> None:
        """設定ファイルを保存する"""
        try:
            # 更新日時を記録
            self.config["last_updated"] = dt.datetime.now().isoformat()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("ブラウザ自動操作設定を保存しました")
        except Exception as e:
            logger.error(f"設定ファイルの保存に失敗しました: {e}")
    
    def start_browser(self) -> None:
        """ブラウザを起動する"""
        try:
            playwright = sync_playwright().start()
            
            browser_settings = self.config.get("browser_settings", {})
            user_agent = browser_settings.get("user_agent", "")
            viewport_width = browser_settings.get("viewport_width", 1280)
            viewport_height = browser_settings.get("viewport_height", 800)
            locale = browser_settings.get("locale", "ja-JP")
            timezone = browser_settings.get("timezone", "Asia/Tokyo")
            
            self.browser = playwright.chromium.launch(headless=self.headless)
            self.context = self.browser.new_context(
                user_agent=user_agent,
                viewport={"width": viewport_width, "height": viewport_height},
                locale=locale,
                timezone_id=timezone
            )
            self.page = self.context.new_page()
            
            # タイムアウト設定
            timeout = browser_settings.get("timeout", 30000)
            self.page.set_default_timeout(timeout)
            
            logger.info("ブラウザを起動しました")
        except Exception as e:
            logger.error(f"ブラウザの起動に失敗しました: {e}")
            raise
    
    def close_browser(self) -> None:
        """ブラウザを閉じる"""
        try:
            if self.context:
                self.context.close()
            if self.browser:
                self.browser.close()
            logger.info("ブラウザを閉じました")
        except Exception as e:
            logger.error(f"ブラウザを閉じる際にエラーが発生しました: {e}")
    
    def login(self, platform: str) -> bool:
        """
        指定されたプラットフォームにログインする
        
        Args:
            platform: プラットフォーム名（"the_option" または "bi_winning"）
        
        Returns:
            bool: ログイン成功かどうか
        """
        if not self.browser or not self.page:
            logger.error("ブラウザが起動していません")
            return False
        
        if platform not in self.config.get("platforms", {}):
            logger.error(f"未知のプラットフォームです: {platform}")
            return False
        
        self.platform = platform
        platform_config = self.config["platforms"][platform]
        url = platform_config["url"]
        selectors = platform_config["selectors"]
        credentials = platform_config["credentials"]
        
        if not credentials.get("username") or not credentials.get("password"):
            logger.error(f"認証情報が設定されていません: {platform}")
            return False
        
        try:
            # ページに移動
            logger.info(f"{platform}のログインページに移動します: {url}")
            self.page.goto(url)
            
            # ログインボタンをクリック
            login_button_selector = selectors["login_button"]
            logger.info(f"ログインボタンをクリックします: {login_button_selector}")
            self.page.click(login_button_selector)
            
            # ユーザー名とパスワードを入力
            username_input_selector = selectors["username_input"]
            password_input_selector = selectors["password_input"]
            submit_button_selector = selectors["submit_button"]
            
            logger.info(f"ユーザー名を入力します: {username_input_selector}")
            self.page.fill(username_input_selector, credentials["username"])
            
            logger.info(f"パスワードを入力します: {password_input_selector}")
            self.page.fill(password_input_selector, credentials["password"])
            
            # 送信ボタンをクリック
            logger.info(f"送信ボタンをクリックします: {submit_button_selector}")
            self.page.click(submit_button_selector)
            
            # ログイン成功を確認
            # ここでは単純に数秒待ってからURLが変わっているかどうかで判断
            time.sleep(3)
            current_url = self.page.url
            
            if current_url != url:
                logger.info(f"{platform}へのログインに成功しました")
                return True
            else:
                logger.error(f"{platform}へのログインに失敗しました")
                return False
        except Exception as e:
            logger.error(f"ログイン中にエラーが発生しました: {e}")
            return False
    
    def logout(self) -> bool:
        """
        現在のプラットフォームからログアウトする
        
        Returns:
            bool: ログアウト成功かどうか
        """
        if not self.browser or not self.page or not self.platform:
            logger.error("ブラウザが起動していないか、プラットフォームが選択されていません")
            return False
        
        platform_config = self.config["platforms"][self.platform]
        url = platform_config["url"]
        
        try:
            # ログアウト処理
            # プラットフォームによって異なるため、ここでは単純にトップページに戻る
            logger.info(f"{self.platform}からログアウトします")
            self.page.goto(url)
            
            # ログアウト成功を確認
            time.sleep(1)
            current_url = self.page.url
            
            if current_url == url:
                logger.info(f"{self.platform}からのログアウトに成功しました")
                return True
            else:
                logger.error(f"{self.platform}からのログアウトに失敗しました")
                return False
        except Exception as e:
            logger.error(f"ログアウト中にエラーが発生しました: {e}")
            return False
    
    def place_trade(self, direction: str, amount: float) -> Dict[str, Any]:
        """
        取引を行う
        
        Args:
            direction: 取引方向（"up" または "down"）
            amount: 取引金額
        
        Returns:
            Dict[str, Any]: 取引結果
        """
        if not self.browser or not self.page or not self.platform:
            logger.error("ブラウザが起動していないか、プラットフォームが選択されていません")
            return {"success": False, "error": "ブラウザが起動していないか、プラットフォームが選択されていません"}
        
        if direction not in ["up", "down"]:
            logger.error(f"無効な取引方向です: {direction}")
            return {"success": False, "error": f"無効な取引方向です: {direction}"}
        
        platform_config = self.config["platforms"][self.platform]
        selectors = platform_config["selectors"]
        
        try:
            # 金額を入力
            amount_input_selector = selectors["amount_input"]
            logger.info(f"取引金額を入力します: {amount}")
            self.page.fill(amount_input_selector, str(int(amount)))
            
            # 取引方向ボタンをクリック
            if direction == "up":
                direction_button_selector = selectors["up_button"]
                logger.info("上昇(UP)ボタンをクリックします")
            else:
                direction_button_selector = selectors["down_button"]
                logger.info("下降(DOWN)ボタンをクリックします")
            
            self.page.click(direction_button_selector)
            
            # 確認ボタンをクリック
            confirm_button_selector = selectors["confirm_button"]
            logger.info("確認ボタンをクリックします")
            self.page.click(confirm_button_selector)
            
            # 取引結果を待つ
            # ここでは単純に数秒待ってから結果を確認
            time.sleep(10)
            
            # 結果を取得
            result_element_selector = selectors["result_element"]
            result_text = self.page.text_content(result_element_selector)
            
            # 残高を取得
            balance_element_selector = selectors["balance_element"]
            balance_text = self.page.text_content(balance_element_selector)
            
            # 結果を解析
            result = "unknown"
            if "win" in result_text.lower() or "勝ち" in result_text:
                result = "win"
            elif "loss" in result_text.lower() or "負け" in result_text:
                result = "loss"
            
            # 残高を解析
            balance = 0.0
            try:
                # 数字だけを抽出
                balance_str = ''.join(c for c in balance_text if c.isdigit() or c == '.')
                balance = float(balance_str)
            except:
                logger.warning(f"残高の解析に失敗しました: {balance_text}")
            
            logger.info(f"取引結果: {result}, 残高: {balance}")
            
            return {
                "success": True,
                "result": result,
                "balance": balance,
                "timestamp": dt.datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"取引中にエラーが発生しました: {e}")
            return {"success": False, "error": str(e)}
    
    def capture_screen(self, file_path: str = None) -> str:
        """
        スクリーンショットを撮影する
        
        Args:
            file_path: 保存先のファイルパス（指定しない場合は一時ファイル）
        
        Returns:
            str: スクリーンショットのファイルパス
        """
        if not self.browser or not self.page:
            logger.error("ブラウザが起動していません")
            return ""
        
        try:
            if not file_path:
                file_path = f"screenshot_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            
            self.page.screenshot(path=file_path)
            logger.info(f"スクリーンショットを保存しました: {file_path}")
            
            return file_path
        except Exception as e:
            logger.error(f"スクリーンショットの撮影に失敗しました: {e}")
            return ""
    
    def extract_text_from_image(self, image_path: str, region: Tuple[int, int, int, int] = None) -> str:
        """
        画像からテキストを抽出する
        
        Args:
            image_path: 画像ファイルのパス
            region: 抽出する領域（x, y, width, height）
        
        Returns:
            str: 抽出されたテキスト
        """
        if not self.config.get("ocr_settings", {}).get("enabled", True):
            logger.warning("OCRが無効になっています")
            return ""
        
        try:
            # 画像を読み込む
            image = cv2.imread(image_path)
            
            if region:
                x, y, width, height = region
                image = image[y:y+height, x:x+width]
            
            # OCR設定
            ocr_settings = self.config.get("ocr_settings", {})
            language = ocr_settings.get("language", "eng")
            
            # OCRを実行
            text = pytesseract.image_to_string(image, lang=language)
            
            logger.info(f"画像からテキストを抽出しました: {text[:50]}...")
            
            return text
        except Exception as e:
            logger.error(f"OCRの実行に失敗しました: {e}")
            return ""
    
    def wait_for_element(self, selector: str, timeout: int = None) -> bool:
        """
        要素が表示されるまで待機する
        
        Args:
            selector: 要素のセレクタ
            timeout: タイムアウト（ミリ秒）
        
        Returns:
            bool: 要素が見つかったかどうか
        """
        if not self.browser or not self.page:
            logger.error("ブラウザが起動していません")
            return False
        
        if not timeout:
            browser_settings = self.config.get("browser_settings", {})
            timeout = browser_settings.get("timeout", 30000)
        
        try:
            self.page.wait_for_selector(selector, timeout=timeout)
            logger.info(f"要素が見つかりました: {selector}")
            return True
        except Exception as e:
            logger.error(f"要素の待機中にタイムアウトしました: {selector}, {e}")
            return False
    
    def retry_operation(self, operation_func, max_attempts: int = None) -> Any:
        """
        操作を再試行する
        
        Args:
            operation_func: 実行する操作の関数
            max_attempts: 最大試行回数
        
        Returns:
            Any: 操作の結果
        """
        if not max_attempts:
            browser_settings = self.config.get("browser_settings", {})
            max_attempts = browser_settings.get("retry_attempts", 3)
        
        attempt = 0
        last_error = None
        
        while attempt < max_attempts:
            try:
                result = operation_func()
                return result
            except Exception as e:
                attempt += 1
                last_error = e
                logger.warning(f"操作に失敗しました（試行 {attempt}/{max_attempts}）: {e}")
                
                if attempt < max_attempts:
                    # 再試行前に少し待機
                    time.sleep(2)
        
        logger.error(f"操作が {max_attempts} 回失敗しました: {last_error}")
        raise last_error
    
    def get_account_balance(self) -> float:
        """
        口座残高を取得する
        
        Returns:
            float: 口座残高
        """
        if not self.browser or not self.page or not self.platform:
            logger.error("ブラウザが起動していないか、プラットフォームが選択されていません")
            return 0.0
        
        platform_config = self.config["platforms"][self.platform]
        selectors = platform_config["selectors"]
        
        try:
            # 残高要素を取得
            balance_element_selector = selectors["balance_element"]
            balance_text = self.page.text_content(balance_element_selector)
            
            # 残高を解析
            try:
                # 数字だけを抽出
                balance_str = ''.join(c for c in balance_text if c.isdigit() or c == '.')
                balance = float(balance_str)
                logger.info(f"口座残高: {balance}")
                return balance
            except:
                logger.warning(f"残高の解析に失敗しました: {balance_text}")
                return 0.0
        except Exception as e:
            logger.error(f"残高の取得に失敗しました: {e}")
            return 0.0
    
    def set_credentials(self, platform: str, username: str, password: str) -> None:
        """
        認証情報を設定する
        
        Args:
            platform: プラットフォーム名（"the_option" または "bi_winning"）
            username: ユーザー名
            password: パスワード
        """
        if platform not in self.config.get("platforms", {}):
            logger.error(f"未知のプラットフォームです: {platform}")
            return
        
        self.config["platforms"][platform]["credentials"] = {
            "username": username,
            "password": password
        }
        
        self._save_config()
        logger.info(f"{platform}の認証情報を設定しました")
    
    def is_logged_in(self) -> bool:
        """
        ログイン状態かどうかを確認する
        
        Returns:
            bool: ログイン状態かどうか
        """
        if not self.browser or not self.page or not self.platform:
            logger.error("ブラウザが起動していないか、プラットフォームが選択されていません")
            return False
        
        platform_config = self.config["platforms"][self.platform]
        url = platform_config["url"]
        
        try:
            # ログイン状態の確認方法はプラットフォームによって異なる
            # ここでは単純にURLが変わっているかどうかで判断
            current_url = self.page.url
            
            if current_url != url:
                logger.info(f"{self.platform}にログイン中です")
                return True
            else:
                logger.info(f"{self.platform}にログインしていません")
                return False
        except Exception as e:
            logger.error(f"ログイン状態の確認に失敗しました: {e}")
            return False
