#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Bubinga Platform Automation Module
---------------------------------
このモジュールはブビンガ（Bubinga）バイナリーオプションプラットフォームの
自動操作機能を提供します。要素検出、ログイン、取引操作、
人間らしい操作パターンの再現などの機能を実装しています。
"""

import time
import random
import logging
import sys
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# srcディレクトリをPYTHONPATHに追加
src_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if src_path not in sys.path:
    sys.path.insert(0, src_path)

# 内部モジュールのインポート（フラットなパッケージ構造に統一）
from utils.human_behavior_simulator import HumanBehaviorSimulator
from detection_avoidance.detection_avoidance_system import DetectionAvoidanceSystem
from core.recovery_system import RecoverySystem

# ロガーの設定
logger = logging.getLogger(__name__)

class BubingaAutomation:
    """ブビンガプラットフォームの自動操作を行うクラス"""
    
    def __init__(self, driver, config, human_behavior_simulator=None, 
                 detection_avoidance_system=None, recovery_system=None):
        """
        初期化メソッド
        
        Args:
            driver: Seleniumのウェブドライバーインスタンス
            config: ブビンガ自動化の設定情報を含む辞書
            human_behavior_simulator: 人間行動シミュレーターのインスタンス（オプション）
            detection_avoidance_system: 検知回避システムのインスタンス（オプション）
            recovery_system: 復旧システムのインスタンス（オプション）
        """
        self.driver = driver
        self.config = config
        self.base_url = config.get('base_url', 'https://bubinga.com')
        self.login_url = config.get('login_url', f"{self.base_url}/login")
        self.trading_url = config.get('trading_url', f"{self.base_url}/trading")
        
        # 外部システムの設定
        self.human_behavior = human_behavior_simulator or HumanBehaviorSimulator()
        self.detection_avoidance = detection_avoidance_system or DetectionAvoidanceSystem()
        self.recovery_system = recovery_system or RecoverySystem()
        
        # 要素セレクタ（推定）- 実際のプラットフォームに合わせて調整が必要
        self.selectors = {
            'login': {
                'email_field': {
                    'xpath': '//input[@type="email" or @name="email" or contains(@placeholder, "email")]',
                    'css': 'input[type="email"], input[name="email"]'
                },
                'password_field': {
                    'xpath': '//input[@type="password" or @name="password" or contains(@placeholder, "password")]',
                    'css': 'input[type="password"], input[name="password"]'
                },
                'login_button': {
                    'xpath': '//button[contains(text(), "Login") or contains(text(), "Sign in") or contains(@class, "login")]',
                    'css': 'button.login-btn, button[type="submit"]'
                },
                '2fa_field': {
                    'xpath': '//input[contains(@placeholder, "verification") or contains(@name, "2fa")]',
                    'css': 'input.verification-code, input[name="2fa"]'
                }
            },
            'trading': {
                'asset_dropdown': {
                    'xpath': '//div[contains(@class, "asset-selector") or contains(@class, "instrument-selector")]',
                    'css': 'div.asset-selector, div.instrument-selector'
                },
                'asset_search': {
                    'xpath': '//input[contains(@placeholder, "Search") and ancestor::div[contains(@class, "asset-selector")]]',
                    'css': 'div.asset-selector input, div.instrument-selector input'
                },
                'asset_list': {
                    'xpath': '//div[contains(@class, "asset-list") or contains(@class, "instrument-list")]//div[contains(@class, "item")]',
                    'css': 'div.asset-list .item, div.instrument-list .item'
                },
                'amount_field': {
                    'xpath': '//input[contains(@placeholder, "Amount") or @name="amount" or contains(@class, "amount")]',
                    'css': 'input.amount-input, input[name="amount"]'
                },
                'time_selector': {
                    'xpath': '//div[contains(@class, "time-selector") or contains(@class, "expiry-selector")]',
                    'css': 'div.time-selector, div.expiry-selector'
                },
                'time_options': {
                    'xpath': '//div[contains(@class, "time-selector")]//div[contains(@class, "option")]',
                    'css': 'div.time-selector .option, div.expiry-selector .option'
                },
                'high_button': {
                    'xpath': '//button[contains(@class, "high") or contains(@class, "up") or contains(text(), "High") or contains(text(), "Up")]',
                    'css': 'button.high-btn, button.up-btn'
                },
                'low_button': {
                    'xpath': '//button[contains(@class, "low") or contains(@class, "down") or contains(text(), "Low") or contains(text(), "Down")]',
                    'css': 'button.low-btn, button.down-btn'
                },
                'confirm_button': {
                    'xpath': '//button[contains(@class, "confirm") or contains(text(), "Confirm") or contains(text(), "Place Trade")]',
                    'css': 'button.confirm-btn, button.place-trade-btn'
                },
                'balance': {
                    'xpath': '//div[contains(@class, "balance") or contains(text(), "Balance")]//span',
                    'css': 'div.balance span, div.account-balance span'
                }
            },
            'navigation': {
                'trading_link': {
                    'xpath': '//a[contains(@href, "trading") or contains(text(), "Trading")]',
                    'css': 'a[href*="trading"], a.trading-link'
                },
                'deposit_link': {
                    'xpath': '//a[contains(@href, "deposit") or contains(text(), "Deposit")]',
                    'css': 'a[href*="deposit"], a.deposit-link'
                },
                'withdraw_link': {
                    'xpath': '//a[contains(@href, "withdraw") or contains(text(), "Withdraw")]',
                    'css': 'a[href*="withdraw"], a.withdraw-link'
                },
                'account_link': {
                    'xpath': '//a[contains(@href, "account") or contains(@href, "profile") or contains(text(), "Account")]',
                    'css': 'a[href*="account"], a[href*="profile"], a.account-link'
                },
                'logout_button': {
                    'xpath': '//a[contains(@href, "logout") or contains(text(), "Logout") or contains(text(), "Sign out")]',
                    'css': 'a[href*="logout"], a.logout-btn, button.logout-btn'
                }
            }
        }
        
        # 要素検出の最大待機時間（秒）
        self.wait_timeout = config.get('wait_timeout', 10)
        
        # 現在のセッション状態
        self.is_logged_in = False
        self.current_balance = 0.0
        self.last_action_time = 0
        
        logger.info("ブビンガ自動化モジュールが初期化されました")
    
    def find_element_with_retry(self, element_dict, max_retries=3, wait_time=2):
        """
        複数の検出方法を試して要素を見つける
        
        Args:
            element_dict: 要素のセレクタ情報を含む辞書
            max_retries: 最大リトライ回数
            wait_time: リトライ間の待機時間（秒）
            
        Returns:
            見つかった要素、見つからない場合はNone
        """
        methods = [
            (By.XPATH, element_dict.get('xpath')),
            (By.CSS_SELECTOR, element_dict.get('css')),
            (By.ID, element_dict.get('id')),
            (By.CLASS_NAME, element_dict.get('class'))
        ]
        
        # 有効なセレクタのみをフィルタリング
        methods = [(method, selector) for method, selector in methods if selector]
        
        for _ in range(max_retries):
            for method, selector in methods:
                try:
                    wait = WebDriverWait(self.driver, self.wait_timeout)
                    element = wait.until(EC.presence_of_element_located((method, selector)))
                    wait.until(EC.element_to_be_clickable((method, selector)))
                    return element
                except (TimeoutException, NoSuchElementException):
                    continue
            
            # 全ての方法が失敗した場合、少し待ってからリトライ
            time.sleep(wait_time)
        
        logger.warning(f"要素が見つかりませんでした: {element_dict}")
        return None
    
    def login(self, email, password, twofa_code=None):
        """
        ブビンガプラットフォームにログインする
        
        Args:
            email: ログイン用メールアドレス
            password: ログイン用パスワード
            twofa_code: 二段階認証コード（必要な場合）
            
        Returns:
            bool: ログイン成功時はTrue、失敗時はFalse
        """
        try:
            # ログインページに移動
            logger.info("ログインページにアクセスしています...")
            self.driver.get(self.login_url)
            
            # 人間らしい待機
            self.human_behavior.random_wait(1, 3)
            
            # メールアドレス入力
            email_field = self.find_element_with_retry(self.selectors['login']['email_field'])
            if not email_field:
                logger.error("メールアドレス入力フィールドが見つかりませんでした")
                return False
            
            self.human_behavior.human_type(email_field, email)
            self.human_behavior.random_wait(0.5, 1.5)
            
            # パスワード入力
            password_field = self.find_element_with_retry(self.selectors['login']['password_field'])
            if not password_field:
                logger.error("パスワード入力フィールドが見つかりませんでした")
                return False
                
            self.human_behavior.human_type(password_field, password)
            self.human_behavior.random_wait(0.5, 1.5)
            
            # ログインボタンクリック
            login_button = self.find_element_with_retry(self.selectors['login']['login_button'])
            if not login_button:
                logger.error("ログインボタンが見つかりませんでした")
                return False
                
            self.human_behavior.human_click(login_button)
            
            # 二段階認証が必要な場合
            if twofa_code:
                self.human_behavior.random_wait(1, 3)
                twofa_field = self.find_element_with_retry(self.selectors['login']['2fa_field'])
                if twofa_field:
                    self.human_behavior.human_type(twofa_field, twofa_code)
                    self.human_behavior.random_wait(0.5, 1)
                    
                    # 確認ボタンを探して押す（セレクタは実際のプラットフォームに合わせて調整が必要）
                    confirm_button = self.find_element_with_retry({
                        'xpath': '//button[contains(text(), "Confirm") or contains(text(), "Verify")]',
                        'css': 'button.confirm-btn, button.verify-btn'
                    })
                    if confirm_button:
                        self.human_behavior.human_click(confirm_button)
            
            # ログイン成功の確認（取引ページへのリダイレクトなど）
            self.human_behavior.random_wait(2, 4)
            
            # 取引リンクが表示されているかチェック
            trading_link = self.find_element_with_retry(self.selectors['navigation']['trading_link'])
            if trading_link:
                logger.info("ログインに成功しました")
                self.is_logged_in = True
                self.last_action_time = time.time()
                return True
            else:
                logger.error("ログインに失敗しました")
                return False
                
        except Exception as e:
            logger.error(f"ログイン中にエラーが発生しました: {str(e)}")
            return False
    
    def logout(self):
        """
        ブビンガプラットフォームからログアウトする
        
        Returns:
            bool: ログアウト成功時はTrue、失敗時はFalse
        """
        if not self.is_logged_in:
            logger.info("既にログアウト状態です")
            return True
            
        try:
            # ログアウトボタンを探す
            logout_button = self.find_element_with_retry(self.selectors['navigation']['logout_button'])
            if not logout_button:
                logger.error("ログアウトボタンが見つかりませんでした")
                return False
                
            # 人間らしくクリック
            self.human_behavior.human_click(logout_button)
            self.human_behavior.random_wait(1, 3)
            
            # ログアウト確認（ログインページにリダイレクトされたかなど）
            login_field = self.find_element_with_retry(self.selectors['login']['email_field'])
            if login_field:
                logger.info("ログアウトに成功しました")
                self.is_logged_in = False
                return True
            else:
                logger.error("ログアウトに失敗しました")
                return False
                
        except Exception as e:
            logger.error(f"ログアウト中にエラーが発生しました: {str(e)}")
            return False
    
    def navigate_to_trading(self):
        """
        取引ページに移動する
        
        Returns:
            bool: 移動成功時はTrue、失敗時はFalse
        """
        if not self.is_logged_in:
            logger.error("取引ページに移動するにはログインが必要です")
            return False
            
        try:
            # 取引リンクを探す
            trading_link = self.find_element_with_retry(self.selectors['navigation']['trading_link'])
            if not trading_link:
                # 直接URLにアクセス
                self.driver.get(self.trading_url)
            else:
                # 人間らしくクリック
                self.human_behavior.human_click(trading_link)
                
            self.human_behavior.random_wait(2, 4)
            
            # 取引ページの読み込み確認
            amount_field = self.find_element_with_retry(self.selectors['trading']['amount_field'])
            if amount_field:
                logger.info("取引ページへの移動に成功しました")
                return True
            else:
                logger.error("取引ページへの移動に失敗しました")
                return False
                
        except Exception as e:
            logger.error(f"取引ページへの移動中にエラーが発生しました: {str(e)}")
            return False
    
    def get_balance(self):
        """
        現在の口座残高を取得する
        
        Returns:
            float: 口座残高、取得失敗時は0.0
        """
        try:
            balance_element = self.find_element_with_retry(self.selectors['trading']['balance'])
            if not balance_element:
                logger.error("残高表示が見つかりませんでした")
                return 0.0
                
            balance_text = balance_element.text.strip()
            
            # 通貨記号や区切り文字を除去して数値に変換
            balance_text = ''.join(c for c in balance_text if c.isdigit() or c == '.' or c == ',')
            balance_text = balance_text.replace(',', '')
            
            balance = float(balance_text)
            self.current_balance = balance
            logger.info(f"現在の残高: {balance}")
            return balance
            
        except Exception as e:
            logger.error(f"残高取得中にエラーが発生しました: {str(e)}")
            return 0.0
    
    def select_asset(self, asset_name):
        """
        取引する資産を選択する
        
        Args:
            asset_name: 選択する資産の名前（例: "EUR/USD"）
            
        Returns:
            bool: 選択成功時はTrue、失敗時はFalse
        """
        try:
            # 資産選択ドロップダウンを開く
            asset_dropdown = self.find_element_with_retry(self.selectors['trading']['asset_dropdown'])
            if not asset_dropdown:
                logger.error("資産選択ドロップダウンが見つかりませんでした")
                return False
                
            self.human_behavior.human_click(asset_dropdown)
            self.human_behavior.random_wait(0.5, 1.5)
            
            # 検索フィールドがあれば使用
            asset_search = self.find_element_with_retry(self.selectors['trading']['asset_search'])
            if asset_search:
                self.human_behavior.human_type(asset_search, asset_name)
                self.human_behavior.random_wait(0.5, 1.5)
            
            # 資産リストから選択
            asset_items = self.driver.find_elements(By.XPATH, self.selectors['trading']['asset_list']['xpath'])
            if not asset_items:
                asset_items = self.driver.find_elements(By.CSS_SELECTOR, self.selectors['trading']['asset_list']['css'])
                
            if not asset_items:
                logger.error("資産リストが見つかりませんでした")
                return False
                
            # 指定された資産名と一致する項目を探す
            for item in asset_items:
                if asset_name in item.text:
                    self.human_behavior.human_click(item)
                    logger.info(f"資産を選択しました: {asset_name}")
                    self.human_behavior.random_wait(0.5, 1.5)
                    return True
                    
            logger.error(f"指定された資産が見つかりませんでした: {asset_name}")
            return False
            
        except Exception as e:
            logger.error(f"資産選択中にエラーが発生しました: {str(e)}")
            return False
    
    def set_amount(self, amount):
        """
        取引金額を設定する
        
        Args:
            amount: 設定する金額（数値）
            
        Returns:
            bool: 設定成功時はTrue、失敗時はFalse
        """
        try:
            amount_field = self.find_element_with_retry(self.selectors['trading']['amount_field'])
            if not amount_field:
                logger.error("金額入力フィールドが見つかりませんでした")
                return False
                
            # 既存の値をクリア
            amount_field.clear()
            self.human_behavior.random_wait(0.3, 0.8)
            
            # 新しい金額を入力
            self.human_behavior.human_type(amount_field, str(amount))
            logger.info(f"取引金額を設定しました: {amount}")
            return True
            
        except Exception as e:
            logger.error(f"金額設定中にエラーが発生しました: {str(e)}")
            return False
    
    def select_time(self, time_value):
        """
        取引時間を選択する
        
        Args:
            time_value: 選択する時間（例: "1m", "5m", "15m"）
            
        Returns:
            bool: 選択成功時はTrue、失敗時はFalse
        """
        try:
            # 時間選択ドロップダウンを開く
            time_selector = self.find_element_with_retry(self.selectors['trading']['time_selector'])
            if not time_selector:
                logger.error("時間選択ドロップダウンが見つかりませんでした")
                return False
                
            self.human_behavior.human_click(time_selector)
            self.human_behavior.random_wait(0.5, 1.5)
            
            # 時間オプションから選択
            time_options = self.driver.find_elements(By.XPATH, self.selectors['trading']['time_options']['xpath'])
            if not time_options:
                time_options = self.driver.find_elements(By.CSS_SELECTOR, self.selectors['trading']['time_options']['css'])
                
            if not time_options:
                logger.error("時間オプションが見つかりませんでした")
                return False
                
            # 指定された時間と一致するオプションを探す
            for option in time_options:
                if time_value in option.text:
                    self.human_behavior.human_click(option)
                    logger.info(f"取引時間を選択しました: {time_value}")
                    self.human_behavior.random_wait(0.5, 1.5)
                    return True
                    
            logger.error(f"指定された時間オプションが見つかりませんでした: {time_value}")
            return False
            
        except Exception as e:
            logger.error(f"時間選択中にエラーが発生しました: {str(e)}")
            return False
    
    def place_trade(self, direction):
        """
        取引を実行する
        
        Args:
            direction: 取引方向（"high"または"low"）
            
        Returns:
            bool: 取引実行成功時はTrue、失敗時はFalse
        """
        try:
            # 方向ボタンを選択
            if direction.lower() == "high":
                direction_button = self.find_element_with_retry(self.selectors['trading']['high_button'])
                button_name = "HIGH"
            elif direction.lower() == "low":
                direction_button = self.find_element_with_retry(self.selectors['trading']['low_button'])
                button_name = "LOW"
            else:
                logger.error(f"無効な取引方向です: {direction}")
                return False
                
            if not direction_button:
                logger.error(f"{button_name}ボタンが見つかりませんでした")
                return False
                
            # 方向ボタンをクリック
            self.human_behavior.human_click(direction_button)
            self.human_behavior.random_wait(0.5, 1.5)
            
            # 確認ボタンがあれば押す
            confirm_button = self.find_element_with_retry(self.selectors['trading']['confirm_button'])
            if confirm_button:
                self.human_behavior.human_click(confirm_button)
                logger.info(f"{button_name}方向の取引を実行しました")
                self.human_behavior.random_wait(1, 3)
                return True
            else:
                logger.info(f"{button_name}方向の取引を実行しました（確認ボタンなし）")
                return True
                
        except Exception as e:
            logger.error(f"取引実行中にエラーが発生しました: {str(e)}")
            return False
    
    def execute_trade(self, asset_name, amount, time_value, direction):
        """
        一連の取引操作を実行する
        
        Args:
            asset_name: 取引する資産名（例: "EUR/USD"）
            amount: 取引金額
            time_value: 取引時間（例: "1m", "5m"）
            direction: 取引方向（"high"または"low"）
            
        Returns:
            bool: 取引成功時はTrue、失敗時はFalse
        """
        # 取引ページに移動
        if not self.navigate_to_trading():
            return False
            
        # 資産を選択
        if not self.select_asset(asset_name):
            return False
            
        # 金額を設定
        if not self.set_amount(amount):
            return False
            
        # 時間を選択
        if not self.select_time(time_value):
            return False
            
        # 取引を実行
        if not self.place_trade(direction):
            return False
            
        logger.info(f"取引を実行しました: {asset_name}, {amount}, {time_value}, {direction}")
        self.last_action_time = time.time()
        return True
    
    def is_session_active(self, max_idle_time=1800):
        """
        セッションがアクティブかどうかを確認する
        
        Args:
            max_idle_time: 最大アイドル時間（秒）、デフォルトは30分
            
        Returns:
            bool: セッションがアクティブな場合はTrue、タイムアウトした場合はFalse
        """
        if not self.is_logged_in:
            return False
            
        current_time = time.time()
        idle_time = current_time - self.last_action_time
        
        if idle_time > max_idle_time:
            logger.info(f"セッションがタイムアウトしました: {idle_time:.0f}秒間アイドル状態")
            self.is_logged_in = False
            return False
            
        return True
    
    def refresh_session(self):
        """
        セッションを更新する（ページをリフレッシュ）
        
        Returns:
            bool: 更新成功時はTrue、失敗時はFalse
        """
        if not self.is_logged_in:
            logger.error("セッション更新にはログインが必要です")
            return False
            
        try:
            # ページをリフレッシュ
            self.driver.refresh()
            self.human_behavior.random_wait(2, 4)
            
            # セッションが維持されているか確認
            if self.navigate_to_trading():
                logger.info("セッションを更新しました")
                self.last_action_time = time.time()
                return True
            else:
                logger.error("セッション更新に失敗しました")
                self.is_logged_in = False
                return False
                
        except Exception as e:
            logger.error(f"セッション更新中にエラーが発生しました: {str(e)}")
            return False
    
    def scheduled_login_logout(self, credentials, trading_hours):
        """
        取引時間に基づいて自動的にログイン/ログアウトする
        
        Args:
            credentials: ログイン認証情報を含む辞書（email, password, twofa_code）
            trading_hours: 取引時間を含む辞書（start, end）、時刻は"HH:MM"形式
            
        Returns:
            bool: 操作成功時はTrue、失敗時はFalse
        """
        # 現在時刻を取得
        current_time = time.strftime("%H:%M")
        
        # 取引時間内かどうかを確認
        is_trading_hours = trading_hours['start'] <= current_time <= trading_hours['end']
        
        if is_trading_hours and not self.is_logged_in:
            # 取引時間内でログインしていない場合はログイン
            logger.info("取引時間内のため、ログインします")
            return self.login(
                credentials.get('email', ''),
                credentials.get('password', ''),
                credentials.get('twofa_code')
            )
        elif not is_trading_hours and self.is_logged_in:
            # 取引時間外でログインしている場合はログアウト
            logger.info("取引時間外のため、ログアウトします")
            return self.logout()
            
        return True
    
    def update_selectors(self, new_selectors):
        """
        要素セレクタを更新する
        
        Args:
            new_selectors: 新しいセレクタ情報を含む辞書
            
        Returns:
            dict: 更新後のセレクタ辞書
        """
        # 再帰的に辞書をマージ
        def merge_dicts(d1, d2):
            for k, v in d2.items():
                if k in d1 and isinstance(d1[k], dict) and isinstance(v, dict):
                    merge_dicts(d1[k], v)
                else:
                    d1[k] = v
            return d1
            
        self.selectors = merge_dicts(self.selectors, new_selectors)
        logger.info("要素セレクタを更新しました")
        return self.selectors
