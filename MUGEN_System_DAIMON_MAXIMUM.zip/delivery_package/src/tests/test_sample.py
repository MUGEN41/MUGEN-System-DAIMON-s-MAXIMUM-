#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System 統合版 - サンプルテスト
基本的なテスト構造と実行方法を示すサンプル
"""

import unittest
import pytest


class TestSample(unittest.TestCase):
    """サンプルテストクラス"""

    def setUp(self):
        """各テスト前の準備"""
        self.test_value = 100

    def test_basic_assertion(self):
        """基本的なアサーションのテスト"""
        self.assertEqual(100, self.test_value)
        self.assertTrue(self.test_value > 0)
        self.assertFalse(self.test_value < 0)

    def test_calculation(self):
        """計算機能のテスト"""
        result = self.test_value * 0.01  # 1%計算
        self.assertEqual(1.0, result)


@pytest.fixture
def sample_account_balance():
    """テスト用の口座残高を提供するフィクスチャ"""
    return 100000


def test_entry_amount_calculation(sample_account_balance):
    """pytestスタイルでのエントリー金額計算テスト"""
    # 実際の実装では、この関数は別モジュールからインポートされる
    def calculate_entry_amount(balance, percentage=0.01):
        return round(balance * percentage / 10) * 10

    result = calculate_entry_amount(sample_account_balance)
    assert result == 1000
    assert result == sample_account_balance * 0.01


if __name__ == "__main__":
    unittest.main()
