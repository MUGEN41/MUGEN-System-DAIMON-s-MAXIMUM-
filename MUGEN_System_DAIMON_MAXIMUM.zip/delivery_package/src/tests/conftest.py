import sys
import os
from pathlib import Path

# プロジェクトルートディレクトリをPYTHONPATHに追加
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

# srcディレクトリをPYTHONPATHに追加
src_path = Path(__file__).parent.parent
sys.path.insert(0, str(src_path))
