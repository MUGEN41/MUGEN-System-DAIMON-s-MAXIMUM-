#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System (DAIMON's MAXIMUM) - 50種類のロジック選択システム
勝率80%以上を実現するための50種類のロジックを管理・選択するモジュール
"""

import os
import sys
import json
import time
import random
import logging
import datetime as dt
import numpy as np
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("logic_selector.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Logic_Selector")

class LogicSelector:
    """
    ロジック選択システムクラス
    勝率80%以上を実現するための50種類のロジックを管理・選択する
    """
    
    def __init__(self, config_path: str = "config/logic_selector_config.json"):
        """
        初期化
        
        Args:
            config_path: 設定ファイルのパス
        """
        self.config_path = Path(config_path)
        self.config_dir = self.config_path.parent
        self.config: Dict[str, Any] = {}
        self.logic_stats: Dict[str, Dict[str, Any]] = {}
        self.locked_logics: Dict[str, Dict[str, Any]] = {}
        self._ensure_config_dir()
        self._load_config()
        self._load_logic_stats()
        self._load_locked_logics()
    
    def _ensure_config_dir(self) -> None:
        """設定ディレクトリが存在することを確認"""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)
            logger.info(f"設定ディレクトリを作成しました: {self.config_dir}")
    
    def _load_config(self) -> None:
        """設定ファイルを読み込む"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info("ロジック選択システム設定を読み込みました")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
                self.config = {}
        else:
            logger.info("設定ファイルが存在しないため、新規作成します")
            # 初期設定
            self.config = {
                "min_win_rate": 0.8,  # 最低勝率
                "min_trades_for_evaluation": 20,  # 評価に必要な最小取引数
                "lock_duration_hours": 24,  # ロック期間（時間）
                "max_lock_count": 2,  # 最大ロック回数
                "consecutive_losses_for_lock": 5,  # ロックするための連続敗北数
                "timeframes": ["1m", "3m", "5m", "15m", "1h", "4h", "1d"],  # 対応する時間枠
                "currency_pairs": ["USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "CADJPY", "CHFJPY", "EURUSD", "GBPUSD"],  # 対応する通貨ペア
                "logic_modules": {
                    "trend_following": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "mean_reversion": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "breakout": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "pattern_recognition": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "oscillator": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "momentum": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "volume_analysis": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "sentiment_analysis": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "fundamental_analysis": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "multi_timeframe": {
                        "enabled": True,
                        "weight": 1.0
                    }
                },
                "last_updated": dt.datetime.now().isoformat()
            }
            self._save_config()
            self._generate_initial_logics()
    
    def _save_config(self) -> None:
        """設定ファイルを保存する"""
        try:
            # 更新日時を記録
            self.config["last_updated"] = dt.datetime.now().isoformat()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("ロジック選択システム設定を保存しました")
        except Exception as e:
            logger.error(f"設定ファイルの保存に失敗しました: {e}")
    
    def _generate_initial_logics(self) -> None:
        """初期ロジックを生成する"""
        try:
            logics = []
            logic_modules = self.config.get("logic_modules", {})
            timeframes = self.config.get("timeframes", ["1m", "3m", "5m", "15m", "1h", "4h", "1d"])
            currency_pairs = self.config.get("currency_pairs", ["USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "CADJPY", "CHFJPY", "EURUSD", "GBPUSD"])
            
            # 各モジュールタイプごとに5つのロジックを生成
            for module_type, module_config in logic_modules.items():
                if module_config.get("enabled", True):
                    for i in range(5):
                        logic_id = f"{module_type}_{i+1}"
                        logic = {
                            "id": logic_id,
                            "name": f"{module_type.replace('_', ' ').title()} Logic {i+1}",
                            "type": module_type,
                            "description": f"{module_type.replace('_', ' ').title()} based trading logic #{i+1}",
                            "parameters": self._generate_random_parameters(module_type),
                            "timeframes": random.sample(timeframes, min(3, len(timeframes))),
                            "currency_pairs": random.sample(currency_pairs, min(5, len(currency_pairs))),
                            "win_rate": 0.8 + random.uniform(0.0, 0.15),  # 初期勝率は80%〜95%
                            "trades": 0,
                            "wins": 0,
                            "losses": 0,
                            "consecutive_wins": 0,
                            "consecutive_losses": 0,
                            "max_consecutive_wins": 0,
                            "max_consecutive_losses": 0,
                            "created_at": dt.datetime.now().isoformat(),
                            "last_used": None,
                            "last_updated": dt.datetime.now().isoformat()
                        }
                        logics.append(logic)
            
            # ロジック統計情報を保存
            self.logic_stats = {logic["id"]: logic for logic in logics}
            self._save_logic_stats()
            
            logger.info(f"{len(logics)}個の初期ロジックを生成しました")
        except Exception as e:
            logger.error(f"初期ロジックの生成に失敗しました: {e}")
    
    def _generate_random_parameters(self, module_type: str) -> Dict[str, Any]:
        """
        モジュールタイプに応じたランダムなパラメータを生成する
        
        Args:
            module_type: モジュールタイプ
        
        Returns:
            Dict[str, Any]: ランダムなパラメータ
        """
        if module_type == "trend_following":
            return {
                "ma_type": random.choice(["simple", "exponential", "weighted"]),
                "fast_period": random.randint(5, 20),
                "slow_period": random.randint(21, 50),
                "signal_period": random.randint(5, 15),
                "threshold": random.uniform(0.0, 0.5)
            }
        elif module_type == "mean_reversion":
            return {
                "lookback_period": random.randint(10, 30),
                "std_dev_multiplier": random.uniform(1.5, 3.0),
                "exit_threshold": random.uniform(0.3, 0.7)
            }
        elif module_type == "breakout":
            return {
                "channel_period": random.randint(10, 40),
                "breakout_threshold": random.uniform(0.5, 2.0),
                "confirmation_candles": random.randint(1, 3)
            }
        elif module_type == "pattern_recognition":
            return {
                "pattern_types": random.sample(["doji", "hammer", "engulfing", "morning_star", "evening_star"], random.randint(2, 5)),
                "confirmation_period": random.randint(1, 5),
                "min_pattern_size": random.uniform(0.1, 0.5)
            }
        elif module_type == "oscillator":
            return {
                "oscillator_type": random.choice(["rsi", "stochastic", "cci", "williams_r"]),
                "period": random.randint(7, 25),
                "overbought_level": random.randint(70, 85),
                "oversold_level": random.randint(15, 30)
            }
        elif module_type == "momentum":
            return {
                "momentum_indicator": random.choice(["macd", "roc", "awesome_oscillator", "ultimate_oscillator"]),
                "fast_period": random.randint(5, 15),
                "slow_period": random.randint(16, 30),
                "signal_threshold": random.uniform(0.0, 0.3)
            }
        elif module_type == "volume_analysis":
            return {
                "volume_indicators": random.sample(["obv", "volume_roc", "volume_oscillator", "money_flow_index"], random.randint(1, 4)),
                "volume_threshold": random.uniform(1.2, 2.5),
                "price_volume_correlation": random.choice([True, False])
            }
        elif module_type == "sentiment_analysis":
            return {
                "sentiment_sources": random.sample(["news", "social_media", "market_positioning", "cot_report"], random.randint(1, 4)),
                "sentiment_threshold": random.uniform(0.6, 0.9),
                "sentiment_period": random.randint(1, 7)
            }
        elif module_type == "fundamental_analysis":
            return {
                "economic_indicators": random.sample(["gdp", "inflation", "interest_rates", "employment", "trade_balance"], random.randint(2, 5)),
                "forecast_deviation_threshold": random.uniform(0.1, 0.5),
                "news_impact_period": random.randint(1, 24)
            }
        elif module_type == "multi_timeframe":
            return {
                "primary_timeframe": random.choice(["1m", "3m", "5m", "15m"]),
                "secondary_timeframes": random.sample(["15m", "1h", "4h", "1d"], random.randint(1, 3)),
                "alignment_required": random.choice([True, False]),
                "confirmation_weight": random.uniform(0.5, 1.0)
            }
        else:
            return {}
    
    def _load_logic_stats(self) -> None:
        """ロジック統計情報を読み込む"""
        stats_path = self.config_dir / "logic_stats.json"
        
        if stats_path.exists():
            try:
                with open(stats_path, 'r', encoding='utf-8') as f:
                    self.logic_stats = json.load(f)
                logger.info(f"{len(self.logic_stats)}個のロジック統計情報を読み込みました")
            except Exception as e:
                logger.error(f"ロジック統計情報の読み込みに失敗しました: {e}")
                self.logic_stats = {}
        else:
            logger.info("ロジック統計情報が存在しないため、新規作成します")
            self.logic_stats = {}
    
    def _save_logic_stats(self) -> None:
        """ロジック統計情報を保存する"""
        try:
            stats_path = self.config_dir / "logic_stats.json"
            
            with open(stats_path, 'w', encoding='utf-8') as f:
                json.dump(self.logic_stats, f, indent=4, ensure_ascii=False)
            logger.info(f"{len(self.logic_stats)}個のロジック統計情報を保存しました")
        except Exception as e:
            logger.error(f"ロジック統計情報の保存に失敗しました: {e}")
    
    def _load_locked_logics(self) -> None:
        """ロックされたロジック情報を読み込む"""
        locked_path = self.config_dir / "locked_logics.json"
        
        if locked_path.exists():
            try:
                with open(locked_path, 'r', encoding='utf-8') as f:
                    self.locked_logics = json.load(f)
                logger.info(f"{len(self.locked_logics)}個のロックされたロジック情報を読み込みました")
            except Exception as e:
                logger.error(f"ロックされたロジック情報の読み込みに失敗しました: {e}")
                self.locked_logics = {}
        else:
            logger.info("ロックされたロジック情報が存在しないため、新規作成します")
            self.locked_logics = {}
    
    def _save_locked_logics(self) -> None:
        """ロックされたロジック情報を保存する"""
        try:
            locked_path = self.config_dir / "locked_logics.json"
            
            with open(locked_path, 'w', encoding='utf-8') as f:
                json.dump(self.locked_logics, f, indent=4, ensure_ascii=False)
            logger.info(f"{len(self.locked_logics)}個のロックされたロジック情報を保存しました")
        except Exception as e:
            logger.error(f"ロックされたロジック情報の保存に失敗しました: {e}")
    
    def select_logic(self, timeframe: str, currency_pair: str) -> Dict[str, Any]:
        """
        指定された時間枠と通貨ペアに適したロジックを選択する
        
        Args:
            timeframe: 時間枠
            currency_pair: 通貨ペア
        
        Returns:
            Dict[str, Any]: 選択されたロジック
        """
        # 有効なロジックをフィルタリング
        valid_logics = []
        min_win_rate = self.config.get("min_win_rate", 0.8)
        
        for logic_id, logic in self.logic_stats.items():
            # ロックされていないか確認
            if logic_id in self.locked_logics:
                lock_info = self.locked_logics[logic_id]
                lock_until = dt.datetime.fromisoformat(lock_info["lock_until"])
                if dt.datetime.now() < lock_until:
                    logger.info(f"ロジック {logic_id} はロックされています（解除: {lock_until}）")
                    continue
                else:
                    # ロック期間が終了したので、ロック情報から削除
                    logger.info(f"ロジック {logic_id} のロックが解除されました")
                    del self.locked_logics[logic_id]
                    self._save_locked_logics()
            
            # 時間枠と通貨ペアが一致するか確認
            if timeframe in logic.get("timeframes", []) and currency_pair in logic.get("currency_pairs", []):
                # 勝率が最低勝率以上か確認
                if logic.get("win_rate", 0.0) >= min_win_rate:
                    valid_logics.append(logic)
        
        if not valid_logics:
            logger.warning(f"条件に一致するロジックが見つかりませんでした: {timeframe}, {currency_pair}")
            # 条件を緩和して再検索
            for logic_id, logic in self.logic_stats.items():
                if logic_id not in self.locked_logics:
                    if timeframe in logic.get("timeframes", []) or currency_pair in logic.get("currency_pairs", []):
                        valid_logics.append(logic)
        
        if not valid_logics:
            logger.error(f"使用可能なロジックが見つかりませんでした: {timeframe}, {currency_pair}")
            return {}
        
        # 勝率に基づいて重み付けを行い、ランダムに選択
        weights = [logic.get("win_rate", 0.5) ** 2 for logic in valid_logics]  # 勝率の2乗で重み付け
        total_weight = sum(weights)
        normalized_weights = [w / total_weight for w in weights]
        
        selected_logic = random.choices(valid_logics, weights=normalized_weights, k=1)[0]
        
        # 最終使用日時を更新
        selected_logic["last_used"] = dt.datetime.now().isoformat()
        self.logic_stats[selected_logic["id"]] = selected_logic
        self._save_logic_stats()
        
        logger.info(f"ロジックを選択しました: {selected_logic['id']}, 勝率: {selected_logic['win_rate']:.2f}")
        
        return selected_logic
    
    def record_logic_result(self, logic_id: str, result: str) -> None:
        """
        ロジックの結果を記録する
        
        Args:
            logic_id: ロジックID
            result: 結果（"win" または "loss"）
        """
        if logic_id not in self.logic_stats:
            logger.error(f"未知のロジックID: {logic_id}")
            return
        
        logic = self.logic_stats[logic_id]
        
        # 取引数と勝敗数を更新
        logic["trades"] = logic.get("trades", 0) + 1
        
        if result == "win":
            logic["wins"] = logic.get("wins", 0) + 1
            logic["consecutive_wins"] = logic.get("consecutive_wins", 0) + 1
            logic["consecutive_losses"] = 0
            logic["max_consecutive_wins"] = max(logic.get("max_consecutive_wins", 0), logic["consecutive_wins"])
        else:
            logic["losses"] = logic.get("losses", 0) + 1
            logic["consecutive_losses"] = logic.get("consecutive_losses", 0) + 1
            logic["consecutive_wins"] = 0
            logic["max_consecutive_losses"] = max(logic.get("max_consecutive_losses", 0), logic["consecutive_losses"])
        
        # 勝率を更新
        if logic["trades"] > 0:
            logic["win_rate"] = logic["wins"] / logic["trades"]
        
        # 最終更新日時を更新
        logic["last_updated"] = dt.datetime.now().isoformat()
        
        # 連続敗北によるロック
        consecutive_losses_for_lock = self.config.get("consecutive_losses_for_lock", 5)
        if logic["consecutive_losses"] >= consecutive_losses_for_lock:
            self.lock_logic(logic_id)
        
        # 統計情報を保存
        self.logic_stats[logic_id] = logic
        self._save_logic_stats()
        
        logger.info(f"ロジック {logic_id} の結果を記録しました: {result}, 勝率: {logic['win_rate']:.2f}")
    
    def lock_logic(self, logic_id: str) -> bool:
        """
        ロジックをロックする
        
        Args:
            logic_id: ロジックID
        
        Returns:
            bool: ロック成功かどうか
        """
        if logic_id not in self.logic_stats:
            logger.error(f"未知のロジックID: {logic_id}")
            return False
        
        # 既にロックされているか確認
        if logic_id in self.locked_logics:
            lock_info = self.locked_logics[logic_id]
            lock_count = lock_info.get("lock_count", 1)
            max_lock_count = self.config.get("max_lock_count", 2)
            
            if lock_count >= max_lock_count:
                logger.warning(f"ロジック {logic_id} は最大ロック回数に達しました。除外します。")
                # ロジックを除外（統計情報からは削除せず、ロック情報に永続的にマーク）
                lock_info["permanent_lock"] = True
                lock_info["lock_count"] = lock_count
                self.locked_logics[logic_id] = lock_info
                self._save_locked_logics()
                return True
            
            # ロック回数を増やす
            lock_count += 1
        else:
            lock_count = 1
        
        # ロック期間を設定
        lock_duration_hours = self.config.get("lock_duration_hours", 24)
        lock_until = dt.datetime.now() + dt.timedelta(hours=lock_duration_hours)
        
        # ロック情報を保存
        self.locked_logics[logic_id] = {
            "lock_until": lock_until.isoformat(),
            "lock_count": lock_count,
            "lock_reason": "consecutive_losses",
            "locked_at": dt.datetime.now().isoformat()
        }
        self._save_locked_logics()
        
        logger.info(f"ロジック {logic_id} をロックしました（解除: {lock_until}, 回数: {lock_count}）")
        
        return True
    
    def unlock_logic(self, logic_id: str) -> bool:
        """
        ロジックのロックを解除する
        
        Args:
            logic_id: ロジックID
        
        Returns:
            bool: ロック解除成功かどうか
        """
        if logic_id not in self.locked_logics:
            logger.warning(f"ロジック {logic_id} はロックされていません")
            return False
        
        lock_info = self.locked_logics[logic_id]
        
        # 永続的にロックされている場合は解除不可
        if lock_info.get("permanent_lock", False):
            logger.warning(f"ロジック {logic_id} は永続的にロックされています。解除できません。")
            return False
        
        # ロック情報から削除
        del self.locked_logics[logic_id]
        self._save_locked_logics()
        
        logger.info(f"ロジック {logic_id} のロックを解除しました")
        
        return True
    
    def get_logic_info(self, logic_id: str) -> Dict[str, Any]:
        """
        ロジック情報を取得する
        
        Args:
            logic_id: ロジックID
        
        Returns:
            Dict[str, Any]: ロジック情報
        """
        if logic_id not in self.logic_stats:
            logger.error(f"未知のロジックID: {logic_id}")
            return {}
        
        logic = self.logic_stats[logic_id]
        
        # ロック情報を追加
        if logic_id in self.locked_logics:
            lock_info = self.locked_logics[logic_id]
            logic["locked"] = True
            logic["lock_info"] = lock_info
        else:
            logic["locked"] = False
        
        return logic
    
    def get_all_logics(self) -> List[Dict[str, Any]]:
        """
        全てのロジック情報を取得する
        
        Returns:
            List[Dict[str, Any]]: 全てのロジック情報
        """
        logics = []
        
        for logic_id, logic in self.logic_stats.items():
            # ロック情報を追加
            if logic_id in self.locked_logics:
                lock_info = self.locked_logics[logic_id]
                logic["locked"] = True
                logic["lock_info"] = lock_info
            else:
                logic["locked"] = False
            
            logics.append(logic)
        
        return logics
    
    def get_best_logics(self, count: int = 10) -> List[Dict[str, Any]]:
        """
        勝率の高いロジックを取得する
        
        Args:
            count: 取得するロジック数
        
        Returns:
            List[Dict[str, Any]]: 勝率の高いロジック情報
        """
        # 最低取引数でフィルタリング
        min_trades = self.config.get("min_trades_for_evaluation", 20)
        valid_logics = [logic for logic in self.logic_stats.values() if logic.get("trades", 0) >= min_trades]
        
        # 勝率でソート
        sorted_logics = sorted(valid_logics, key=lambda x: x.get("win_rate", 0.0), reverse=True)
        
        # 上位のロジックを取得
        best_logics = sorted_logics[:count]
        
        # ロック情報を追加
        for logic in best_logics:
            logic_id = logic["id"]
            if logic_id in self.locked_logics:
                lock_info = self.locked_logics[logic_id]
                logic["locked"] = True
                logic["lock_info"] = lock_info
            else:
                logic["locked"] = False
        
        return best_logics
    
    def get_logic_stats_summary(self) -> Dict[str, Any]:
        """
        ロジック統計情報のサマリーを取得する
        
        Returns:
            Dict[str, Any]: ロジック統計情報のサマリー
        """
        total_logics = len(self.logic_stats)
        locked_logics = len(self.locked_logics)
        permanently_locked = sum(1 for info in self.locked_logics.values() if info.get("permanent_lock", False))
        
        # 有効なロジック（ロックされていないもの）
        active_logics = [logic for logic_id, logic in self.logic_stats.items() if logic_id not in self.locked_logics]
        
        # 勝率の統計
        win_rates = [logic.get("win_rate", 0.0) for logic in active_logics if logic.get("trades", 0) > 0]
        avg_win_rate = sum(win_rates) / len(win_rates) if win_rates else 0.0
        min_win_rate = min(win_rates) if win_rates else 0.0
        max_win_rate = max(win_rates) if win_rates else 0.0
        
        # 時間枠ごとのロジック数
        timeframes = self.config.get("timeframes", [])
        timeframe_counts = {tf: sum(1 for logic in active_logics if tf in logic.get("timeframes", [])) for tf in timeframes}
        
        # 通貨ペアごとのロジック数
        currency_pairs = self.config.get("currency_pairs", [])
        pair_counts = {pair: sum(1 for logic in active_logics if pair in logic.get("currency_pairs", [])) for pair in currency_pairs}
        
        # モジュールタイプごとのロジック数
        module_types = list(self.config.get("logic_modules", {}).keys())
        type_counts = {type_: sum(1 for logic in active_logics if logic.get("type") == type_) for type_ in module_types}
        
        return {
            "total_logics": total_logics,
            "active_logics": len(active_logics),
            "locked_logics": locked_logics,
            "permanently_locked": permanently_locked,
            "win_rate_stats": {
                "average": avg_win_rate,
                "minimum": min_win_rate,
                "maximum": max_win_rate
            },
            "timeframe_counts": timeframe_counts,
            "currency_pair_counts": pair_counts,
            "module_type_counts": type_counts,
            "timestamp": dt.datetime.now().isoformat()
        }
