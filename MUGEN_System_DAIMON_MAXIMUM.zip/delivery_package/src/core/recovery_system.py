#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System (DAIMON's MAXIMUM) - 自動処理再開機能
システムが停止した場合に自動的に処理を再開するモジュール
"""

import os
import sys
import json
import time
import logging
import datetime as dt
import traceback
import signal
import pickle
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple, Callable

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("recovery_system.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Recovery_System")

class RecoverySystem:
    """
    自動処理再開システムクラス
    システムが停止した場合に自動的に処理を再開する
    """
    
    def __init__(self, config_path: str = "config/recovery_system_config.json"):
        """
        初期化
        
        Args:
            config_path: 設定ファイルのパス
        """
        self.config_path = Path(config_path)
        self.config_dir = self.config_path.parent
        self.config: Dict[str, Any] = {}
        self.checkpoint_dir = Path("checkpoints")
        self.active_processes: Dict[str, Dict[str, Any]] = {}
        self._ensure_config_dir()
        self._ensure_checkpoint_dir()
        self._load_config()
        self._load_active_processes()
        self._setup_signal_handlers()
    
    def _ensure_config_dir(self) -> None:
        """設定ディレクトリが存在することを確認"""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)
            logger.info(f"設定ディレクトリを作成しました: {self.config_dir}")
    
    def _ensure_checkpoint_dir(self) -> None:
        """チェックポイントディレクトリが存在することを確認"""
        if not self.checkpoint_dir.exists():
            self.checkpoint_dir.mkdir(parents=True)
            logger.info(f"チェックポイントディレクトリを作成しました: {self.checkpoint_dir}")
    
    def _load_config(self) -> None:
        """設定ファイルを読み込む"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info("自動処理再開システム設定を読み込みました")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
                self.config = {}
        else:
            logger.info("設定ファイルが存在しないため、新規作成します")
            # 初期設定
            self.config = {
                "enabled": True,
                "checkpoint_interval": 300,  # チェックポイント作成間隔（秒）
                "max_retry_attempts": 5,  # 最大再試行回数
                "retry_delay": 60,  # 再試行間隔（秒）
                "retry_backoff_factor": 2.0,  # 再試行間隔の増加係数
                "max_retry_delay": 3600,  # 最大再試行間隔（秒）
                "critical_processes": [
                    "trading_loop",
                    "data_collection",
                    "model_training"
                ],
                "notification_on_recovery": True,  # 復旧時に通知するかどうか
                "cleanup_old_checkpoints": True,  # 古いチェックポイントを削除するかどうか
                "max_checkpoint_age_days": 7,  # チェックポイントの最大保存期間（日）
                "last_updated": dt.datetime.now().isoformat()
            }
            self._save_config()
    
    def _save_config(self) -> None:
        """設定ファイルを保存する"""
        try:
            # 更新日時を記録
            self.config["last_updated"] = dt.datetime.now().isoformat()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("自動処理再開システム設定を保存しました")
        except Exception as e:
            logger.error(f"設定ファイルの保存に失敗しました: {e}")
    
    def _load_active_processes(self) -> None:
        """アクティブなプロセス情報を読み込む"""
        active_processes_path = self.config_dir / "active_processes.json"
        
        if active_processes_path.exists():
            try:
                with open(active_processes_path, 'r', encoding='utf-8') as f:
                    self.active_processes = json.load(f)
                logger.info(f"{len(self.active_processes)}個のアクティブなプロセス情報を読み込みました")
            except Exception as e:
                logger.error(f"アクティブなプロセス情報の読み込みに失敗しました: {e}")
                self.active_processes = {}
        else:
            logger.info("アクティブなプロセス情報が存在しないため、新規作成します")
            self.active_processes = {}
    
    def _save_active_processes(self) -> None:
        """アクティブなプロセス情報を保存する"""
        try:
            active_processes_path = self.config_dir / "active_processes.json"
            
            with open(active_processes_path, 'w', encoding='utf-8') as f:
                json.dump(self.active_processes, f, indent=4, ensure_ascii=False)
            logger.info(f"{len(self.active_processes)}個のアクティブなプロセス情報を保存しました")
        except Exception as e:
            logger.error(f"アクティブなプロセス情報の保存に失敗しました: {e}")
    
    def _setup_signal_handlers(self) -> None:
        """シグナルハンドラを設定する"""
        try:
            # SIGTERMとSIGINTのハンドラを設定
            signal.signal(signal.SIGTERM, self._signal_handler)
            signal.signal(signal.SIGINT, self._signal_handler)
            logger.info("シグナルハンドラを設定しました")
        except Exception as e:
            logger.error(f"シグナルハンドラの設定に失敗しました: {e}")
    
    def _signal_handler(self, sig, frame) -> None:
        """
        シグナルハンドラ
        
        Args:
            sig: シグナル番号
            frame: 現在のスタックフレーム
        """
        signal_name = "UNKNOWN"
        if sig == signal.SIGTERM:
            signal_name = "SIGTERM"
        elif sig == signal.SIGINT:
            signal_name = "SIGINT"
        
        logger.warning(f"シグナル {signal_name} を受信しました。チェックポイントを作成して終了します。")
        
        # 全てのアクティブなプロセスのチェックポイントを作成
        for process_id in list(self.active_processes.keys()):
            self.create_checkpoint(process_id)
        
        # 終了
        sys.exit(0)
    
    def register_process(self, process_id: str, process_type: str, recovery_function: Callable, initial_state: Dict[str, Any] = None) -> str:
        """
        プロセスを登録する
        
        Args:
            process_id: プロセスID
            process_type: プロセスタイプ
            recovery_function: 復旧関数
            initial_state: 初期状態
        
        Returns:
            str: 登録されたプロセスID
        """
        if not self.config.get("enabled", True):
            logger.warning("自動処理再開システムが無効になっています")
            return process_id
        
        # プロセス情報を作成
        process_info = {
            "id": process_id,
            "type": process_type,
            "recovery_function": recovery_function.__name__,
            "recovery_module": recovery_function.__module__,
            "state": initial_state or {},
            "status": "active",
            "start_time": dt.datetime.now().isoformat(),
            "last_checkpoint": None,
            "retry_count": 0,
            "last_error": None
        }
        
        # アクティブなプロセスに追加
        self.active_processes[process_id] = process_info
        self._save_active_processes()
        
        logger.info(f"プロセス {process_id} を登録しました（タイプ: {process_type}）")
        
        return process_id
    
    def update_process_state(self, process_id: str, state: Dict[str, Any]) -> bool:
        """
        プロセスの状態を更新する
        
        Args:
            process_id: プロセスID
            state: 状態
        
        Returns:
            bool: 更新成功かどうか
        """
        if not self.config.get("enabled", True):
            return False
        
        if process_id not in self.active_processes:
            logger.error(f"未知のプロセスID: {process_id}")
            return False
        
        # 状態を更新
        self.active_processes[process_id]["state"] = state
        self._save_active_processes()
        
        # チェックポイント作成間隔を確認
        checkpoint_interval = self.config.get("checkpoint_interval", 300)
        last_checkpoint = self.active_processes[process_id].get("last_checkpoint")
        
        if last_checkpoint:
            last_checkpoint_time = dt.datetime.fromisoformat(last_checkpoint)
            elapsed = (dt.datetime.now() - last_checkpoint_time).total_seconds()
            
            if elapsed >= checkpoint_interval:
                self.create_checkpoint(process_id)
        else:
            # 初回のチェックポイントを作成
            self.create_checkpoint(process_id)
        
        return True
    
    def create_checkpoint(self, process_id: str) -> bool:
        """
        チェックポイントを作成する
        
        Args:
            process_id: プロセスID
        
        Returns:
            bool: 作成成功かどうか
        """
        if not self.config.get("enabled", True):
            return False
        
        if process_id not in self.active_processes:
            logger.error(f"未知のプロセスID: {process_id}")
            return False
        
        try:
            process_info = self.active_processes[process_id]
            
            # チェックポイントファイル名を生成
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            checkpoint_file = self.checkpoint_dir / f"{process_id}_{timestamp}.checkpoint"
            
            # チェックポイントを保存
            with open(checkpoint_file, 'wb') as f:
                pickle.dump(process_info, f)
            
            # 最終チェックポイント時間を更新
            process_info["last_checkpoint"] = dt.datetime.now().isoformat()
            self.active_processes[process_id] = process_info
            self._save_active_processes()
            
            logger.info(f"プロセス {process_id} のチェックポイントを作成しました: {checkpoint_file}")
            
            # 古いチェックポイントを削除
            if self.config.get("cleanup_old_checkpoints", True):
                self._cleanup_old_checkpoints(process_id)
            
            return True
        except Exception as e:
            logger.error(f"チェックポイントの作成に失敗しました: {e}")
            return False
    
    def _cleanup_old_checkpoints(self, process_id: str) -> None:
        """
        古いチェックポイントを削除する
        
        Args:
            process_id: プロセスID
        """
        try:
            max_age_days = self.config.get("max_checkpoint_age_days", 7)
            cutoff_date = dt.datetime.now() - dt.timedelta(days=max_age_days)
            
            # プロセスIDに一致するチェックポイントファイルを検索
            checkpoint_files = list(self.checkpoint_dir.glob(f"{process_id}_*.checkpoint"))
            
            # 最新のチェックポイントを除外
            if checkpoint_files:
                checkpoint_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
                checkpoint_files = checkpoint_files[1:]  # 最新のものを除外
            
            # 古いチェックポイントを削除
            deleted_count = 0
            for file in checkpoint_files:
                file_time = dt.datetime.fromtimestamp(file.stat().st_mtime)
                if file_time < cutoff_date:
                    file.unlink()
                    deleted_count += 1
            
            if deleted_count > 0:
                logger.info(f"{deleted_count}個の古いチェックポイントを削除しました")
        except Exception as e:
            logger.error(f"古いチェックポイントの削除に失敗しました: {e}")
    
    def complete_process(self, process_id: str) -> bool:
        """
        プロセスを完了する
        
        Args:
            process_id: プロセスID
        
        Returns:
            bool: 完了成功かどうか
        """
        if process_id not in self.active_processes:
            logger.error(f"未知のプロセスID: {process_id}")
            return False
        
        try:
            # プロセス情報を削除
            del self.active_processes[process_id]
            self._save_active_processes()
            
            logger.info(f"プロセス {process_id} を完了しました")
            
            return True
        except Exception as e:
            logger.error(f"プロセスの完了に失敗しました: {e}")
            return False
    
    def recover_process(self, process_id: str) -> bool:
        """
        プロセスを復旧する
        
        Args:
            process_id: プロセスID
        
        Returns:
            bool: 復旧成功かどうか
        """
        if not self.config.get("enabled", True):
            logger.warning("自動処理再開システムが無効になっています")
            return False
        
        # 最新のチェックポイントを検索
        checkpoint_files = list(self.checkpoint_dir.glob(f"{process_id}_*.checkpoint"))
        
        if not checkpoint_files:
            logger.error(f"プロセス {process_id} のチェックポイントが見つかりません")
            return False
        
        # 最新のチェックポイントを取得
        checkpoint_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
        latest_checkpoint = checkpoint_files[0]
        
        try:
            # チェックポイントを読み込む
            with open(latest_checkpoint, 'rb') as f:
                process_info = pickle.load(f)
            
            # 復旧関数を取得
            recovery_function_name = process_info.get("recovery_function")
            recovery_module_name = process_info.get("recovery_module")
            
            if not recovery_function_name or not recovery_module_name:
                logger.error(f"復旧関数情報が不足しています: {process_id}")
                return False
            
            # 復旧関数をインポート
            try:
                module = __import__(recovery_module_name, fromlist=[recovery_function_name])
                recovery_function = getattr(module, recovery_function_name)
            except Exception as e:
                logger.error(f"復旧関数のインポートに失敗しました: {e}")
                return False
            
            # 再試行回数を更新
            process_info["retry_count"] += 1
            max_retry_attempts = self.config.get("max_retry_attempts", 5)
            
            if process_info["retry_count"] > max_retry_attempts:
                logger.error(f"プロセス {process_id} の最大再試行回数を超えました")
                process_info["status"] = "failed"
                self.active_processes[process_id] = process_info
                self._save_active_processes()
                return False
            
            # 再試行間隔を計算
            retry_delay = self.config.get("retry_delay", 60)
            retry_backoff_factor = self.config.get("retry_backoff_factor", 2.0)
            max_retry_delay = self.config.get("max_retry_delay", 3600)
            
            current_delay = min(retry_delay * (retry_backoff_factor ** (process_info["retry_count"] - 1)), max_retry_delay)
            
            logger.info(f"プロセス {process_id} の復旧を {current_delay}秒後に試みます（試行回数: {process_info['retry_count']}）")
            time.sleep(current_delay)
            
            # 復旧関数を実行
            try:
                recovery_function(process_info["state"])
                
                # 復旧成功
                process_info["status"] = "recovered"
                process_info["last_error"] = None
                self.active_processes[process_id] = process_info
                self._save_active_processes()
                
                logger.info(f"プロセス {process_id} の復旧に成功しました")
                
                # 復旧通知
                if self.config.get("notification_on_recovery", True):
                    self._send_recovery_notification(process_id)
                
                return True
            except Exception as e:
                # 復旧失敗
                error_message = str(e)
                stack_trace = traceback.format_exc()
                
                process_info["status"] = "recovery_failed"
                process_info["last_error"] = {
                    "message": error_message,
                    "stack_trace": stack_trace,
                    "timestamp": dt.datetime.now().isoformat()
                }
                self.active_processes[process_id] = process_info
                self._save_active_processes()
                
                logger.error(f"プロセス {process_id} の復旧に失敗しました: {error_message}")
                
                # 再帰的に再試行
                return self.recover_process(process_id)
        except Exception as e:
            logger.error(f"プロセスの復旧中にエラーが発生しました: {e}")
            return False
    
    def _send_recovery_notification(self, process_id: str) -> None:
        """
        復旧通知を送信する
        
        Args:
            process_id: プロセスID
        """
        try:
            process_info = self.active_processes.get(process_id, {})
            process_type = process_info.get("type", "unknown")
            retry_count = process_info.get("retry_count", 0)
            
            message = f"プロセス {process_id} ({process_type}) が復旧しました。試行回数: {retry_count}"
            logger.info(f"復旧通知: {message}")
            
            # TODO: 通知機能の実装（LINE、メールなど）
        except Exception as e:
            logger.error(f"復旧通知の送信に失敗しました: {e}")
    
    def check_and_recover_processes(self) -> Dict[str, bool]:
        """
        全てのプロセスをチェックし、必要に応じて復旧する
        
        Returns:
            Dict[str, bool]: プロセスIDと復旧結果のマップ
        """
        if not self.config.get("enabled", True):
            logger.warning("自動処理再開システムが無効になっています")
            return {}
        
        results = {}
        
        # アクティブなプロセスをチェック
        for process_id, process_info in list(self.active_processes.items()):
            if process_info.get("status") in ["failed", "recovery_failed"]:
                # 復旧を試みる
                result = self.recover_process(process_id)
                results[process_id] = result
        
        # チェックポイントディレクトリ内の全てのチェックポイントをチェック
        checkpoint_files = list(self.checkpoint_dir.glob("*.checkpoint"))
        
        for checkpoint_file in checkpoint_files:
            # プロセスIDを抽出
            file_name = checkpoint_file.stem
            if "_" in file_name:
                process_id = file_name.split("_")[0]
                
                # アクティブなプロセスに存在しない場合は復旧を試みる
                if process_id not in self.active_processes:
                    result = self.recover_process(process_id)
                    results[process_id] = result
        
        return results
    
    def get_process_info(self, process_id: str) -> Dict[str, Any]:
        """
        プロセス情報を取得する
        
        Args:
            process_id: プロセスID
        
        Returns:
            Dict[str, Any]: プロセス情報
        """
        if process_id not in self.active_processes:
            logger.error(f"未知のプロセスID: {process_id}")
            return {}
        
        return self.active_processes[process_id]
    
    def get_all_processes(self) -> Dict[str, Dict[str, Any]]:
        """
        全てのプロセス情報を取得する
        
        Returns:
            Dict[str, Dict[str, Any]]: 全てのプロセス情報
        """
        return self.active_processes
    
    def get_recovery_system_status(self) -> Dict[str, Any]:
        """
        自動処理再開システムの状態を取得する
        
        Returns:
            Dict[str, Any]: システムの状態
        """
        # チェックポイント数を計算
        checkpoint_files = list(self.checkpoint_dir.glob("*.checkpoint"))
        checkpoint_count = len(checkpoint_files)
        
        # プロセス状態の集計
        process_status_counts = {}
        for process_info in self.active_processes.values():
            status = process_info.get("status", "unknown")
            process_status_counts[status] = process_status_counts.get(status, 0) + 1
        
        # プロセスタイプの集計
        process_type_counts = {}
        for process_info in self.active_processes.values():
            process_type = process_info.get("type", "unknown")
            process_type_counts[process_type] = process_type_counts.get(process_type, 0) + 1
        
        return {
            "enabled": self.config.get("enabled", True),
            "active_processes": len(self.active_processes),
            "checkpoint_count": checkpoint_count,
            "process_status_counts": process_status_counts,
            "process_type_counts": process_type_counts,
            "config": self.config,
            "timestamp": dt.datetime.now().isoformat()
        }

# 使用例
if __name__ == "__main__":
    # 自動処理再開システムのインスタンスを作成
    recovery_system = RecoverySystem()
    
    # プロセスを登録
    def example_recovery_function(state):
        print(f"Recovering process with state: {state}")
    
    process_id = recovery_system.register_process(
        process_id="example_process",
        process_type="example",
        recovery_function=example_recovery_function,
        initial_state={"step": 0, "data": []}
    )
    
    # プロセスの状態を更新
    for i in range(5):
        state = {"step": i, "data": [j for j in range(i)]}
        recovery_system.update_process_state(process_id, state)
        time.sleep(1)
    
    # プロセスを完了
    recovery_system.complete_process(process_id)
    
    # 全てのプロセスをチェックして復旧
    recovery_system.check_and_recover_processes()
