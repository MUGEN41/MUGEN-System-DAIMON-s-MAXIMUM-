#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System (DAIMON's MAXIMUM) - システム統合モジュール
各機能モジュールを統合し、システム全体を制御するメインモジュール
"""

import os
import sys
import json
import time
import logging
import datetime as dt
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple

# 各モジュールのインポート
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from human_behavior.human_behavior_simulator import HumanBehaviorSimulator
from detection_avoidance.detection_avoidance_system import DetectionAvoidanceSystem
from trade_management.daily_trade_manager import DailyTradeManager
from browser_automation.browser_automation import BrowserAutomation

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("mugen_system.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("MUGEN_System")

class MugenSystem:
    """
    MUGEN System統合クラス
    各機能モジュールを統合し、システム全体を制御する
    """
    
    def __init__(self, config_path: str = "config/system_config.json"):
        """
        初期化
        
        Args:
            config_path: 設定ファイルのパス
        """
        self.config_path = Path(config_path)
        self.config_dir = self.config_path.parent
        self.config: Dict[str, Any] = {}
        
        # 各モジュールのインスタンス
        self.human_behavior = None
        self.detection_avoidance = None
        self.trade_manager = None
        self.browser_automation = None
        
        self._ensure_config_dir()
        self._load_config()
        self._initialize_modules()
    
    def _ensure_config_dir(self) -> None:
        """設定ディレクトリが存在することを確認"""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)
            logger.info(f"設定ディレクトリを作成しました: {self.config_dir}")
    
    def _load_config(self) -> None:
        """設定ファイルを読み込む"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info("システム設定を読み込みました")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
                self.config = {}
        else:
            logger.info("設定ファイルが存在しないため、新規作成します")
            # 初期設定
            self.config = {
                "system_name": "MUGEN System (DAIMON's MAXIMUM)",
                "version": "1.0.0",
                "target_platforms": ["the_option", "bi_winning"],
                "active_timeframes": ["1m", "3m", "5m", "15m", "1h", "4h", "1d"],
                "module_settings": {
                    "human_behavior": {
                        "enabled": True,
                        "config_path": "human_behavior/config/behavior_config.json"
                    },
                    "detection_avoidance": {
                        "enabled": True,
                        "config_path": "detection_avoidance/config/detection_avoidance_config.json"
                    },
                    "trade_management": {
                        "enabled": True,
                        "config_path": "trade_management/config/trade_rules_config.json"
                    },
                    "browser_automation": {
                        "enabled": True,
                        "config_path": "browser_automation/config/browser_automation_config.json",
                        "headless": False
                    }
                },
                "trading_settings": {
                    "initial_balance": 100000.0,
                    "target_balance": 100000000.0,  # 1億円
                    "daily_trade_target": 100,
                    "win_rate_target": 0.8,
                    "auto_stop_on_consecutive_losses": 5,
                    "notify_on_stop": True
                },
                "notification_settings": {
                    "line_notify": {
                        "enabled": True,
                        "token": ""
                    },
                    "email": {
                        "enabled": False,
                        "smtp_server": "",
                        "smtp_port": 587,
                        "username": "",
                        "password": "",
                        "recipient": ""
                    }
                },
                "last_updated": dt.datetime.now().isoformat()
            }
            self._save_config()
    
    def _save_config(self) -> None:
        """設定ファイルを保存する"""
        try:
            # 更新日時を記録
            self.config["last_updated"] = dt.datetime.now().isoformat()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("システム設定を保存しました")
        except Exception as e:
            logger.error(f"設定ファイルの保存に失敗しました: {e}")
    
    def _initialize_modules(self) -> None:
        """各モジュールを初期化する"""
        try:
            # 人間行動シミュレーションモジュール
            if self.config.get("module_settings", {}).get("human_behavior", {}).get("enabled", True):
                config_path = self.config.get("module_settings", {}).get("human_behavior", {}).get("config_path", "human_behavior/config/behavior_config.json")
                logger.info(f"人間行動シミュレーションモジュールを初期化します: {config_path}")
                self.human_behavior = HumanBehaviorSimulator(config_path=config_path)
            
            # 検知回避モジュール
            if self.config.get("module_settings", {}).get("detection_avoidance", {}).get("enabled", True):
                config_path = self.config.get("module_settings", {}).get("detection_avoidance", {}).get("config_path", "detection_avoidance/config/detection_avoidance_config.json")
                logger.info(f"検知回避モジュールを初期化します: {config_path}")
                self.detection_avoidance = DetectionAvoidanceSystem(config_path=config_path)
            
            # 取引管理モジュール
            if self.config.get("module_settings", {}).get("trade_management", {}).get("enabled", True):
                config_path = self.config.get("module_settings", {}).get("trade_management", {}).get("config_path", "trade_management/config/trade_rules_config.json")
                logger.info(f"取引管理モジュールを初期化します: {config_path}")
                self.trade_manager = DailyTradeManager(config_path=config_path)
            
            # ブラウザ自動操作モジュール
            if self.config.get("module_settings", {}).get("browser_automation", {}).get("enabled", True):
                config_path = self.config.get("module_settings", {}).get("browser_automation", {}).get("config_path", "browser_automation/config/browser_automation_config.json")
                headless = self.config.get("module_settings", {}).get("browser_automation", {}).get("headless", False)
                logger.info(f"ブラウザ自動操作モジュールを初期化します: {config_path}, headless={headless}")
                self.browser_automation = BrowserAutomation(config_path=config_path, headless=headless)
            
            logger.info("全モジュールの初期化が完了しました")
        except Exception as e:
            logger.error(f"モジュールの初期化中にエラーが発生しました: {e}")
            raise
    
    def start(self) -> None:
        """システムを起動する"""
        try:
            logger.info("MUGEN Systemを起動します")
            
            # ブラウザを起動
            if self.browser_automation:
                self.browser_automation.start_browser()
            
            # 取引プラットフォームにログイン
            target_platforms = self.config.get("target_platforms", ["the_option", "bi_winning"])
            if self.browser_automation and target_platforms:
                platform = target_platforms[0]  # 最初のプラットフォームを使用
                self.browser_automation.login(platform)
            
            # 取引ループを開始
            self._trading_loop()
            
        except Exception as e:
            logger.error(f"システム起動中にエラーが発生しました: {e}")
            self.stop()
            raise
    
    def stop(self) -> None:
        """システムを停止する"""
        try:
            logger.info("MUGEN Systemを停止します")
            
            # ブラウザを閉じる
            if self.browser_automation:
                self.browser_automation.close_browser()
            
            logger.info("MUGEN Systemを正常に停止しました")
        except Exception as e:
            logger.error(f"システム停止中にエラーが発生しました: {e}")
            raise
    
    def _trading_loop(self) -> None:
        """取引ループ"""
        try:
            logger.info("取引ループを開始します")
            
            consecutive_losses = 0
            max_consecutive_losses = self.config.get("trading_settings", {}).get("auto_stop_on_consecutive_losses", 5)
            
            while True:
                # 日次取引可能かどうかを確認
                if self.trade_manager and not self.trade_manager.can_trade_today():
                    logger.info("今日の取引上限に達しました。明日まで待機します。")
                    self._wait_until_next_day()
                    continue
                
                # 検知回避システムに次の取引結果を問い合わせ
                next_result = "win"  # デフォルト
                if self.detection_avoidance:
                    next_result = self.detection_avoidance.determine_next_trade_result()
                
                # 取引サイズを計算
                trade_size = 1000.0  # デフォルト
                if self.trade_manager:
                    trade_size = self.trade_manager.calculate_trade_size()
                
                # 人間らしい待機時間を計算
                wait_time = 0
                if self.human_behavior:
                    wait_time = self.human_behavior.calculate_wait_time()
                
                logger.info(f"次の取引: 結果={next_result}, サイズ={trade_size}, 待機時間={wait_time}秒")
                
                # 待機
                if wait_time > 0:
                    time.sleep(wait_time)
                
                # 取引方向を決定（勝ちの場合はランダム、負けの場合は逆）
                direction = "up" if random.random() > 0.5 else "down"
                if next_result == "loss":
                    # 負けるように方向を調整（実際のチャート状況に応じて）
                    direction = "down" if direction == "up" else "up"
                
                # 取引を実行
                trade_result = None
                if self.browser_automation:
                    trade_result = self.browser_automation.place_trade(direction, trade_size)
                
                # 取引結果を記録
                if trade_result and trade_result.get("success", False):
                    result = trade_result.get("result", "unknown")
                    profit = trade_size if result == "win" else -trade_size
                    balance = trade_result.get("balance", 0.0)
                    
                    # 検知回避システムに結果を記録
                    if self.detection_avoidance:
                        self.detection_avoidance.record_trade_result(result, profit, balance)
                    
                    # 取引管理システムに結果を記録
                    if self.trade_manager:
                        self.trade_manager.record_trade(profit)
                    
                    # 連続敗北のカウント
                    if result == "win":
                        consecutive_losses = 0
                    else:
                        consecutive_losses += 1
                    
                    # 連続敗北による停止
                    if consecutive_losses >= max_consecutive_losses:
                        logger.warning(f"{consecutive_losses}連敗したため、取引を停止します")
                        self._send_notification(f"{consecutive_losses}連敗したため、取引を停止します")
                        break
                
                # 1億円到達チェック
                if self.trade_manager and self.trade_manager.daily_stats["account_balance"] >= self.config.get("trading_settings", {}).get("target_balance", 100000000.0):
                    logger.info("目標金額（1億円）に到達しました！")
                    self._send_notification("目標金額（1億円）に到達しました！")
                    break
            
            logger.info("取引ループを終了します")
        except Exception as e:
            logger.error(f"取引ループ中にエラーが発生しました: {e}")
            self._send_notification(f"エラーが発生しました: {e}")
            raise
    
    def _wait_until_next_day(self) -> None:
        """翌日まで待機する"""
        now = dt.datetime.now()
        tomorrow = now.replace(hour=0, minute=0, second=0, microsecond=0) + dt.timedelta(days=1)
        wait_seconds = (tomorrow - now).total_seconds()
        
        logger.info(f"翌日まで待機します: {wait_seconds}秒")
        
        # 実際のシステムでは、ここで長時間のsleepは避け、
        # 定期的に状態をチェックしながら待機するべき
        time.sleep(min(wait_seconds, 3600))  # 最大1時間待機
    
    def _send_notification(self, message: str) -> None:
        """通知を送信する"""
        try:
            # LINE通知
            if self.config.get("notification_settings", {}).get("line_notify", {}).get("enabled", False):
                token = self.config.get("notification_settings", {}).get("line_notify", {}).get("token", "")
                if token:
                    self._send_line_notification(message, token)
            
            # メール通知
            if self.config.get("notification_settings", {}).get("email", {}).get("enabled", False):
                email_config = self.config.get("notification_settings", {}).get("email", {})
                self._send_email_notification(message, email_config)
            
            logger.info(f"通知を送信しました: {message}")
        except Exception as e:
            logger.error(f"通知の送信に失敗しました: {e}")
    
    def _send_line_notification(self, message: str, token: str) -> None:
        """LINE通知を送信する"""
        try:
            import requests
            
            url = "https://notify-api.line.me/api/notify"
            headers = {"Authorization": f"Bearer {token}"}
            data = {"message": message}
            
            response = requests.post(url, headers=headers, data=data)
            response.raise_for_status()
            
            logger.info("LINE通知を送信しました")
        except Exception as e:
            logger.error(f"LINE通知の送信に失敗しました: {e}")
    
    def _send_email_notification(self, message: str, email_config: Dict[str, Any]) -> None:
        """メール通知を送信する"""
        try:
            import smtplib
            from email.mime.text import MIMEText
            from email.mime.multipart import MIMEMultipart
            
            smtp_server = email_config.get("smtp_server", "")
            smtp_port = email_config.get("smtp_port", 587)
            username = email_config.get("username", "")
            password = email_config.get("password", "")
            recipient = email_config.get("recipient", "")
            
            if not smtp_server or not username or not password or not recipient:
                logger.error("メール設定が不完全です")
                return
            
            msg = MIMEMultipart()
            msg["From"] = username
            msg["To"] = recipient
            msg["Subject"] = "MUGEN System通知"
            
            msg.attach(MIMEText(message, "plain"))
            
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(username, password)
            server.send_message(msg)
            server.quit()
            
            logger.info("メール通知を送信しました")
        except Exception as e:
            logger.error(f"メール通知の送信に失敗しました: {e}")
    
    def get_system_status(self) -> Dict[str, Any]:
        """システムの状態を取得する"""
        status = {
            "system_name": self.config.get("system_name", "MUGEN System"),
            "version": self.config.get("version", "1.0.0"),
            "running": True,
            "modules": {
                "human_behavior": bool(self.human_behavior),
                "detection_avoidance": bool(self.detection_avoidance),
                "trade_management": bool(self.trade_manager),
                "browser_automation": bool(self.browser_automation)
            },
            "timestamp": dt.datetime.now().isoformat()
        }
        
        # 取引管理情報を追加
        if self.trade_manager:
            status["trade_summary"] = self.trade_manager.get_trade_summary()
        
        return status

# メイン実行部分
if __name__ == "__main__":
    try:
        # システムのインスタンスを作成
        system = MugenSystem()
        
        # システムを起動
        system.start()
    except KeyboardInterrupt:
        logger.info("ユーザーによる中断を検出しました")
    except Exception as e:
        logger.critical(f"予期せぬエラーが発生しました: {e}", exc_info=True)
    finally:
        # システムを停止
        if 'system' in locals():
            system.stop()
