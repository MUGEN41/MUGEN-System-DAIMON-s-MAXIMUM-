#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System (DAIMON's MAXIMUM) - ファンダメンタルズ監視機能
経済指標や市場ニュースを監視し、取引判断に活用するモジュール
"""

import os
import sys
import json
import time
import logging
import datetime as dt
import requests
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("fundamentals_monitor.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Fundamentals_Monitor")

class FundamentalsMonitor:
    """
    ファンダメンタルズ監視クラス
    経済指標や市場ニュースを監視し、取引判断に活用する
    """
    
    def __init__(self, config_path: str = "config/fundamentals_monitor_config.json"):
        """
        初期化
        
        Args:
            config_path: 設定ファイルのパス
        """
        self.config_path = Path(config_path)
        self.config_dir = self.config_path.parent
        self.config: Dict[str, Any] = {}
        self.economic_calendar: Dict[str, Any] = {}
        self.news_data: Dict[str, Any] = {}
        self.market_sentiment: Dict[str, float] = {}
        self.last_update: Dict[str, dt.datetime] = {}
        self._ensure_config_dir()
        self._load_config()
        self._load_cached_data()
    
    def _ensure_config_dir(self) -> None:
        """設定ディレクトリが存在することを確認"""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)
            logger.info(f"設定ディレクトリを作成しました: {self.config_dir}")
    
    def _load_config(self) -> None:
        """設定ファイルを読み込む"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info("ファンダメンタルズ監視設定を読み込みました")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
                self.config = {}
        else:
            logger.info("設定ファイルが存在しないため、新規作成します")
            # 初期設定
            self.config = {
                "enabled": True,
                "update_interval": {
                    "economic_calendar": 3600,  # 1時間ごと
                    "news": 900,  # 15分ごと
                    "market_sentiment": 1800  # 30分ごと
                },
                "impact_thresholds": {
                    "high": 0.7,
                    "medium": 0.4,
                    "low": 0.2
                },
                "currency_pairs": ["USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "CADJPY", "CHFJPY", "EURUSD", "GBPUSD"],
                "economic_indicators": {
                    "interest_rates": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "gdp": {
                        "enabled": True,
                        "weight": 0.9
                    },
                    "inflation": {
                        "enabled": True,
                        "weight": 0.8
                    },
                    "employment": {
                        "enabled": True,
                        "weight": 0.8
                    },
                    "retail_sales": {
                        "enabled": True,
                        "weight": 0.7
                    },
                    "manufacturing": {
                        "enabled": True,
                        "weight": 0.7
                    },
                    "trade_balance": {
                        "enabled": True,
                        "weight": 0.6
                    },
                    "housing": {
                        "enabled": True,
                        "weight": 0.5
                    }
                },
                "news_sources": {
                    "financial_news": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "central_bank_statements": {
                        "enabled": True,
                        "weight": 1.0
                    },
                    "market_analysis": {
                        "enabled": True,
                        "weight": 0.8
                    },
                    "social_media": {
                        "enabled": True,
                        "weight": 0.5
                    }
                },
                "sentiment_analysis": {
                    "enabled": True,
                    "lookback_period": 7,  # 日数
                    "smoothing_factor": 0.2
                },
                "data_cache": {
                    "enabled": True,
                    "max_age_days": 30
                },
                "last_updated": dt.datetime.now().isoformat()
            }
            self._save_config()
    
    def _save_config(self) -> None:
        """設定ファイルを保存する"""
        try:
            # 更新日時を記録
            self.config["last_updated"] = dt.datetime.now().isoformat()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("ファンダメンタルズ監視設定を保存しました")
        except Exception as e:
            logger.error(f"設定ファイルの保存に失敗しました: {e}")
    
    def _load_cached_data(self) -> None:
        """キャッシュされたデータを読み込む"""
        try:
            # 経済カレンダー
            calendar_path = self.config_dir / "economic_calendar_cache.json"
            if calendar_path.exists():
                with open(calendar_path, 'r', encoding='utf-8') as f:
                    self.economic_calendar = json.load(f)
                logger.info("経済カレンダーのキャッシュを読み込みました")
                self.last_update["economic_calendar"] = dt.datetime.fromisoformat(self.economic_calendar.get("last_updated", "2000-01-01T00:00:00"))
            
            # ニュースデータ
            news_path = self.config_dir / "news_data_cache.json"
            if news_path.exists():
                with open(news_path, 'r', encoding='utf-8') as f:
                    self.news_data = json.load(f)
                logger.info("ニュースデータのキャッシュを読み込みました")
                self.last_update["news"] = dt.datetime.fromisoformat(self.news_data.get("last_updated", "2000-01-01T00:00:00"))
            
            # 市場センチメント
            sentiment_path = self.config_dir / "market_sentiment_cache.json"
            if sentiment_path.exists():
                with open(sentiment_path, 'r', encoding='utf-8') as f:
                    sentiment_data = json.load(f)
                    self.market_sentiment = {k: float(v) for k, v in sentiment_data.get("sentiment", {}).items()}
                logger.info("市場センチメントのキャッシュを読み込みました")
                self.last_update["market_sentiment"] = dt.datetime.fromisoformat(sentiment_data.get("last_updated", "2000-01-01T00:00:00"))
        except Exception as e:
            logger.error(f"キャッシュデータの読み込みに失敗しました: {e}")
    
    def _save_cached_data(self) -> None:
        """キャッシュデータを保存する"""
        try:
            # 経済カレンダー
            if self.economic_calendar:
                calendar_path = self.config_dir / "economic_calendar_cache.json"
                with open(calendar_path, 'w', encoding='utf-8') as f:
                    json.dump(self.economic_calendar, f, indent=4, ensure_ascii=False)
                logger.info("経済カレンダーのキャッシュを保存しました")
            
            # ニュースデータ
            if self.news_data:
                news_path = self.config_dir / "news_data_cache.json"
                with open(news_path, 'w', encoding='utf-8') as f:
                    json.dump(self.news_data, f, indent=4, ensure_ascii=False)
                logger.info("ニュースデータのキャッシュを保存しました")
            
            # 市場センチメント
            if self.market_sentiment:
                sentiment_path = self.config_dir / "market_sentiment_cache.json"
                sentiment_data = {
                    "sentiment": self.market_sentiment,
                    "last_updated": dt.datetime.now().isoformat()
                }
                with open(sentiment_path, 'w', encoding='utf-8') as f:
                    json.dump(sentiment_data, f, indent=4, ensure_ascii=False)
                logger.info("市場センチメントのキャッシュを保存しました")
        except Exception as e:
            logger.error(f"キャッシュデータの保存に失敗しました: {e}")
    
    def update_economic_calendar(self) -> bool:
        """
        経済カレンダーを更新する
        
        Returns:
            bool: 更新成功かどうか
        """
        if not self.config.get("enabled", True):
            logger.warning("ファンダメンタルズ監視が無効になっています")
            return False
        
        # 更新間隔をチェック
        now = dt.datetime.now()
        last_update = self.last_update.get("economic_calendar", dt.datetime(2000, 1, 1))
        update_interval = self.config.get("update_interval", {}).get("economic_calendar", 3600)
        
        if (now - last_update).total_seconds() < update_interval:
            logger.info("経済カレンダーの更新間隔に達していません")
            return False
        
        try:
            # 経済カレンダーデータを取得（実際のAPIを使用する場合はここを修正）
            # この例では、モックデータを生成
            calendar_data = self._generate_mock_economic_calendar()
            
            # データを更新
            self.economic_calendar = calendar_data
            self.economic_calendar["last_updated"] = now.isoformat()
            self.last_update["economic_calendar"] = now
            
            # キャッシュを保存
            self._save_cached_data()
            
            logger.info("経済カレンダーを更新しました")
            return True
        except Exception as e:
            logger.error(f"経済カレンダーの更新に失敗しました: {e}")
            return False
    
    def _generate_mock_economic_calendar(self) -> Dict[str, Any]:
        """
        モックの経済カレンダーデータを生成する（実際のAPIを使用する場合は削除）
        
        Returns:
            Dict[str, Any]: モックの経済カレンダーデータ
        """
        now = dt.datetime.now()
        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end_date = start_date + dt.timedelta(days=7)
        
        # 経済指標のリスト
        indicators = [
            {"name": "Interest Rate Decision", "country": "US", "impact": "high"},
            {"name": "GDP", "country": "US", "impact": "high"},
            {"name": "Non-Farm Payrolls", "country": "US", "impact": "high"},
            {"name": "CPI", "country": "US", "impact": "high"},
            {"name": "Retail Sales", "country": "US", "impact": "medium"},
            {"name": "Interest Rate Decision", "country": "EU", "impact": "high"},
            {"name": "GDP", "country": "EU", "impact": "high"},
            {"name": "CPI", "country": "EU", "impact": "high"},
            {"name": "Interest Rate Decision", "country": "JP", "impact": "high"},
            {"name": "GDP", "country": "JP", "impact": "high"},
            {"name": "CPI", "country": "JP", "impact": "high"}
        ]
        
        # イベントを生成
        events = []
        current_date = start_date
        
        while current_date < end_date:
            # その日のイベント数（0〜3）
            num_events = min(3, max(0, int(current_date.weekday() < 5) * (1 + int(current_date.weekday() % 3))))
            
            for _ in range(num_events):
                # ランダムな時間（市場時間内）
                hour = 8 + (current_date.weekday() % 3) * 4
                minute = (current_date.day * 17) % 60
                event_time = current_date.replace(hour=hour, minute=minute)
                
                # ランダムな経済指標
                indicator = indicators[(current_date.day + current_date.weekday()) % len(indicators)]
                
                # 予測値と実際の値
                forecast = round(100 + (current_date.day % 10) * 0.1, 1)
                actual = None
                if event_time < now:
                    deviation = (((current_date.day * 7) % 21) - 10) * 0.1
                    actual = round(forecast + deviation, 1)
                
                events.append({
                    "id": f"evt_{current_date.strftime('%Y%m%d')}_{len(events)}",
                    "title": f"{indicator['country']} {indicator['name']}",
                    "country": indicator["country"],
                    "indicator": indicator["name"],
                    "impact": indicator["impact"],
                    "date": event_time.isoformat(),
                    "forecast": forecast,
                    "actual": actual,
                    "previous": round(forecast - 0.2, 1)
                })
            
            current_date += dt.timedelta(days=1)
        
        return {
            "events": events,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "count": len(events)
        }
    
    def update_news(self) -> bool:
        """
        ニュースデータを更新する
        
        Returns:
            bool: 更新成功かどうか
        """
        if not self.config.get("enabled", True):
            logger.warning("ファンダメンタルズ監視が無効になっています")
            return False
        
        # 更新間隔をチェック
        now = dt.datetime.now()
        last_update = self.last_update.get("news", dt.datetime(2000, 1, 1))
        update_interval = self.config.get("update_interval", {}).get("news", 900)
        
        if (now - last_update).total_seconds() < update_interval:
            logger.info("ニュースデータの更新間隔に達していません")
            return False
        
        try:
            # ニュースデータを取得（実際のAPIを使用する場合はここを修正）
            # この例では、モックデータを生成
            news_data = self._generate_mock_news_data()
            
            # データを更新
            self.news_data = news_data
            self.news_data["last_updated"] = now.isoformat()
            self.last_update["news"] = now
            
            # キャッシュを保存
            self._save_cached_data()
            
            logger.info("ニュースデータを更新しました")
            return True
        except Exception as e:
            logger.error(f"ニュースデータの更新に失敗しました: {e}")
            return False
    
    def _generate_mock_news_data(self) -> Dict[str, Any]:
        """
        モックのニュースデータを生成する（実際のAPIを使用する場合は削除）
        
        Returns:
            Dict[str, Any]: モックのニュースデータ
        """
        now = dt.datetime.now()
        
        # ニュースソースのリスト
        sources = ["Bloomberg", "Reuters", "CNBC", "Financial Times", "Wall Street Journal"]
        
        # ニュースカテゴリのリスト
        categories = ["central_bank_statements", "financial_news", "market_analysis", "social_media"]
        
        # 通貨ペアのリスト
        currency_pairs = self.config.get("currency_pairs", ["USDJPY", "EURJPY", "GBPJPY", "EURUSD", "GBPUSD"])
        
        # ニュースを生成
        news_items = []
        
        # 過去24時間のニュース
        for hours_ago in range(24):
            # その時間のニュース数（0〜3）
            num_news = min(3, max(0, int((24 - hours_ago) / 8)))
            
            for i in range(num_news):
                # ニュース時間
                news_time = now - dt.timedelta(hours=hours_ago, minutes=(i * 17) % 60)
                
                # ランダムなソース、カテゴリ、通貨ペア
                source = sources[(hours_ago + i) % len(sources)]
                category = categories[(hours_ago * 3 + i) % len(categories)]
                related_pairs = [currency_pairs[(hours_ago + i + j) % len(currency_pairs)] for j in range(1 + i % 3)]
                
                # センチメント（-1.0〜1.0）
                sentiment = round(((hours_ago * 7 + i * 13) % 21 - 10) / 10, 1)
                
                # タイトルとサマリー
                if sentiment > 0.3:
                    title_prefix = "Positive: "
                    sentiment_text = "positive"
                elif sentiment < -0.3:
                    title_prefix = "Negative: "
                    sentiment_text = "negative"
                else:
                    title_prefix = "Neutral: "
                    sentiment_text = "neutral"
                
                if category == "central_bank_statements":
                    title = f"{title_prefix}Central Bank of {related_pairs[0][:2]} Announces Policy Decision"
                    summary = f"The central bank has made a {sentiment_text} statement regarding monetary policy."
                elif category == "financial_news":
                    title = f"{title_prefix}Financial Update on {', '.join(related_pairs)}"
                    summary = f"Recent financial developments show {sentiment_text} trends for these currency pairs."
                elif category == "market_analysis":
                    title = f"{title_prefix}Market Analysis for {related_pairs[0]}"
                    summary = f"Analysts provide {sentiment_text} outlook for {related_pairs[0]} based on recent data."
                else:
                    title = f"{title_prefix}Social Media Buzz on {related_pairs[0]}"
                    summary = f"Social media sentiment is {sentiment_text} regarding {related_pairs[0]}."
                
                news_items.append({
                    "id": f"news_{news_time.strftime('%Y%m%d%H%M')}_{i}",
                    "title": title,
                    "summary": summary,
                    "source": source,
                    "category": category,
                    "date": news_time.isoformat(),
                    "url": f"https://example.com/news/{news_time.strftime('%Y%m%d')}/{i}",
                    "related_pairs": related_pairs,
                    "sentiment": sentiment
                })
        
        return {
            "news": news_items,
            "count": len(news_items)
        }
    
    def update_market_sentiment(self) -> bool:
        """
        市場センチメントを更新する
        
        Returns:
            bool: 更新成功かどうか
        """
        if not self.config.get("enabled", True):
            logger.warning("ファンダメンタルズ監視が無効になっています")
            return False
        
        # 更新間隔をチェック
        now = dt.datetime.now()
        last_update = self.last_update.get("market_sentiment", dt.datetime(2000, 1, 1))
        update_interval = self.config.get("update_interval", {}).get("market_sentiment", 1800)
        
        if (now - last_update).total_seconds() < update_interval:
            logger.info("市場センチメントの更新間隔に達していません")
            return False
        
        try:
            # 経済カレンダーとニュースデータが最新であることを確認
            self.update_economic_calendar()
            self.update_news()
            
            # 市場センチメントを計算
            sentiment = self._calculate_market_sentiment()
            
            # データを更新
            self.market_sentiment = sentiment
            self.last_update["market_sentiment"] = now
            
            # キャッシュを保存
            self._save_cached_data()
            
            logger.info("市場センチメントを更新しました")
            return True
        except Exception as e:
            logger.error(f"市場センチメントの更新に失敗しました: {e}")
            return False
    
    def _calculate_market_sentiment(self) -> Dict[str, float]:
        """
        市場センチメントを計算する
        
        Returns:
            Dict[str, float]: 通貨ペアごとの市場センチメント（-1.0〜1.0）
        """
        sentiment = {}
        currency_pairs = self.config.get("currency_pairs", [])
        
        for pair in currency_pairs:
            # 経済カレンダーからのセンチメント
            calendar_sentiment = self._calculate_calendar_sentiment(pair)
            
            # ニュースからのセンチメント
            news_sentiment = self._calculate_news_sentiment(pair)
            
            # 重み付け
            calendar_weight = 0.6
            news_weight = 0.4
            
            # 総合センチメント（-1.0〜1.0）
            total_sentiment = calendar_sentiment * calendar_weight + news_sentiment * news_weight
            
            # スムージング（前回のセンチメントがある場合）
            if pair in self.market_sentiment:
                smoothing_factor = self.config.get("sentiment_analysis", {}).get("smoothing_factor", 0.2)
                total_sentiment = self.market_sentiment[pair] * (1 - smoothing_factor) + total_sentiment * smoothing_factor
            
            # 範囲を-1.0〜1.0に制限
            total_sentiment = max(-1.0, min(1.0, total_sentiment))
            
            sentiment[pair] = total_sentiment
        
        return sentiment
    
    def _calculate_calendar_sentiment(self, currency_pair: str) -> float:
        """
        経済カレンダーからセンチメントを計算する
        
        Args:
            currency_pair: 通貨ペア
        
        Returns:
            float: センチメント（-1.0〜1.0）
        """
        # 通貨ペアから関連する国を抽出
        countries = []
        if currency_pair[:2] == "US":
            countries.append("US")
        elif currency_pair[:2] == "EU":
            countries.append("EU")
        elif currency_pair[:2] == "GB":
            countries.append("GB")
        elif currency_pair[:2] == "JP":
            countries.append("JP")
        elif currency_pair[:2] == "AU":
            countries.append("AU")
        elif currency_pair[:2] == "NZ":
            countries.append("NZ")
        elif currency_pair[:2] == "CA":
            countries.append("CA")
        elif currency_pair[:2] == "CH":
            countries.append("CH")
        
        if currency_pair[2:4] == "JP":
            countries.append("JP")
        elif currency_pair[2:4] == "US":
            countries.append("US")
        
        if not countries:
            return 0.0
        
        # 経済カレンダーからイベントを抽出
        events = self.economic_calendar.get("events", [])
        
        # 関連するイベントをフィルタリング
        relevant_events = [event for event in events if event.get("country") in countries and event.get("actual") is not None]
        
        if not relevant_events:
            return 0.0
        
        # イベントごとのセンチメントを計算
        total_sentiment = 0.0
        total_weight = 0.0
        
        for event in relevant_events:
            # 予測値と実際の値の差
            forecast = event.get("forecast", 0.0)
            actual = event.get("actual", 0.0)
            
            if forecast == 0:
                continue
            
            deviation = (actual - forecast) / abs(forecast)
            
            # インパクトの重み
            impact = event.get("impact", "medium")
            impact_weight = 1.0
            if impact == "high":
                impact_weight = 2.0
            elif impact == "low":
                impact_weight = 0.5
            
            # 指標の重み
            indicator = event.get("indicator", "")
            indicator_weight = 1.0
            
            for indicator_type, config in self.config.get("economic_indicators", {}).items():
                if indicator_type.lower() in indicator.lower() and config.get("enabled", True):
                    indicator_weight = config.get("weight", 1.0)
                    break
            
            # 時間の重み（新しいほど重要）
            event_time = dt.datetime.fromisoformat(event.get("date", "2000-01-01T00:00:00"))
            time_diff = (dt.datetime.now() - event_time).total_seconds() / 3600  # 時間単位
            time_weight = max(0.1, min(1.0, 24 / (time_diff + 1)))
            
            # 総合的な重み
            weight = impact_weight * indicator_weight * time_weight
            
            # センチメント（-1.0〜1.0）
            # 正の値は通貨強化、負の値は通貨弱化を意味する
            sentiment = max(-1.0, min(1.0, deviation * 5.0))
            
            # 通貨ペアの最初の通貨に関するイベントの場合、センチメントをそのまま使用
            # 2番目の通貨に関するイベントの場合、センチメントを反転
            if event.get("country") == countries[0]:
                pair_sentiment = sentiment
            else:
                pair_sentiment = -sentiment
            
            total_sentiment += pair_sentiment * weight
            total_weight += weight
        
        if total_weight == 0:
            return 0.0
        
        # 正規化（-1.0〜1.0）
        normalized_sentiment = total_sentiment / total_weight
        return max(-1.0, min(1.0, normalized_sentiment))
    
    def _calculate_news_sentiment(self, currency_pair: str) -> float:
        """
        ニュースからセンチメントを計算する
        
        Args:
            currency_pair: 通貨ペア
        
        Returns:
            float: センチメント（-1.0〜1.0）
        """
        # ニュースアイテムを抽出
        news_items = self.news_data.get("news", [])
        
        # 関連するニュースをフィルタリング
        relevant_news = [news for news in news_items if currency_pair in news.get("related_pairs", [])]
        
        if not relevant_news:
            return 0.0
        
        # ニュースごとのセンチメントを計算
        total_sentiment = 0.0
        total_weight = 0.0
        
        for news in relevant_news:
            # ニュースのセンチメント
            sentiment = news.get("sentiment", 0.0)
            
            # カテゴリの重み
            category = news.get("category", "")
            category_weight = 1.0
            
            for source_type, config in self.config.get("news_sources", {}).items():
                if source_type == category and config.get("enabled", True):
                    category_weight = config.get("weight", 1.0)
                    break
            
            # 時間の重み（新しいほど重要）
            news_time = dt.datetime.fromisoformat(news.get("date", "2000-01-01T00:00:00"))
            time_diff = (dt.datetime.now() - news_time).total_seconds() / 3600  # 時間単位
            time_weight = max(0.1, min(1.0, 24 / (time_diff + 1)))
            
            # 総合的な重み
            weight = category_weight * time_weight
            
            total_sentiment += sentiment * weight
            total_weight += weight
        
        if total_weight == 0:
            return 0.0
        
        # 正規化（-1.0〜1.0）
        normalized_sentiment = total_sentiment / total_weight
        return max(-1.0, min(1.0, normalized_sentiment))
    
    def get_trading_recommendation(self, currency_pair: str, timeframe: str = "1h") -> Dict[str, Any]:
        """
        取引推奨を取得する
        
        Args:
            currency_pair: 通貨ペア
            timeframe: 時間枠
        
        Returns:
            Dict[str, Any]: 取引推奨
        """
        if not self.config.get("enabled", True):
            logger.warning("ファンダメンタルズ監視が無効になっています")
            return {"recommendation": "neutral", "confidence": 0.0, "reason": "Fundamentals monitoring is disabled"}
        
        # 市場センチメントを更新
        self.update_market_sentiment()
        
        # 通貨ペアのセンチメントを取得
        sentiment = self.market_sentiment.get(currency_pair, 0.0)
        
        # 時間枠に基づく重み付け
        timeframe_weight = 1.0
        if timeframe == "1m":
            timeframe_weight = 0.2  # 短期の時間枠ではファンダメンタルズの影響は小さい
        elif timeframe == "3m":
            timeframe_weight = 0.3
        elif timeframe == "5m":
            timeframe_weight = 0.4
        elif timeframe == "15m":
            timeframe_weight = 0.5
        elif timeframe == "1h":
            timeframe_weight = 0.7
        elif timeframe == "4h":
            timeframe_weight = 0.8
        elif timeframe == "1d":
            timeframe_weight = 1.0  # 長期の時間枠ではファンダメンタルズの影響は大きい
        
        # 調整されたセンチメント
        adjusted_sentiment = sentiment * timeframe_weight
        
        # 推奨と確信度
        if adjusted_sentiment > 0.3:
            recommendation = "buy"
            confidence = min(1.0, adjusted_sentiment * 2)
            reason = f"Positive market sentiment for {currency_pair}"
        elif adjusted_sentiment < -0.3:
            recommendation = "sell"
            confidence = min(1.0, -adjusted_sentiment * 2)
            reason = f"Negative market sentiment for {currency_pair}"
        else:
            recommendation = "neutral"
            confidence = 1.0 - abs(adjusted_sentiment) * 3
            reason = f"Neutral market sentiment for {currency_pair}"
        
        # 関連するイベントとニュース
        upcoming_events = self._get_upcoming_events(currency_pair)
        recent_news = self._get_recent_news(currency_pair)
        
        return {
            "currency_pair": currency_pair,
            "timeframe": timeframe,
            "recommendation": recommendation,
            "confidence": round(confidence, 2),
            "sentiment": round(adjusted_sentiment, 2),
            "reason": reason,
            "upcoming_events": upcoming_events,
            "recent_news": recent_news,
            "timestamp": dt.datetime.now().isoformat()
        }
    
    def _get_upcoming_events(self, currency_pair: str) -> List[Dict[str, Any]]:
        """
        今後のイベントを取得する
        
        Args:
            currency_pair: 通貨ペア
        
        Returns:
            List[Dict[str, Any]]: 今後のイベント
        """
        # 通貨ペアから関連する国を抽出
        countries = []
        if currency_pair[:2] == "US":
            countries.append("US")
        elif currency_pair[:2] == "EU":
            countries.append("EU")
        elif currency_pair[:2] == "GB":
            countries.append("GB")
        elif currency_pair[:2] == "JP":
            countries.append("JP")
        elif currency_pair[:2] == "AU":
            countries.append("AU")
        elif currency_pair[:2] == "NZ":
            countries.append("NZ")
        elif currency_pair[:2] == "CA":
            countries.append("CA")
        elif currency_pair[:2] == "CH":
            countries.append("CH")
        
        if currency_pair[2:4] == "JP":
            countries.append("JP")
        elif currency_pair[2:4] == "US":
            countries.append("US")
        
        if not countries:
            return []
        
        # 経済カレンダーからイベントを抽出
        events = self.economic_calendar.get("events", [])
        
        # 今後のイベントをフィルタリング
        now = dt.datetime.now()
        upcoming_events = []
        
        for event in events:
            event_time = dt.datetime.fromisoformat(event.get("date", "2000-01-01T00:00:00"))
            if event_time > now and event.get("country") in countries:
                # イベントの重要度
                impact = event.get("impact", "medium")
                impact_score = 1
                if impact == "high":
                    impact_score = 3
                elif impact == "low":
                    impact_score = 1
                
                upcoming_events.append({
                    "title": event.get("title", ""),
                    "date": event.get("date", ""),
                    "impact": impact,
                    "impact_score": impact_score,
                    "forecast": event.get("forecast", None)
                })
        
        # 時間順にソート
        upcoming_events.sort(key=lambda x: x.get("date", ""))
        
        # 最大5件まで
        return upcoming_events[:5]
    
    def _get_recent_news(self, currency_pair: str) -> List[Dict[str, Any]]:
        """
        最近のニュースを取得する
        
        Args:
            currency_pair: 通貨ペア
        
        Returns:
            List[Dict[str, Any]]: 最近のニュース
        """
        # ニュースアイテムを抽出
        news_items = self.news_data.get("news", [])
        
        # 関連するニュースをフィルタリング
        relevant_news = [news for news in news_items if currency_pair in news.get("related_pairs", [])]
        
        # 時間順にソート（新しい順）
        relevant_news.sort(key=lambda x: x.get("date", ""), reverse=True)
        
        # 最大5件まで
        recent_news = relevant_news[:5]
        
        # 必要な情報だけを抽出
        return [
            {
                "title": news.get("title", ""),
                "date": news.get("date", ""),
                "source": news.get("source", ""),
                "sentiment": news.get("sentiment", 0.0),
                "url": news.get("url", "")
            }
            for news in recent_news
        ]
    
    def get_fundamentals_summary(self, currency_pairs: List[str] = None) -> Dict[str, Any]:
        """
        ファンダメンタルズの概要を取得する
        
        Args:
            currency_pairs: 通貨ペアのリスト（指定しない場合は全て）
        
        Returns:
            Dict[str, Any]: ファンダメンタルズの概要
        """
        if not self.config.get("enabled", True):
            logger.warning("ファンダメンタルズ監視が無効になっています")
            return {"status": "disabled"}
        
        # 市場センチメントを更新
        self.update_market_sentiment()
        
        # 通貨ペアのリストを取得
        if currency_pairs is None:
            currency_pairs = self.config.get("currency_pairs", [])
        
        # 各通貨ペアのセンチメント
        sentiment_summary = {}
        for pair in currency_pairs:
            sentiment = self.market_sentiment.get(pair, 0.0)
            sentiment_summary[pair] = {
                "sentiment": round(sentiment, 2),
                "status": "bullish" if sentiment > 0.3 else "bearish" if sentiment < -0.3 else "neutral"
            }
        
        # 今後のイベント
        all_upcoming_events = []
        for pair in currency_pairs:
            events = self._get_upcoming_events(pair)
            for event in events:
                if event not in all_upcoming_events:
                    all_upcoming_events.append(event)
        
        # 時間順にソート
        all_upcoming_events.sort(key=lambda x: x.get("date", ""))
        
        # 最近のニュース
        all_recent_news = []
        for pair in currency_pairs:
            news = self._get_recent_news(pair)
            for item in news:
                if item not in all_recent_news:
                    all_recent_news.append(item)
        
        # 時間順にソート（新しい順）
        all_recent_news.sort(key=lambda x: x.get("date", ""), reverse=True)
        
        return {
            "sentiment_summary": sentiment_summary,
            "upcoming_events": all_upcoming_events[:10],  # 最大10件
            "recent_news": all_recent_news[:10],  # 最大10件
            "last_updated": dt.datetime.now().isoformat()
        }

# 使用例
if __name__ == "__main__":
    # ファンダメンタルズ監視のインスタンスを作成
    monitor = FundamentalsMonitor()
    
    # 経済カレンダーを更新
    monitor.update_economic_calendar()
    
    # ニュースを更新
    monitor.update_news()
    
    # 市場センチメントを更新
    monitor.update_market_sentiment()
    
    # 取引推奨を取得
    recommendation = monitor.get_trading_recommendation("USDJPY", "1h")
    print(f"Recommendation for USDJPY (1h): {recommendation['recommendation']}, Confidence: {recommendation['confidence']}")
    
    # ファンダメンタルズの概要を取得
    summary = monitor.get_fundamentals_summary(["USDJPY", "EURJPY", "EURUSD"])
    print(f"Fundamentals summary: {len(summary['upcoming_events'])} upcoming events, {len(summary['recent_news'])} recent news")
