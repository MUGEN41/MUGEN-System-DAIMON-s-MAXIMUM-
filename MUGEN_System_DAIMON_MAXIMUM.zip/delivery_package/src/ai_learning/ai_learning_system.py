#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System AI Learning Module
-------------------------------
このモジュールはMUGEN Systemのチャートデータ学習機能を提供します。
TensorflowとCUDAを使用して、複数の通貨ペアと時間枠に対応した
高精度な予測モデルを構築します。
"""

import os
import sys
import json
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, BatchNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import logging
from datetime import datetime, timedelta
import pickle
import glob

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ai_learning.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AILearningSystem:
    """
    MUGEN System AI学習システム
    
    複数の通貨ペアと時間枠に対応した学習モデルを構築し、
    高精度な予測を行うためのシステムです。
    """
    
    def __init__(self, config_path=None):
        """
        初期化
        
        Parameters:
        -----------
        config_path : str
            設定ファイルのパス
        """
        # デフォルト設定
        self.default_config = {
            "data_dir": "data",
            "models_dir": "models",
            "currency_pairs": [
                "USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY",
                "EURUSD", "GBPUSD", "AUDUSD", "NZDUSD"
            ],
            "timeframes": [
                "1m", "3m", "5m", "15m", "1h", "4h", "1d"
            ],
            "date_range": {
                "start": "2021-05-01",
                "end": "2024-04-30"
            },
            "features": [
                "open", "high", "low", "close", "volume"
            ],
            "target": "direction",  # 'direction' or 'price'
            "sequence_length": 60,
            "prediction_horizon": 1,
            "test_size": 0.2,
            "validation_size": 0.1,
            "batch_size": 64,
            "epochs": 100,
            "early_stopping_patience": 10,
            "learning_rate": 0.001,
            "dropout_rate": 0.2,
            "lstm_units": [128, 64],
            "dense_units": [32, 16],
            "use_batch_norm": true,
            "use_gpu": true,
            "random_seed": 42,
            "target_win_rate": 0.8
        }
        
        # 設定ファイルの読み込み
        self.config = self.default_config
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    self.config.update(loaded_config)
                logger.info(f"設定ファイルを読み込みました: {config_path}")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
        
        # ディレクトリの作成
        os.makedirs(self.config["data_dir"], exist_ok=True)
        os.makedirs(self.config["models_dir"], exist_ok=True)
        
        # スケーラーの初期化
        self.scalers = {}
        
        # GPUの設定
        if self.config["use_gpu"]:
            self._setup_gpu()
        
        # 乱数シードの設定
        np.random.seed(self.config["random_seed"])
        tf.random.set_seed(self.config["random_seed"])
        
        logger.info("AI学習システムを初期化しました")
    
    def _setup_gpu(self):
        """GPUの設定"""
        try:
            gpus = tf.config.list_physical_devices('GPU')
            if gpus:
                for gpu in gpus:
                    tf.config.experimental.set_memory_growth(gpu, True)
                logger.info(f"GPUが利用可能です: {len(gpus)}個")
            else:
                logger.warning("GPUが見つかりません。CPUを使用します。")
        except Exception as e:
            logger.error(f"GPU設定エラー: {e}")
    
    def download_data(self, currency_pair, timeframe, start_date, end_date):
        """
        チャートデータのダウンロード
        
        Parameters:
        -----------
        currency_pair : str
            通貨ペア (例: "USDJPY")
        timeframe : str
            時間枠 (例: "1m", "1h")
        start_date : str
            開始日 (YYYY-MM-DD)
        end_date : str
            終了日 (YYYY-MM-DD)
            
        Returns:
        --------
        pandas.DataFrame or None
            ダウンロードしたデータ、失敗時はNone
        """
        # 実際の実装ではAPIからデータを取得
        # このサンプルではダミーデータを生成
        logger.info(f"{currency_pair} {timeframe} のデータをダウンロード中 ({start_date} から {end_date})")
        
        try:
            # ダミーデータの生成
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
            
            # 時間枠に応じた間隔の設定
            if timeframe == "1m":
                freq = "1min"
            elif timeframe == "3m":
                freq = "3min"
            elif timeframe == "5m":
                freq = "5min"
            elif timeframe == "15m":
                freq = "15min"
            elif timeframe == "1h":
                freq = "1H"
            elif timeframe == "4h":
                freq = "4H"
            elif timeframe == "1d":
                freq = "1D"
            else:
                logger.error(f"不明な時間枠: {timeframe}")
                return None
            
            # 日付範囲の生成
            date_range = pd.date_range(start=start, end=end, freq=freq)
            
            # データフレームの作成
            df = pd.DataFrame(index=date_range)
            df.index.name = 'timestamp'
            
            # ランダムな価格データの生成
            base_price = 100.0 if "JPY" in currency_pair else 1.0
            volatility = 0.002  # ボラティリティ
            
            # 初期価格
            price = base_price
            prices = []
            
            # ランダムウォークで価格を生成
            for _ in range(len(df)):
                change = np.random.normal(0, volatility)
                price *= (1 + change)
                prices.append(price)
            
            # OHLCV データの生成
            df['open'] = prices
            df['high'] = df['open'] * (1 + np.random.uniform(0, 0.003, len(df)))
            df['low'] = df['open'] * (1 - np.random.uniform(0, 0.003, len(df)))
            df['close'] = df['open'] * (1 + np.random.normal(0, 0.001, len(df)))
            df['volume'] = np.random.randint(100, 1000, len(df))
            
            # ファイルに保存
            filename = f"{self.config['data_dir']}/{currency_pair}_{timeframe}_{start_date}_{end_date}.csv"
            df.to_csv(filename)
            logger.info(f"データを保存しました: {filename}")
            
            return df
            
        except Exception as e:
            logger.error(f"データダウンロードエラー: {e}")
            return None
    
    def download_all_data(self):
        """すべての通貨ペアと時間枠のデータをダウンロード"""
        start_date = self.config["date_range"]["start"]
        end_date = self.config["date_range"]["end"]
        
        for currency_pair in self.config["currency_pairs"]:
            for timeframe in self.config["timeframes"]:
                self.download_data(currency_pair, timeframe, start_date, end_date)
    
    def preprocess_data(self, df, currency_pair, timeframe):
        """
        データの前処理
        
        Parameters:
        -----------
        df : pandas.DataFrame
            処理するデータフレーム
        currency_pair : str
            通貨ペア
        timeframe : str
            時間枠
            
        Returns:
        --------
        tuple
            (X_train, y_train, X_val, y_val, X_test, y_test)
        """
        logger.info(f"{currency_pair} {timeframe} のデータを前処理中")
        
        try:
            # 特徴量とターゲットの準備
            features = self.config["features"]
            target = self.config["target"]
            sequence_length = self.config["sequence_length"]
            prediction_horizon = self.config["prediction_horizon"]
            
            # 欠損値の処理
            df = df.dropna()
            
            # 特徴量の計算（テクニカル指標など）
            df = self._calculate_features(df)
            
            # ターゲット変数の作成
            if target == "direction":
                # 方向予測（上昇/下降）
                df['target'] = (df['close'].shift(-prediction_horizon) > df['close']).astype(int)
            else:
                # 価格予測
                df['target'] = df['close'].shift(-prediction_horizon)
            
            # NaNの削除
            df = df.dropna()
            
            # スケーリング
            scaler_key = f"{currency_pair}_{timeframe}"
            if scaler_key not in self.scalers:
                self.scalers[scaler_key] = MinMaxScaler()
            
            # 特徴量のスケーリング
            feature_data = df[features].values
            scaled_features = self.scalers[scaler_key].fit_transform(feature_data)
            
            # シーケンスデータの作成
            X, y = self._create_sequences(scaled_features, df['target'].values, sequence_length)
            
            # データ分割
            X_train, X_temp, y_train, y_temp = train_test_split(
                X, y, test_size=self.config["test_size"] + self.config["validation_size"],
                random_state=self.config["random_seed"]
            )
            
            # テストとバリデーションの分割
            val_size = self.config["validation_size"] / (self.config["test_size"] + self.config["validation_size"])
            X_val, X_test, y_val, y_test = train_test_split(
                X_temp, y_temp, test_size=val_size,
                random_state=self.config["random_seed"]
            )
            
            logger.info(f"データ前処理完了: 訓練={X_train.shape}, 検証={X_val.shape}, テスト={X_test.shape}")
            
            return X_train, y_train, X_val, y_val, X_test, y_test
            
        except Exception as e:
            logger.error(f"データ前処理エラー: {e}")
            return None, None, None, None, None, None
    
    def _calculate_features(self, df):
        """テクニカル指標などの特徴量を計算"""
        # 移動平均
        df['sma_5'] = df['close'].rolling(window=5).mean()
        df['sma_10'] = df['close'].rolling(window=10).mean()
        df['sma_20'] = df['close'].rolling(window=20).mean()
        
        # ボリンジャーバンド
        df['std_20'] = df['close'].rolling(window=20).std()
        df['upper_band'] = df['sma_20'] + (df['std_20'] * 2)
        df['lower_band'] = df['sma_20'] - (df['std_20'] * 2)
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # MACD
        df['ema_12'] = df['close'].ewm(span=12, adjust=False).mean()
        df['ema_26'] = df['close'].ewm(span=26, adjust=False).mean()
        df['macd'] = df['ema_12'] - df['ema_26']
        df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
        df['macd_hist'] = df['macd'] - df['macd_signal']
        
        return df
    
    def _create_sequences(self, data, target, sequence_length):
        """シーケンスデータの作成"""
        X, y = [], []
        
        for i in range(len(data) - sequence_length):
            X.append(data[i:i+sequence_length])
            y.append(target[i+sequence_length])
        
        return np.array(X), np.array(y)
    
    def build_model(self, input_shape, output_shape=1):
        """
        モデルの構築
        
        Parameters:
        -----------
        input_shape : tuple
            入力データの形状
        output_shape : int
            出力の次元数
            
        Returns:
        --------
        tensorflow.keras.Model
            構築されたモデル
        """
        logger.info(f"モデルを構築中: 入力形状={input_shape}, 出力形状={output_shape}")
        
        try:
            model = Sequential()
            
            # LSTM層
            lstm_units = self.config["lstm_units"]
            for i, units in enumerate(lstm_units):
                return_sequences = i < len(lstm_units) - 1
                if i == 0:
                    model.add(LSTM(units, return_sequences=return_sequences, input_shape=input_shape))
                else:
                    model.add(LSTM(units, return_sequences=return_sequences))
                
                if self.config["use_batch_norm"]:
                    model.add(BatchNormalization())
                
                model.add(Dropout(self.config["dropout_rate"]))
            
            # 全結合層
            dense_units = self.config["dense_units"]
            for units in dense_units:
                model.add(Dense(units, activation='relu'))
                if self.config["use_batch_norm"]:
                    model.add(BatchNormalization())
                model.add(Dropout(self.config["dropout_rate"]))
            
            # 出力層
            if output_shape == 1:
                # 二値分類または回帰
                if self.config["target"] == "direction":
                    model.add(Dense(1, activation='sigmoid'))
                else:
                    model.add(Dense(1, activation='linear'))
            else:
                # 多クラス分類
                model.add(Dense(output_shape, activation='softmax'))
            
            # オプティマイザと損失関数
            optimizer = Adam(learning_rate=self.config["learning_rate"])
            
            if self.config["target"] == "direction":
                model.compile(
                    optimizer=optimizer,
                    loss='binary_crossentropy',
                    metrics=['accuracy']
                )
            else:
                model.compile(
                    optimizer=optimizer,
                    loss='mse',
                    metrics=['mae']
                )
            
            logger.info(f"モデル構築完了")
            model.summary(print_fn=logger.info)
            
            return model
            
        except Exception as e:
            logger.error(f"モデル構築エラー: {e}")
            return None
    
    def train_model(self, model, X_train, y_train, X_val, y_val, currency_pair, timeframe):
        """
        モデルの学習
        
        Parameters:
        -----------
        model : tensorflow.keras.Model
            学習するモデル
        X_train, y_train : numpy.ndarray
            訓練データ
        X_val, y_val : numpy.ndarray
            検証データ
        currency_pair : str
            通貨ペア
        timeframe : str
            時間枠
            
        Returns:
        --------
        tensorflow.keras.Model
            学習済みモデル
        """
        logger.info(f"{currency_pair} {timeframe} のモデルを学習中")
        
        try:
            # モデル保存用のパス
            model_path = f"{self.config['models_dir']}/{currency_pair}_{timeframe}_model.h5"
            
            # コールバックの設定
            callbacks = [
                EarlyStopping(
                    monitor='val_loss',
                    patience=self.config["early_stopping_patience"],
                    restore_best_weights=True
                ),
                ModelCheckpoint(
                    filepath=model_path,
                    monitor='val_loss',
                    save_best_only=True
                ),
                ReduceLROnPlateau(
                    monitor='val_loss',
                    factor=0.5,
                    patience=5,
                    min_lr=1e-6
                )
            ]
            
            # 学習の実行
            history = model.fit(
                X_train, y_train,
                validation_data=(X_val, y_val),
                epochs=self.config["epochs"],
                batch_size=self.config["batch_size"],
                callbacks=callbacks,
                verbose=1
            )
            
            # 学習履歴の保存
            history_path = f"{self.config['models_dir']}/{currency_pair}_{timeframe}_history.pkl"
            with open(history_path, 'wb') as f:
                pickle.dump(history.history, f)
            
            # 学習曲線のプロット
            self._plot_learning_curves(history, currency_pair, timeframe)
            
            logger.info(f"モデル学習完了: {model_path}")
            
            return model
            
        except Exception as e:
            logger.error(f"モデル学習エラー: {e}")
            return None
    
    def _plot_learning_curves(self, history, currency_pair, timeframe):
        """学習曲線のプロット"""
        try:
            plt.figure(figsize=(12, 5))
            
            # 損失のプロット
            plt.subplot(1, 2, 1)
            plt.plot(history.history['loss'], label='Training Loss')
            plt.plot(history.history['val_loss'], label='Validation Loss')
            plt.title(f'{currency_pair} {timeframe} - Loss')
            plt.xlabel('Epoch')
            plt.ylabel('Loss')
            plt.legend()
            
            # メトリクスのプロット
            plt.subplot(1, 2, 2)
            if 'accuracy' in history.history:
                plt.plot(history.history['accuracy'], label='Training Accuracy')
                plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
                plt.title(f'{currency_pair} {timeframe} - Accuracy')
                plt.ylabel('Accuracy')
            else:
                plt.plot(history.history['mae'], label='Training MAE')
                plt.plot(history.history['val_mae'], label='Validation MAE')
                plt.title(f'{currency_pair} {timeframe} - MAE')
                plt.ylabel('MAE')
            
            plt.xlabel('Epoch')
            plt.legend()
            
            # 保存
            plt.tight_layout()
            plt.savefig(f"{self.config['models_dir']}/{currency_pair}_{timeframe}_learning_curves.png")
            plt.close()
            
        except Exception as e:
            logger.error(f"学習曲線プロットエラー: {e}")
    
    def evaluate_model(self, model, X_test, y_test, currency_pair, timeframe):
        """
        モデルの評価
        
        Parameters:
        -----------
        model : tensorflow.keras.Model
            評価するモデル
        X_test, y_test : numpy.ndarray
            テストデータ
        currency_pair : str
            通貨ペア
        timeframe : str
            時間枠
            
        Returns:
        --------
        dict
            評価結果
        """
        logger.info(f"{currency_pair} {timeframe} のモデルを評価中")
        
        try:
            # モデル評価
            evaluation = model.evaluate(X_test, y_test, verbose=1)
            
            results = {}
            if self.config["target"] == "direction":
                results["loss"] = evaluation[0]
                results["accuracy"] = evaluation[1]
                
                # 予測
                y_pred_prob = model.predict(X_test)
                y_pred = (y_pred_prob > 0.5).astype(int)
                
                # 勝率（正解率）
                win_rate = np.mean(y_pred.flatten() == y_test)
                results["win_rate"] = win_rate
                
                logger.info(f"評価結果: 損失={results['loss']:.4f}, 精度={results['accuracy']:.4f}, 勝率={win_rate:.4f}")
                
                # 目標勝率との比較
                target_win_rate = self.config["target_win_rate"]
                if win_rate >= target_win_rate:
                    logger.info(f"目標勝率 {target_win_rate} を達成しました！")
                else:
                    logger.warning(f"目標勝率 {target_win_rate} に達していません。モデルの改善が必要です。")
            else:
                results["loss"] = evaluation[0]
                results["mae"] = evaluation[1]
                logger.info(f"評価結果: 損失={results['loss']:.4f}, MAE={results['mae']:.4f}")
            
            # 結果の保存
            results_path = f"{self.config['models_dir']}/{currency_pair}_{timeframe}_evaluation.json"
            with open(results_path, 'w', encoding='utf-8') as f:
                json.dump(results, f, indent=4)
            
            return results
            
        except Exception as e:
            logger.error(f"モデル評価エラー: {e}")
            return None
    
    def train_all_models(self):
        """すべての通貨ペアと時間枠のモデルを学習"""
        results = {}
        
        for currency_pair in self.config["currency_pairs"]:
            results[currency_pair] = {}
            
            for timeframe in self.config["timeframes"]:
                logger.info(f"{currency_pair} {timeframe} の処理を開始")
                
                # データの読み込み
                data_path = f"{self.config['data_dir']}/{currency_pair}_{timeframe}_*.csv"
                data_files = glob.glob(data_path)
                
                if not data_files:
                    logger.warning(f"データファイルが見つかりません: {data_path}")
                    continue
                
                # 最新のデータファイルを使用
                latest_file = max(data_files, key=os.path.getctime)
                df = pd.read_csv(latest_file, index_col='timestamp', parse_dates=True)
                
                # データの前処理
                X_train, y_train, X_val, y_val, X_test, y_test = self.preprocess_data(df, currency_pair, timeframe)
                
                if X_train is None:
                    continue
                
                # モデルの構築
                input_shape = (X_train.shape[1], X_train.shape[2])
                output_shape = 1  # 二値分類または回帰
                model = self.build_model(input_shape, output_shape)
                
                if model is None:
                    continue
                
                # モデルの学習
                model = self.train_model(model, X_train, y_train, X_val, y_val, currency_pair, timeframe)
                
                if model is None:
                    continue
                
                # モデルの評価
                evaluation = self.evaluate_model(model, X_test, y_test, currency_pair, timeframe)
                
                if evaluation is not None:
                    results[currency_pair][timeframe] = evaluation
        
        # 全体の結果をまとめる
        summary_path = f"{self.config['models_dir']}/training_summary.json"
        with open(summary_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=4)
        
        logger.info(f"すべてのモデルの学習が完了しました。結果: {summary_path}")
        
        return results
    
    def optimize_hyperparameters(self, currency_pair, timeframe):
        """
        ハイパーパラメータの最適化
        
        Parameters:
        -----------
        currency_pair : str
            通貨ペア
        timeframe : str
            時間枠
            
        Returns:
        --------
        dict
            最適なハイパーパラメータ
        """
        logger.info(f"{currency_pair} {timeframe} のハイパーパラメータ最適化を開始")
        
        # 実際の実装ではBayesian Optimizationなどを使用
        # このサンプルでは簡易的な実装
        
        # 最適なハイパーパラメータ（サンプル）
        optimal_params = {
            "batch_size": 64,
            "learning_rate": 0.001,
            "dropout_rate": 0.2,
            "lstm_units": [128, 64],
            "dense_units": [32, 16]
        }
        
        # 結果の保存
        params_path = f"{self.config['models_dir']}/{currency_pair}_{timeframe}_optimal_params.json"
        with open(params_path, 'w', encoding='utf-8') as f:
            json.dump(optimal_params, f, indent=4)
        
        logger.info(f"ハイパーパラメータ最適化完了: {params_path}")
        
        return optimal_params
    
    def save_model_and_scaler(self, model, currency_pair, timeframe):
        """モデルとスケーラーの保存"""
        try:
            # モデルの保存
            model_path = f"{self.config['models_dir']}/{currency_pair}_{timeframe}_model.h5"
            model.save(model_path)
            
            # スケーラーの保存
            scaler_key = f"{currency_pair}_{timeframe}"
            if scaler_key in self.scalers:
                scaler_path = f"{self.config['models_dir']}/{currency_pair}_{timeframe}_scaler.pkl"
                with open(scaler_path, 'wb') as f:
                    pickle.dump(self.scalers[scaler_key], f)
            
            logger.info(f"モデルとスケーラーを保存しました: {model_path}")
            
        except Exception as e:
            logger.error(f"モデル保存エラー: {e}")
    
    def load_model_and_scaler(self, currency_pair, timeframe):
        """モデルとスケーラーの読み込み"""
        try:
            # モデルの読み込み
            model_path = f"{self.config['models_dir']}/{currency_pair}_{timeframe}_model.h5"
            model = tf.keras.models.load_model(model_path)
            
            # スケーラーの読み込み
            scaler_path = f"{self.config['models_dir']}/{currency_pair}_{timeframe}_scaler.pkl"
            scaler_key = f"{currency_pair}_{timeframe}"
            
            with open(scaler_path, 'rb') as f:
                self.scalers[scaler_key] = pickle.load(f)
            
            logger.info(f"モデルとスケーラーを読み込みました: {model_path}")
            
            return model
            
        except Exception as e:
            logger.error(f"モデル読み込みエラー: {e}")
            return None
    
    def predict(self, model, data, currency_pair, timeframe):
        """
        予測の実行
        
        Parameters:
        -----------
        model : tensorflow.keras.Model
            予測に使用するモデル
        data : pandas.DataFrame
            予測するデータ
        currency_pair : str
            通貨ペア
        timeframe : str
            時間枠
            
        Returns:
        --------
        numpy.ndarray
            予測結果
        """
        try:
            # データの前処理
            features = self.config["features"]
            sequence_length = self.config["sequence_length"]
            
            # 特徴量の計算
            data = self._calculate_features(data)
            
            # 欠損値の削除
            data = data.dropna()
            
            # スケーリング
            scaler_key = f"{currency_pair}_{timeframe}"
            if scaler_key not in self.scalers:
                logger.error(f"スケーラーが見つかりません: {scaler_key}")
                return None
            
            feature_data = data[features].values
            scaled_features = self.scalers[scaler_key].transform(feature_data)
            
            # 最新のシーケンスを取得
            if len(scaled_features) < sequence_length:
                logger.error(f"データが不足しています: {len(scaled_features)} < {sequence_length}")
                return None
            
            latest_sequence = scaled_features[-sequence_length:].reshape(1, sequence_length, len(features))
            
            # 予測
            prediction = model.predict(latest_sequence)
            
            logger.info(f"予測完了: {prediction}")
            
            return prediction
            
        except Exception as e:
            logger.error(f"予測エラー: {e}")
            return None
    
    def run_full_pipeline(self):
        """完全なパイプラインの実行"""
        try:
            # 1. データのダウンロード
            logger.info("データダウンロードを開始")
            self.download_all_data()
            
            # 2. モデルの学習
            logger.info("モデル学習を開始")
            results = self.train_all_models()
            
            # 3. 結果の要約
            logger.info("学習結果の要約")
            
            win_rates = []
            for currency_pair, timeframes in results.items():
                for timeframe, evaluation in timeframes.items():
                    if "win_rate" in evaluation:
                        win_rates.append(evaluation["win_rate"])
                        logger.info(f"{currency_pair} {timeframe}: 勝率 = {evaluation['win_rate']:.4f}")
            
            if win_rates:
                avg_win_rate = np.mean(win_rates)
                logger.info(f"平均勝率: {avg_win_rate:.4f}")
                
                if avg_win_rate >= self.config["target_win_rate"]:
                    logger.info(f"目標勝率 {self.config['target_win_rate']} を達成しました！")
                else:
                    logger.warning(f"目標勝率 {self.config['target_win_rate']} に達していません。モデルの改善が必要です。")
            
            return True
            
        except Exception as e:
            logger.error(f"パイプライン実行エラー: {e}")
            return False


if __name__ == "__main__":
    # 設定ファイルのパス
    config_path = "config/ai_learning_config.json"
    
    # AIシステムの初期化
    ai_system = AILearningSystem(config_path)
    
    # パイプラインの実行
    success = ai_system.run_full_pipeline()
    
    if success:
        logger.info("AI学習パイプラインが正常に完了しました")
    else:
        logger.error("AI学習パイプラインの実行中にエラーが発生しました")
