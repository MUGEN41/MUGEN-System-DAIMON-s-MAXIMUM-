#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System AI Learning Module - Integration
---------------------------------------------
このモジュールはMUGEN SystemのAI学習機能とコアシステムの統合を行います。
"""

import os
import sys
import json
import logging
from pathlib import Path

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ai_learning_integration.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AILearningIntegration:
    """
    MUGEN System AI学習統合クラス
    
    AI学習モジュールとMUGEN Systemコアの統合を行います。
    """
    
    def __init__(self, config_path=None):
        """
        初期化
        
        Parameters:
        -----------
        config_path : str
            設定ファイルのパス
        """
        # デフォルト設定
        self.default_config = {
            "ai_learning_module_path": "src/ai_learning",
            "core_module_path": "src/core",
            "enable_auto_learning": True,
            "learning_schedule": {
                "frequency": "weekly",
                "day_of_week": 6,  # 0=月曜日, 6=日曜日
                "hour": 2,  # 深夜2時
                "minute": 0
            },
            "notification": {
                "enable": True,
                "methods": ["line"],
                "events": ["learning_start", "learning_complete", "learning_error"]
            }
        }
        
        # 設定ファイルの読み込み
        self.config = self.default_config
        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                    self.config.update(loaded_config)
                logger.info(f"設定ファイルを読み込みました: {config_path}")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
        
        logger.info("AI学習統合モジュールを初期化しました")
    
    def register_with_core(self):
        """コアシステムへの登録"""
        try:
            # コアシステムの設定ファイルパス
            core_config_path = os.path.join(self.config["core_module_path"], "config/system_config.json")
            
            if not os.path.exists(core_config_path):
                logger.error(f"コアシステム設定ファイルが見つかりません: {core_config_path}")
                return False
            
            # コアシステム設定の読み込み
            with open(core_config_path, 'r', encoding='utf-8') as f:
                core_config = json.load(f)
            
            # AI学習モジュールの登録
            if "modules" not in core_config:
                core_config["modules"] = {}
            
            core_config["modules"]["ai_learning"] = {
                "enabled": True,
                "path": self.config["ai_learning_module_path"],
                "config_path": os.path.join(self.config["ai_learning_module_path"], "config/ai_learning_config.json"),
                "auto_learning": self.config["enable_auto_learning"],
                "learning_schedule": self.config["learning_schedule"]
            }
            
            # 設定の保存
            with open(core_config_path, 'w', encoding='utf-8') as f:
                json.dump(core_config, f, indent=4)
            
            logger.info(f"コアシステムにAI学習モジュールを登録しました: {core_config_path}")
            return True
            
        except Exception as e:
            logger.error(f"コアシステムへの登録中にエラーが発生しました: {e}")
            return False
    
    def setup_scheduler(self):
        """学習スケジューラのセットアップ"""
        try:
            # スケジューラ設定ファイルパス
            scheduler_config_path = os.path.join(self.config["core_module_path"], "config/scheduler_config.json")
            
            # 既存の設定を読み込むか、新規作成
            scheduler_config = {}
            if os.path.exists(scheduler_config_path):
                with open(scheduler_config_path, 'r', encoding='utf-8') as f:
                    scheduler_config = json.load(f)
            
            # AI学習タスクの追加
            if "tasks" not in scheduler_config:
                scheduler_config["tasks"] = []
            
            # 既存のAI学習タスクを削除
            scheduler_config["tasks"] = [task for task in scheduler_config["tasks"] 
                                        if task.get("type") != "ai_learning"]
            
            # 新しいAI学習タスクを追加
            ai_learning_task = {
                "type": "ai_learning",
                "name": "AI Model Training",
                "enabled": self.config["enable_auto_learning"],
                "schedule": self.config["learning_schedule"],
                "command": f"python {os.path.join(self.config['ai_learning_module_path'], 'main.py')} --mode full",
                "notification": self.config["notification"]
            }
            
            scheduler_config["tasks"].append(ai_learning_task)
            
            # 設定の保存
            with open(scheduler_config_path, 'w', encoding='utf-8') as f:
                json.dump(scheduler_config, f, indent=4)
            
            logger.info(f"学習スケジューラを設定しました: {scheduler_config_path}")
            return True
            
        except Exception as e:
            logger.error(f"スケジューラのセットアップ中にエラーが発生しました: {e}")
            return False
    
    def setup_notification(self):
        """通知設定のセットアップ"""
        try:
            # 通知設定ファイルパス
            notification_config_path = os.path.join(self.config["core_module_path"], "config/notification_config.json")
            
            # 既存の設定を読み込むか、新規作成
            notification_config = {}
            if os.path.exists(notification_config_path):
                with open(notification_config_path, 'r', encoding='utf-8') as f:
                    notification_config = json.load(f)
            
            # AI学習関連の通知設定を追加
            if "events" not in notification_config:
                notification_config["events"] = {}
            
            # AI学習関連のイベント設定
            notification_config["events"]["learning_start"] = {
                "message": "AI学習を開始しました",
                "level": "info",
                "methods": self.config["notification"]["methods"]
            }
            
            notification_config["events"]["learning_complete"] = {
                "message": "AI学習が完了しました",
                "level": "info",
                "methods": self.config["notification"]["methods"]
            }
            
            notification_config["events"]["learning_error"] = {
                "message": "AI学習中にエラーが発生しました",
                "level": "error",
                "methods": self.config["notification"]["methods"]
            }
            
            # 設定の保存
            with open(notification_config_path, 'w', encoding='utf-8') as f:
                json.dump(notification_config, f, indent=4)
            
            logger.info(f"通知設定を行いました: {notification_config_path}")
            return True
            
        except Exception as e:
            logger.error(f"通知設定中にエラーが発生しました: {e}")
            return False
    
    def integrate(self):
        """統合処理の実行"""
        logger.info("AI学習モジュールの統合を開始します")
        
        # コアシステムへの登録
        if not self.register_with_core():
            logger.error("コアシステムへの登録に失敗しました")
            return False
        
        # スケジューラのセットアップ
        if not self.setup_scheduler():
            logger.error("スケジューラのセットアップに失敗しました")
            return False
        
        # 通知設定のセットアップ
        if not self.setup_notification():
            logger.error("通知設定に失敗しました")
            return False
        
        logger.info("AI学習モジュールの統合が完了しました")
        return True

def main():
    """メイン関数"""
    # 設定ファイルのパス
    config_path = "config/ai_learning_integration_config.json"
    
    # 統合モジュールの初期化
    integration = AILearningIntegration(config_path)
    
    # 統合の実行
    success = integration.integrate()
    
    if success:
        logger.info("AI学習モジュールの統合が正常に完了しました")
        return 0
    else:
        logger.error("AI学習モジュールの統合中にエラーが発生しました")
        return 1

if __name__ == "__main__":
    sys.exit(main())
