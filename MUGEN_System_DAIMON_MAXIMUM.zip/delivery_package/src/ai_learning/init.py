#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System AI Learning Module - Initialization
-----------------------------------------------
このモジュールはMUGEN SystemのAI学習機能の初期化スクリプトです。
"""

import os
import sys
import logging
from pathlib import Path

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ai_learning_init.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def create_directory_structure():
    """ディレクトリ構造の作成"""
    try:
        # 必要なディレクトリの作成
        directories = [
            "data",
            "models",
            "logs"
        ]
        
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            logger.info(f"ディレクトリを作成しました: {directory}")
        
        return True
    except Exception as e:
        logger.error(f"ディレクトリ構造の作成中にエラーが発生しました: {e}")
        return False

def check_tensorflow_cuda():
    """TensorflowとCUDAの確認"""
    try:
        import tensorflow as tf
        
        # TensorFlowのバージョン確認
        tf_version = tf.__version__
        logger.info(f"TensorFlow バージョン: {tf_version}")
        
        # GPU確認
        gpus = tf.config.list_physical_devices('GPU')
        if gpus:
            logger.info(f"利用可能なGPU: {len(gpus)}個")
            for gpu in gpus:
                logger.info(f"  - {gpu}")
            
            # GPU設定
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)
            
            # CUDAバージョン確認
            cuda_version = tf.sysconfig.get_build_info()["cuda_version"]
            logger.info(f"CUDA バージョン: {cuda_version}")
            
            return True
        else:
            logger.warning("GPUが見つかりません。CPUを使用します。")
            return False
    except ImportError:
        logger.error("TensorFlowがインストールされていません。")
        return False
    except Exception as e:
        logger.error(f"TensorFlow/CUDA確認中にエラーが発生しました: {e}")
        return False

def main():
    """初期化メイン関数"""
    logger.info("MUGEN System AI学習モジュールの初期化を開始します")
    
    # ディレクトリ構造の作成
    if not create_directory_structure():
        logger.error("初期化に失敗しました: ディレクトリ構造の作成に失敗")
        return 1
    
    # TensorflowとCUDAの確認
    if not check_tensorflow_cuda():
        logger.warning("TensorFlow/GPUの確認に問題があります。CPUモードで続行します。")
    
    logger.info("MUGEN System AI学習モジュールの初期化が完了しました")
    return 0

if __name__ == "__main__":
    sys.exit(main())
