#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System AI Learning Module - Main Interface
-----------------------------------------------
このモジュールはMUGEN SystemのAI学習機能のメインインターフェースを提供します。
"""

import os
import sys
import argparse
import logging
from datetime import datetime
from ai_learning_system import AILearningSystem

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ai_learning_main.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def parse_arguments():
    """コマンドライン引数の解析"""
    parser = argparse.ArgumentParser(description='MUGEN System AI学習モジュール')
    
    parser.add_argument('--config', type=str, default='config/ai_learning_config.json',
                        help='設定ファイルのパス')
    
    parser.add_argument('--mode', type=str, choices=['download', 'train', 'optimize', 'predict', 'full'],
                        default='full', help='実行モード')
    
    parser.add_argument('--currency_pair', type=str, default=None,
                        help='通貨ペア (例: USDJPY)')
    
    parser.add_argument('--timeframe', type=str, default=None,
                        help='時間枠 (例: 1m, 1h)')
    
    return parser.parse_args()

def main():
    """メイン関数"""
    # 引数の解析
    args = parse_arguments()
    
    try:
        # 開始メッセージ
        logger.info("MUGEN System AI学習モジュールを開始します")
        logger.info(f"設定ファイル: {args.config}")
        logger.info(f"実行モード: {args.mode}")
        
        # AIシステムの初期化
        ai_system = AILearningSystem(args.config)
        
        # モードに応じた処理
        if args.mode == 'download':
            logger.info("データダウンロードモードを実行します")
            if args.currency_pair and args.timeframe:
                # 特定の通貨ペアと時間枠のデータをダウンロード
                start_date = ai_system.config["date_range"]["start"]
                end_date = ai_system.config["date_range"]["end"]
                ai_system.download_data(args.currency_pair, args.timeframe, start_date, end_date)
            else:
                # すべてのデータをダウンロード
                ai_system.download_all_data()
        
        elif args.mode == 'train':
            logger.info("モデル学習モードを実行します")
            if args.currency_pair and args.timeframe:
                # 特定の通貨ペアと時間枠のモデルを学習
                logger.info(f"{args.currency_pair} {args.timeframe} のモデルを学習します")
                
                # データの読み込み
                data_path = f"{ai_system.config['data_dir']}/{args.currency_pair}_{args.timeframe}_*.csv"
                import glob
                data_files = glob.glob(data_path)
                
                if not data_files:
                    logger.error(f"データファイルが見つかりません: {data_path}")
                    return
                
                # 最新のデータファイルを使用
                import pandas as pd
                latest_file = max(data_files, key=os.path.getctime)
                df = pd.read_csv(latest_file, index_col='timestamp', parse_dates=True)
                
                # データの前処理
                X_train, y_train, X_val, y_val, X_test, y_test = ai_system.preprocess_data(
                    df, args.currency_pair, args.timeframe
                )
                
                if X_train is None:
                    return
                
                # モデルの構築
                input_shape = (X_train.shape[1], X_train.shape[2])
                output_shape = 1  # 二値分類または回帰
                model = ai_system.build_model(input_shape, output_shape)
                
                if model is None:
                    return
                
                # モデルの学習
                model = ai_system.train_model(
                    model, X_train, y_train, X_val, y_val, args.currency_pair, args.timeframe
                )
                
                if model is None:
                    return
                
                # モデルの評価
                ai_system.evaluate_model(model, X_test, y_test, args.currency_pair, args.timeframe)
            else:
                # すべてのモデルを学習
                ai_system.train_all_models()
        
        elif args.mode == 'optimize':
            logger.info("ハイパーパラメータ最適化モードを実行します")
            if args.currency_pair and args.timeframe:
                # 特定の通貨ペアと時間枠のハイパーパラメータを最適化
                ai_system.optimize_hyperparameters(args.currency_pair, args.timeframe)
            else:
                logger.error("通貨ペアと時間枠を指定してください")
        
        elif args.mode == 'predict':
            logger.info("予測モードを実行します")
            if args.currency_pair and args.timeframe:
                # 特定の通貨ペアと時間枠の予測を実行
                
                # モデルの読み込み
                model = ai_system.load_model_and_scaler(args.currency_pair, args.timeframe)
                
                if model is None:
                    return
                
                # データの読み込み
                data_path = f"{ai_system.config['data_dir']}/{args.currency_pair}_{args.timeframe}_*.csv"
                import glob
                data_files = glob.glob(data_path)
                
                if not data_files:
                    logger.error(f"データファイルが見つかりません: {data_path}")
                    return
                
                # 最新のデータファイルを使用
                import pandas as pd
                latest_file = max(data_files, key=os.path.getctime)
                df = pd.read_csv(latest_file, index_col='timestamp', parse_dates=True)
                
                # 予測の実行
                prediction = ai_system.predict(model, df, args.currency_pair, args.timeframe)
                
                if prediction is not None:
                    if ai_system.config["target"] == "direction":
                        direction = "上昇" if prediction[0][0] > 0.5 else "下降"
                        confidence = prediction[0][0] if prediction[0][0] > 0.5 else 1 - prediction[0][0]
                        logger.info(f"予測結果: {direction} (確信度: {confidence:.4f})")
                    else:
                        logger.info(f"予測結果: {prediction[0][0]:.4f}")
            else:
                logger.error("通貨ペアと時間枠を指定してください")
        
        elif args.mode == 'full':
            logger.info("完全パイプラインモードを実行します")
            ai_system.run_full_pipeline()
        
        # 終了メッセージ
        logger.info("MUGEN System AI学習モジュールを終了します")
        
    except Exception as e:
        logger.error(f"実行中にエラーが発生しました: {e}", exc_info=True)
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
