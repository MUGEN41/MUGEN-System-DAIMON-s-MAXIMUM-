#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
MUGEN System (DAIMON's MAXIMUM) - 検知回避モジュール
不自然な勝率パターンや取引パターンを回避し、長期間の安全な自動売買を実現するモジュール
"""

import os
import sys
import json
import time
import random
import logging
import numpy as np
import datetime as dt
from pathlib import Path
from typing import Dict, Any, List, Optional, Union, Tuple

# ロギング設定
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("detection_avoidance.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("Detection_Avoidance")

class DetectionAvoidanceSystem:
    """
    検知回避システムクラス
    不自然な勝率パターンや取引パターンを回避し、長期間の安全な自動売買を実現する
    """
    
    def __init__(self, config_path: str = "config/detection_avoidance_config.json"):
        """
        初期化
        
        Args:
            config_path: 設定ファイルのパス
        """
        self.config_path = Path(config_path)
        self.config_dir = self.config_path.parent
        self.config: Dict[str, Any] = {}
        self.trade_history: List[Dict[str, Any]] = []
        self.daily_stats: Dict[str, Any] = {
            "date": dt.datetime.now().strftime("%Y-%m-%d"),
            "wins": 0,
            "losses": 0,
            "total_trades": 0,
            "win_rate": 0.0,
            "consecutive_wins": 0,
            "consecutive_losses": 0,
            "max_consecutive_wins": 0,
            "max_consecutive_losses": 0,
            "profit": 0.0,
            "account_balance": 100000.0  # 初期残高
        }
        self._ensure_config_dir()
        self._load_config()
        self._load_trade_history()
    
    def _ensure_config_dir(self) -> None:
        """設定ディレクトリが存在することを確認"""
        if not self.config_dir.exists():
            self.config_dir.mkdir(parents=True)
            logger.info(f"設定ディレクトリを作成しました: {self.config_dir}")
    
    def _load_config(self) -> None:
        """設定ファイルを読み込む"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                logger.info("検知回避設定を読み込みました")
            except Exception as e:
                logger.error(f"設定ファイルの読み込みに失敗しました: {e}")
                self.config = {}
        else:
            logger.info("設定ファイルが存在しないため、新規作成します")
            # 初期設定
            self.config = {
                "enabled": True,
                "win_rate_settings": {
                    "target_win_rate": 0.8,  # 目標勝率
                    "win_rate_tolerance": 0.05,  # 許容誤差
                    "max_consecutive_wins": 8,  # 最大連勝数
                    "max_consecutive_losses": 3,  # 最大連敗数
                    "win_rate_adjustment_period": 20  # 勝率調整の期間（取引回数）
                },
                "trade_pattern_settings": {
                    "randomize_entry_timing": True,  # エントリータイミングのランダム化
                    "randomize_trade_size": True,  # 取引サイズのランダム化
                    "trade_size_variation": 0.1,  # 取引サイズの変動幅（±10%）
                    "min_time_between_trades": 30,  # 取引間の最小時間（秒）
                    "max_time_between_trades": 300  # 取引間の最大時間（秒）
                },
                "account_balance_settings": {
                    "dynamic_trade_count": True,  # 口座残高に応じた取引回数の動的調整
                    "base_daily_trades": 100,  # 基本日次取引回数
                    "max_daily_trades": 300,  # 最大日次取引回数
                    "min_daily_trades": 100,  # 最小日次取引回数
                    "trade_count_adjustment_factor": 0.5  # 取引回数調整係数
                },
                "risk_management_settings": {
                    "risk_level_monitoring": True,  # リスクレベル監視
                    "auto_risk_adjustment": True,  # 自動リスク調整
                    "max_daily_loss_percentage": 0.05,  # 最大日次損失率（5%）
                    "max_drawdown_percentage": 0.15,  # 最大ドローダウン率（15%）
                    "risk_reduction_factor": 0.5  # リスク削減係数
                },
                "last_updated": dt.datetime.now().isoformat()
            }
            self._save_config()
    
    def _save_config(self) -> None:
        """設定ファイルを保存する"""
        try:
            # 更新日時を記録
            self.config["last_updated"] = dt.datetime.now().isoformat()
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
            logger.info("検知回避設定を保存しました")
        except Exception as e:
            logger.error(f"設定ファイルの保存に失敗しました: {e}")
    
    def _load_trade_history(self) -> None:
        """取引履歴を読み込む"""
        history_path = self.config_dir / "trade_history.json"
        
        if history_path.exists():
            try:
                with open(history_path, 'r', encoding='utf-8') as f:
                    self.trade_history = json.load(f)
                logger.info(f"{len(self.trade_history)}件の取引履歴を読み込みました")
                
                # 最新の日付の統計情報を更新
                if self.trade_history:
                    latest_trade = self.trade_history[-1]
                    trade_date = dt.datetime.fromisoformat(latest_trade["timestamp"]).strftime("%Y-%m-%d")
                    today = dt.datetime.now().strftime("%Y-%m-%d")
                    
                    if trade_date == today:
                        # 今日の取引がある場合、統計情報を更新
                        today_trades = [t for t in self.trade_history if dt.datetime.fromisoformat(t["timestamp"]).strftime("%Y-%m-%d") == today]
                        wins = sum(1 for t in today_trades if t["result"] == "win")
                        losses = len(today_trades) - wins
                        
                        self.daily_stats = {
                            "date": today,
                            "wins": wins,
                            "losses": losses,
                            "total_trades": len(today_trades),
                            "win_rate": wins / len(today_trades) if len(today_trades) > 0 else 0.0,
                            "consecutive_wins": self._calculate_current_consecutive("win"),
                            "consecutive_losses": self._calculate_current_consecutive("loss"),
                            "max_consecutive_wins": self._calculate_max_consecutive("win"),
                            "max_consecutive_losses": self._calculate_max_consecutive("loss"),
                            "profit": sum(t["profit"] for t in today_trades),
                            "account_balance": latest_trade["account_balance"]
                        }
                        
                        logger.info(f"今日の統計情報を更新しました: 勝率 {self.daily_stats['win_rate']:.2f}, 取引数 {self.daily_stats['total_trades']}")
            except Exception as e:
                logger.error(f"取引履歴の読み込みに失敗しました: {e}")
                self.trade_history = []
        else:
            logger.info("取引履歴が存在しないため、新規作成します")
            self.trade_history = []
    
    def _save_trade_history(self) -> None:
        """取引履歴を保存する"""
        try:
            history_path = self.config_dir / "trade_history.json"
            
            with open(history_path, 'w', encoding='utf-8') as f:
                json.dump(self.trade_history, f, indent=4, ensure_ascii=False)
            logger.info(f"{len(self.trade_history)}件の取引履歴を保存しました")
        except Exception as e:
            logger.error(f"取引履歴の保存に失敗しました: {e}")
    
    def _calculate_current_consecutive(self, result_type: str) -> int:
        """
        現在の連続勝利または連続敗北数を計算する
        
        Args:
            result_type: 結果タイプ（"win" または "loss"）
        
        Returns:
            int: 連続数
        """
        if not self.trade_history:
            return 0
        
        count = 0
        for trade in reversed(self.trade_history):
            if trade["result"] == result_type:
                count += 1
            else:
                break
        
        return count
    
    def _calculate_max_consecutive(self, result_type: str) -> int:
        """
        最大連続勝利または連続敗北数を計算する
        
        Args:
            result_type: 結果タイプ（"win" または "loss"）
        
        Returns:
            int: 最大連続数
        """
        if not self.trade_history:
            return 0
        
        max_count = 0
        current_count = 0
        
        for trade in self.trade_history:
            if trade["result"] == result_type:
                current_count += 1
                max_count = max(max_count, current_count)
            else:
                current_count = 0
        
        return max_count
    
    def should_adjust_win_rate(self) -> bool:
        """
        勝率を調整すべきかどうかを判断する
        
        Returns:
            bool: 勝率を調整すべきかどうか
        """
        if not self.config.get("enabled", True):
            return False
        
        if not self.config.get("win_rate_settings", {}).get("target_win_rate"):
            return False
        
        # 取引数が少ない場合は調整しない
        min_trades = self.config.get("win_rate_settings", {}).get("win_rate_adjustment_period", 20)
        if self.daily_stats["total_trades"] < min_trades:
            return False
        
        target_win_rate = self.config.get("win_rate_settings", {}).get("target_win_rate", 0.8)
        tolerance = self.config.get("win_rate_settings", {}).get("win_rate_tolerance", 0.05)
        
        current_win_rate = self.daily_stats["win_rate"]
        
        # 勝率が目標範囲外の場合は調整
        if current_win_rate < target_win_rate - tolerance or current_win_rate > target_win_rate + tolerance:
            logger.info(f"勝率調整が必要です: 現在の勝率 {current_win_rate:.2f}, 目標勝率 {target_win_rate:.2f}±{tolerance:.2f}")
            return True
        
        # 連勝数が最大値を超えている場合は調整
        max_consecutive_wins = self.config.get("win_rate_settings", {}).get("max_consecutive_wins", 8)
        if self.daily_stats["consecutive_wins"] >= max_consecutive_wins:
            logger.info(f"連勝数が最大値を超えています: {self.daily_stats['consecutive_wins']} >= {max_consecutive_wins}")
            return True
        
        # 連敗数が最大値を超えている場合は調整
        max_consecutive_losses = self.config.get("win_rate_settings", {}).get("max_consecutive_losses", 3)
        if self.daily_stats["consecutive_losses"] >= max_consecutive_losses:
            logger.info(f"連敗数が最大値を超えています: {self.daily_stats['consecutive_losses']} >= {max_consecutive_losses}")
            return True
        
        return False
    
    def determine_next_trade_result(self) -> str:
        """
        次の取引結果を決定する
        
        Returns:
            str: 次の取引結果（"win" または "loss"）
        """
        if not self.config.get("enabled", True):
            # 検知回避が無効の場合はランダムに決定
            return random.choice(["win", "loss"])
        
        target_win_rate = self.config.get("win_rate_settings", {}).get("target_win_rate", 0.8)
        
        # 勝率調整が必要かどうかを判断
        if self.should_adjust_win_rate():
            current_win_rate = self.daily_stats["win_rate"]
            
            if current_win_rate > target_win_rate:
                # 勝率が高すぎる場合は負けを増やす
                logger.info(f"勝率が高すぎるため、次の取引は負けにします: {current_win_rate:.2f} > {target_win_rate:.2f}")
                return "loss"
            elif current_win_rate < target_win_rate:
                # 勝率が低すぎる場合は勝ちを増やす
                logger.info(f"勝率が低すぎるため、次の取引は勝ちにします: {current_win_rate:.2f} < {target_win_rate:.2f}")
                return "win"
        
        # 連勝数が最大値を超えている場合は負けにする
        max_consecutive_wins = self.config.get("win_rate_settings", {}).get("max_consecutive_wins", 8)
        if self.daily_stats["consecutive_wins"] >= max_consecutive_wins:
            logger.info(f"連勝数が最大値を超えているため、次の取引は負けにします: {self.daily_stats['consecutive_wins']} >= {max_consecutive_wins}")
            return "loss"
        
        # 連敗数が最大値を超えている場合は勝ちにする
        max_consecutive_losses = self.config.get("win_rate_settings", {}).get("max_consecutive_losses", 3)
        if self.daily_stats["consecutive_losses"] >= max_consecutive_losses:
            logger.info(f"連敗数が最大値を超えているため、次の取引は勝ちにします: {self.daily_stats['consecutive_losses']} >= {max_consecutive_losses}")
            return "win"
        
        # 上記の条件に該当しない場合は、目標勝率に基づいて確率的に決定
        if random.random() < target_win_rate:
            return "win"
        else:
            return "loss"
    
    def calculate_trade_size(self, account_balance: float) -> float:
        """
        取引サイズを計算する
        
        Args:
            account_balance: 口座残高
        
        Returns:
            float: 取引サイズ
        """
        # 基本取引サイズは口座残高の1%
        base_size = account_balance * 0.01
        
        if not self.config.get("enabled", True) or not self.config.get("trade_pattern_settings", {}).get("randomize_trade_size", True):
            return base_size
        
        # 取引サイズのランダム化
        variation = self.config.get("trade_pattern_settings", {}).get("trade_size_variation", 0.1)
        random_factor = 1.0 + random.uniform(-variation, variation)
        
        # 10円単位で四捨五入
        trade_size = round(base_size * random_factor / 10) * 10
        
        return max(10, trade_size)  # 最小取引サイズは10円
    
    def calculate_wait_time(self) -> int:
        """
        次の取引までの待機時間を計算する
        
        Returns:
            int: 待機時間（秒）
        """
        if not self.config.get("enabled", True) or not self.config.get("trade_pattern_settings", {}).get("randomize_entry_timing", True):
            return 0
        
        min_time = self.config.get("trade_pattern_settings", {}).get("min_time_between_trades", 30)
        max_time = self.config.get("trade_pattern_settings", {}).get("max_time_between_trades", 300)
        
        # 指数分布を使用して、より自然な間隔を生成
        lambda_param = 1.0 / ((min_time + max_time) / 2)
        wait_time = int(random.expovariate(lambda_param))
        
        # 範囲内に収める
        wait_time = max(min_time, min(wait_time, max_time))
        
        return wait_time
    
    def calculate_daily_trade_count(self, account_balance: float) -> int:
        """
        日次取引回数を計算する
        
        Args:
            account_balance: 口座残高
        
        Returns:
            int: 日次取引回数
        """
        if not self.config.get("enabled", True) or not self.config.get("account_balance_settings", {}).get("dynamic_trade_count", True):
            return self.config.get("account_balance_settings", {}).get("base_daily_trades", 100)
        
        base_trades = self.config.get("account_balance_settings", {}).get("base_daily_trades", 100)
        max_trades = self.config.get("account_balance_settings", {}).get("max_daily_trades", 300)
        min_trades = self.config.get("account_balance_settings", {}).get("min_daily_trades", 100)
        adjustment_factor = self.config.get("account_balance_settings", {}).get("trade_count_adjustment_factor", 0.5)
        
        # 口座残高に応じて取引回数を調整
        # 初期残高（100,000円）の場合は基本取引回数
        # 残高が増えるほど取引回数も増加
        initial_balance = 100000.0
        balance_ratio = account_balance / initial_balance
        
        # 対数関数を使用して、残高の増加に対して取引回数が緩やかに増加するようにする
        if balance_ratio <= 1.0:
            trade_count = base_trades
        else:
            additional_trades = int(adjustment_factor * base_trades * np.log10(balance_ratio))
            trade_count = base_trades + additional_trades
        
        # 範囲内に収める
        trade_count = max(min_trades, min(trade_count, max_trades))
        
        return trade_count
    
    def assess_risk_level(self) -> str:
        """
        現在のリスクレベルを評価する
        
        Returns:
            str: リスクレベル（"low", "medium", "high", "critical"）
        """
        if not self.config.get("enabled", True) or not self.config.get("risk_management_settings", {}).get("risk_level_monitoring", True):
            return "medium"
        
        # 日次損失率の計算
        daily_profit = self.daily_stats["profit"]
        account_balance = self.daily_stats["account_balance"]
        daily_loss_percentage = abs(daily_profit) / account_balance if daily_profit < 0 else 0
        
        # ドローダウンの計算
        max_balance = account_balance
        for trade in self.trade_history:
            max_balance = max(max_balance, trade["account_balance"])
        
        drawdown_percentage = (max_balance - account_balance) / max_balance if max_balance > account_balance else 0
        
        # リスクレベルの評価
        max_daily_loss = self.config.get("risk_management_settings", {}).get("max_daily_loss_percentage", 0.05)
        max_drawdown = self.config.get("risk_management_settings", {}).get("max_drawdown_percentage", 0.15)
        
        if daily_loss_percentage >= max_daily_loss or drawdown_percentage >= max_drawdown:
            return "critical"
        elif daily_loss_percentage >= max_daily_loss * 0.7 or drawdown_percentage >= max_drawdown * 0.7:
            return "high"
        elif daily_loss_percentage >= max_daily_loss * 0.4 or drawdown_percentage >= max_drawdown * 0.4:
            return "medium"
        else:
            return "low"
    
    def adjust_risk_parameters(self, risk_level: str) -> Dict[str, Any]:
        """
        リスクレベルに応じてパラメータを調整する
        
        Args:
            risk_level: リスクレベル（"low", "medium", "high", "critical"）
        
        Returns:
            Dict[str, Any]: 調整されたパラメータ
        """
        if not self.config.get("enabled", True) or not self.config.get("risk_management_settings", {}).get("auto_risk_adjustment", True):
            return {}
        
        risk_reduction_factor = self.config.get("risk_management_settings", {}).get("risk_reduction_factor", 0.5)
        
        # 基本パラメータ
        params = {
            "trade_size_factor": 1.0,  # 取引サイズの係数
            "trade_frequency_factor": 1.0,  # 取引頻度の係数
            "win_rate_target_adjustment": 0.0  # 目標勝率の調整値
        }
        
        # リスクレベルに応じてパラメータを調整
        if risk_level == "medium":
            params["trade_size_factor"] = 0.9
            params["trade_frequency_factor"] = 0.9
            params["win_rate_target_adjustment"] = 0.05
        elif risk_level == "high":
            params["trade_size_factor"] = 0.7
            params["trade_frequency_factor"] = 0.7
            params["win_rate_target_adjustment"] = 0.1
        elif risk_level == "critical":
            params["trade_size_factor"] = risk_reduction_factor
            params["trade_frequency_factor"] = risk_reduction_factor
            params["win_rate_target_adjustment"] = 0.15
        
        logger.info(f"リスクレベル {risk_level} に基づいてパラメータを調整しました: {params}")
        
        return params
    
    def record_trade_result(self, result: str, profit: float, account_balance: float, timestamp: dt.datetime = None) -> None:
        """
        取引結果を記録する
        
        Args:
            result: 取引結果（"win" または "loss"）
            profit: 利益（負の場合は損失）
            account_balance: 取引後の口座残高
            timestamp: タイムスタンプ（指定しない場合は現在時刻）
        """
        if timestamp is None:
            timestamp = dt.datetime.now()
        
        trade_record = {
            "result": result,
            "profit": profit,
            "account_balance": account_balance,
            "timestamp": timestamp.isoformat()
        }
        
        self.trade_history.append(trade_record)
        
        # 日付が変わった場合は統計情報をリセット
        trade_date = timestamp.strftime("%Y-%m-%d")
        if trade_date != self.daily_stats["date"]:
            self.daily_stats = {
                "date": trade_date,
                "wins": 1 if result == "win" else 0,
                "losses": 1 if result == "loss" else 0,
                "total_trades": 1,
                "win_rate": 1.0 if result == "win" else 0.0,
                "consecutive_wins": 1 if result == "win" else 0,
                "consecutive_losses": 1 if result == "loss" else 0,
                "max_consecutive_wins": 1 if result == "win" else 0,
                "max_consecutive_losses": 1 if result == "loss" else 0,
                "profit": profit,
                "account_balance": account_balance
            }
        else:
            # 統計情報を更新
            self.daily_stats["wins"] += 1 if result == "win" else 0
            self.daily_stats["losses"] += 1 if result == "loss" else 0
            self.daily_stats["total_trades"] += 1
            self.daily_stats["win_rate"] = self.daily_stats["wins"] / self.daily_stats["total_trades"]
            
            # 連勝・連敗の更新
            if result == "win":
                self.daily_stats["consecutive_wins"] += 1
                self.daily_stats["consecutive_losses"] = 0
                self.daily_stats["max_consecutive_wins"] = max(self.daily_stats["max_consecutive_wins"], self.daily_stats["consecutive_wins"])
            else:
                self.daily_stats["consecutive_losses"] += 1
                self.daily_stats["consecutive_wins"] = 0
                self.daily_stats["max_consecutive_losses"] = max(self.daily_stats["max_consecutive_losses"], self.daily_stats["consecutive_losses"])
            
            self.daily_stats["profit"] += profit
            self.daily_stats["account_balance"] = account_balance
        
        logger.info(f"取引結果を記録しました: {result}, 利益: {profit}, 残高: {account_balance}, 勝率: {self.daily_stats['win_rate']:.2f}")
        
        # 取引履歴を保存
        self._save_trade_history()
    
    def get_daily_stats(self) -> Dict[str, Any]:
        """
        日次統計情報を取得する
        
        Returns:
            Dict[str, Any]: 日次統計情報
        """
        return self.daily_stats
    
    def get_risk_adjusted_parameters(self) -> Dict[str, Any]:
        """
        リスク調整済みのパラメータを取得する
        
        Returns:
            Dict[str, Any]: リスク調整済みのパラメータ
        """
        risk_level = self.assess_risk_level()
        return self.adjust_risk_parameters(risk_level)
    
    def should_continue_trading(self) -> bool:
        """
        取引を継続すべきかどうかを判断する
        
        Returns:
            bool: 取引を継続すべきかどうか
        """
        # 日次取引回数の上限に達した場合は取引を停止
        daily_trade_count = self.calculate_daily_trade_count(self.daily_stats["account_balance"])
        if self.daily_stats["total_trades"] >= daily_trade_count:
            logger.info(f"日次取引回数の上限に達したため、取引を停止します: {self.daily_stats['total_trades']} >= {daily_trade_count}")
            return False
        
        # リスクレベルがcriticalの場合は取引を停止
        risk_level = self.assess_risk_level()
        if risk_level == "critical":
            logger.warning(f"リスクレベルが{risk_level}のため、取引を停止します")
            return False
        
        # 連敗数が最大値を超えている場合は取引を停止
        max_consecutive_losses = self.config.get("win_rate_settings", {}).get("max_consecutive_losses", 3)
        if self.daily_stats["consecutive_losses"] > max_consecutive_losses:
            logger.warning(f"連敗数が最大値を超えているため、取引を停止します: {self.daily_stats['consecutive_losses']} > {max_consecutive_losses}")
            return False
        
        return True
