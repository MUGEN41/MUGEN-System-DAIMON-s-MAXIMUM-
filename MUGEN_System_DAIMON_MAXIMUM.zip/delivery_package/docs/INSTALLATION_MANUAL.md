# MUGEN System（DAIMON's MAXIMUM）インストール手順書

## 目次

1. [システム要件](#システム要件)
2. [前提条件](#前提条件)
3. [Pythonのインストール](#pythonのインストール)
4. [TensorFlowとCUDAのインストール](#tensorflowとcudaのインストール)
5. [MUGEN Systemのインストール](#mugen-systemのインストール)
6. [初期設定](#初期設定)
7. [動作確認](#動作確認)
8. [トラブルシューティング](#トラブルシューティング)
9. [アップデート方法](#アップデート方法)

## システム要件

### ハードウェア要件

- **CPU**: Intel Core i5/AMD Ryzen 5以上（推奨：Intel Core i7/AMD Ryzen 7以上）
- **メモリ**: 16GB以上（推奨：32GB以上）
- **ストレージ**: 100GB以上の空き容量（SSD推奨）
- **GPU**: NVIDIA GeForce GTX 1060 6GB以上（推奨：RTX 2060以上）
  - CUDA対応GPUであること
  - AI学習を高速化するためにはGPUが強く推奨されます

### ソフトウェア要件

- **OS**:
  - Windows 10/11 64bit
  - Ubuntu 20.04 LTS以上
  - macOS 11.0以上（M1/M2チップの場合は特別な設定が必要）
- **Python**: 3.8〜3.11
- **CUDA**: 11.2以上（GPUを使用する場合）
- **cuDNN**: 8.1以上（GPUを使用する場合）

## 前提条件

インストールを開始する前に、以下の点を確認してください：

1. システム管理者権限（管理者アカウント）を持っていること
2. インターネット接続が安定していること
3. ファイアウォールやウイルス対策ソフトが一時的に無効化されているか、適切に設定されていること

## Pythonのインストール

### Windows

1. [Python公式サイト](https://www.python.org/downloads/)から最新の安定版（3.8〜3.11）をダウンロード
2. インストーラを実行し、「Add Python to PATH」オプションを必ずチェック
3. 「Install Now」をクリックしてインストール
4. インストール完了後、コマンドプロンプトを開き、以下のコマンドでPythonが正しくインストールされたか確認：
   ```
   python --version
   pip --version
   ```

### Ubuntu

1. 以下のコマンドを実行してPythonとpipをインストール：
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip python3-venv
   ```
2. 以下のコマンドでインストールを確認：
   ```bash
   python3 --version
   pip3 --version
   ```

### macOS

1. [Python公式サイト](https://www.python.org/downloads/)から最新の安定版（3.8〜3.11）をダウンロード
2. インストーラを実行し、指示に従ってインストール
3. ターミナルを開き、以下のコマンドでPythonが正しくインストールされたか確認：
   ```bash
   python3 --version
   pip3 --version
   ```

## TensorFlowとCUDAのインストール

### Windows

#### CUDA Toolkitのインストール

1. [NVIDIA CUDA Toolkit](https://developer.nvidia.com/cuda-downloads)から最新の互換性のあるバージョン（11.2以上推奨）をダウンロード
2. インストーラを実行し、「Express Installation」を選択
3. インストール完了後、システムを再起動

#### cuDNNのインストール

1. [NVIDIA Developer](https://developer.nvidia.com/cudnn)からアカウント登録後、cuDNNをダウンロード（CUDAバージョンに対応したものを選択）
2. ダウンロードしたzipファイルを解凍
3. 解凍したフォルダ内のファイルを以下のようにCUDAインストールディレクトリにコピー：
   - `bin` → `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.x\bin`
   - `include` → `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.x\include`
   - `lib` → `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.x\lib`

#### TensorFlowのインストール

1. コマンドプロンプトを管理者権限で開き、以下のコマンドを実行：
   ```
   pip install tensorflow==2.10.0
   ```
2. インストールを確認：
   ```
   python -c "import tensorflow as tf; print(tf.__version__); print('GPU Available: ', tf.config.list_physical_devices('GPU'))"
   ```
   GPUが認識されていれば、`GPU Available: [PhysicalDevice(name='/physical_device:GPU:0', device_type='GPU')]`のような出力が表示されます。

### Ubuntu

#### CUDA Toolkitのインストール

1. 以下のコマンドを実行してNVIDIAドライバとCUDAをインストール：
   ```bash
   sudo apt update
   sudo apt install nvidia-driver-515 nvidia-cuda-toolkit
   ```
2. システムを再起動：
   ```bash
   sudo reboot
   ```
3. インストールを確認：
   ```bash
   nvidia-smi
   nvcc --version
   ```

#### cuDNNのインストール

1. [NVIDIA Developer](https://developer.nvidia.com/cudnn)からアカウント登録後、cuDNNをダウンロード（CUDAバージョンに対応したものを選択）
2. 以下のコマンドでインストール：
   ```bash
   sudo dpkg -i libcudnn8_x.x.x-1+cudaX.Y_amd64.deb
   sudo dpkg -i libcudnn8-dev_x.x.x-1+cudaX.Y_amd64.deb
   ```

#### TensorFlowのインストール

1. 以下のコマンドを実行：
   ```bash
   pip3 install tensorflow==2.10.0
   ```
2. インストールを確認：
   ```bash
   python3 -c "import tensorflow as tf; print(tf.__version__); print('GPU Available: ', tf.config.list_physical_devices('GPU'))"
   ```

### macOS

**注意**: macOSではGPUサポートが限定的です。特にM1/M2チップの場合は特別な設定が必要です。

#### TensorFlowのインストール

1. ターミナルを開き、以下のコマンドを実行：
   ```bash
   pip3 install tensorflow-macos
   pip3 install tensorflow-metal  # M1/M2チップの場合
   ```
2. インストールを確認：
   ```bash
   python3 -c "import tensorflow as tf; print(tf.__version__)"
   ```

## MUGEN Systemのインストール

### 1. ソースコードの取得

以下のいずれかの方法でMUGEN Systemのソースコードを取得します：

#### 方法1: ZIPファイルからのインストール

1. 提供されたZIPファイル（`MUGEN_System_DAIMON_MAXIMUM.zip`）をダウンロード
2. 任意の場所に解凍（例: `C:\MUGEN_System`や`/home/username/MUGEN_System`）

#### 方法2: Gitを使用したインストール

1. Gitがインストールされていない場合は、インストール：
   - Windows: [Git for Windows](https://gitforwindows.org/)からダウンロードしてインストール
   - Ubuntu: `sudo apt install git`
   - macOS: `brew install git`（Homebrewが必要）
2. 以下のコマンドを実行してリポジトリをクローン：
   ```bash
   git clone https://github.com/your-repository/MUGEN_System_DAIMON_MAXIMUM.git
   cd MUGEN_System_DAIMON_MAXIMUM
   ```

### 2. 仮想環境の作成

プロジェクト用の仮想環境を作成することを強く推奨します。

#### Windows

```
cd C:\path\to\MUGEN_System
python -m venv venv
venv\Scripts\activate
```

#### Ubuntu/macOS

```bash
cd /path/to/MUGEN_System
python3 -m venv venv
source venv/bin/activate
```

### 3. 依存パッケージのインストール

仮想環境を有効化した状態で、以下のコマンドを実行：

```bash
pip install -r requirements.txt
```

**注意**: インストールには数分かかる場合があります。

## 初期設定

### 1. 設定ファイルの準備

1. `src/config`ディレクトリ内の各設定ファイルを確認
2. 必要に応じて設定を変更（特に認証情報やAPIキーなど）

### 2. AI学習モジュールの初期化

以下のコマンドを実行してAI学習モジュールを初期化：

```bash
cd /path/to/MUGEN_System
python src/ai_learning/init.py
```

### 3. システム全体の初期化

以下のコマンドを実行してシステム全体を初期化：

```bash
python src/core/init.py
```

### 4. AI学習モジュールとコアシステムの統合

以下のコマンドを実行してAI学習モジュールをコアシステムと統合：

```bash
python src/ai_learning/integration.py
```

## 動作確認

### 1. システム起動テスト

以下のコマンドを実行してシステムが正常に起動するか確認：

```bash
python src/core/mugen_system.py --test
```

正常に起動すると、「MUGEN System起動テスト成功」というメッセージが表示されます。

### 2. AI学習モジュールテスト

以下のコマンドを実行してAI学習モジュールが正常に動作するか確認：

```bash
python src/ai_learning/main.py --mode test
```

正常に動作すると、「AI学習モジュールテスト成功」というメッセージが表示されます。

## トラブルシューティング

### 一般的な問題

#### インストール中にエラーが発生する場合

1. インターネット接続を確認
2. 管理者権限で実行しているか確認
3. ファイアウォールやウイルス対策ソフトが干渉していないか確認
4. Pythonのバージョンが3.8〜3.11であることを確認

#### TensorFlowがGPUを認識しない場合

1. 最新のNVIDIAドライバがインストールされているか確認
2. CUDA ToolkitとcuDNNのバージョンがTensorFlowと互換性があるか確認
3. 環境変数が正しく設定されているか確認
4. システムを再起動

#### 「ModuleNotFoundError」エラーが表示される場合

1. 仮想環境が有効化されているか確認
2. `pip install -r requirements.txt`を再実行
3. 特定のモジュールがない場合は個別にインストール：`pip install モジュール名`

### エラーコードと対処法

| エラーコード | 説明 | 対処法 |
|------------|------|------|
| E001 | Pythonバージョンエラー | 互換性のあるPythonバージョン（3.8〜3.11）をインストール |
| E002 | CUDA初期化エラー | NVIDIAドライバとCUDAを再インストール |
| E003 | 依存パッケージエラー | `pip install -r requirements.txt`を再実行 |
| E004 | 設定ファイルエラー | 設定ファイルの形式と内容を確認 |
| E005 | 権限エラー | 管理者権限で実行 |

## アップデート方法

### ZIPファイルからインストールした場合

1. 新しいバージョンのZIPファイルをダウンロード
2. 既存のインストールをバックアップ
3. 新しいファイルで上書き
4. 依存パッケージを更新：`pip install -r requirements.txt --upgrade`
5. 初期化スクリプトを再実行：`python src/core/init.py`

### Gitを使用してインストールした場合

1. 以下のコマンドを実行して最新バージョンを取得：
   ```bash
   cd /path/to/MUGEN_System
   git pull
   ```
2. 依存パッケージを更新：`pip install -r requirements.txt --upgrade`
3. 初期化スクリプトを再実行：`python src/core/init.py`

---

インストールに関するご質問や問題がある場合は、サポートまでお問い合わせください。
