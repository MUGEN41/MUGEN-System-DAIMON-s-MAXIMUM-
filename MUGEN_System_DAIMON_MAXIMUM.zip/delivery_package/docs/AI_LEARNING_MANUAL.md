# MUGEN System（DAIMON's MAXIMUM）AI学習手順書

## 目次

1. [はじめに](#はじめに)
2. [前提条件](#前提条件)
3. [データ収集](#データ収集)
4. [データ前処理](#データ前処理)
5. [モデル構築](#モデル構築)
6. [モデル学習](#モデル学習)
7. [ハイパーパラメータ最適化](#ハイパーパラメータ最適化)
8. [モデル評価](#モデル評価)
9. [予測の実行](#予測の実行)
10. [自動学習スケジュールの設定](#自動学習スケジュールの設定)
11. [トラブルシューティング](#トラブルシューティング)
12. [高度なカスタマイズ](#高度なカスタマイズ)
13. [付録](#付録)

## はじめに

この手順書は、MUGEN System（DAIMON's MAXIMUM）のAI学習機能を活用するためのガイドです。チャートデータの収集から前処理、モデル学習、評価、最適化までの一連のプロセスを詳細に解説します。

### AI学習モジュールの概要

MUGEN SystemのAI学習モジュールは、以下の特徴を持っています：

- **複数通貨ペア対応**: 9種類の通貨ペア（USDJPY, EURJPY, GBPJPY, AUDJPY, NZDJPY, EURUSD, GBPUSD, AUDUSD, NZDUSD）
- **マルチタイムフレーム対応**: 7種類の時間枠（1分足、3分足、5分足、15分足、1時間足、4時間足、1日足）
- **長期データ分析**: 2021年5月1日から2024年4月30日までの3年間のデータを活用
- **ディープラーニングモデル**: TensorflowとCUDAを活用したLSTMベースのモデル
- **自動最適化**: ハイパーパラメータの自動調整機能
- **高い予測精度**: 勝率80%以上を目指した学習プロセス
- **ファンダメンタルズ統合**: 経済指標データとの統合分析

## 前提条件

AI学習を開始する前に、以下の条件が満たされていることを確認してください：

1. **MUGEN Systemのインストール**: [インストール手順書](INSTALLATION_MANUAL.md)に従ってシステムがインストールされていること
2. **TensorFlowとCUDAの設定**: GPUを活用するための環境が整っていること
3. **十分なストレージ容量**: データセット保存用に最低50GB以上の空き容量があること
4. **メモリ容量**: 学習処理用に16GB以上のRAMがあること（32GB以上推奨）
5. **安定したインターネット接続**: データダウンロード用に高速で安定した接続があること

### 環境確認

以下のコマンドを実行して、AI学習環境が正しく設定されているか確認してください：

```bash
cd /path/to/MUGEN_System
source venv/bin/activate  # Windows: venv\Scripts\activate
python src/ai_learning/init.py
```

正常に設定されていれば、以下のような出力が表示されます：

```
INFO - MUGEN System AI学習モジュールの初期化を開始します
INFO - ディレクトリを作成しました: data
INFO - ディレクトリを作成しました: models
INFO - ディレクトリを作成しました: logs
INFO - TensorFlow バージョン: 2.10.0
INFO - 利用可能なGPU: 1個
INFO -   - PhysicalDevice(name='/physical_device:GPU:0', device_type='GPU')
INFO - CUDA バージョン: 11.2
INFO - MUGEN System AI学習モジュールの初期化が完了しました
```

## データ収集

AI学習の第一歩は、高品質なチャートデータの収集です。MUGEN Systemは、複数の方法でデータを収集できます。

### 自動データ収集

最も簡単な方法は、自動データ収集機能を使用することです：

```bash
python src/ai_learning/main.py --mode download
```

このコマンドは、設定ファイル（`src/ai_learning/config/ai_learning_config.json`）に基づいて、すべての通貨ペアと時間枠のデータを自動的にダウンロードします。

特定の通貨ペアと時間枠のみをダウンロードする場合：

```bash
python src/ai_learning/main.py --mode download --currency_pair USDJPY --timeframe 5m
```

### データソースの設定

デフォルトでは、MUGEN Systemは無料のAPIからデータを収集します。より高品質なデータソースを使用するには、設定ファイルを編集します：

1. `src/ai_learning/config/data_sources_config.json`を開く
2. 使用するデータソースのAPIキーと設定を入力

```json
{
  "default_source": "free_api",
  "sources": {
    "free_api": {
      "url": "https://api.example.com/forex",
      "requires_key": false
    },
    "premium_api": {
      "url": "https://premium-api.example.com/forex",
      "requires_key": true,
      "api_key": "YOUR_API_KEY_HERE"
    }
  }
}
```

### データ収集の進捗確認

データ収集の進捗は、ログファイル（`ai_learning_download.log`）で確認できます：

```bash
tail -f ai_learning_download.log
```

また、以下のコマンドでデータ収集の状態を確認できます：

```bash
python src/ai_learning/main.py --check-data
```

### 手動データ収集（高度）

特殊なデータソースからデータを収集する場合は、手動でCSVファイルを準備し、`data`ディレクトリに配置することもできます。CSVファイルは以下の形式である必要があります：

```
timestamp,open,high,low,close,volume
2021-05-01 00:00:00,109.235,109.240,109.230,109.238,123
2021-05-01 00:01:00,109.238,109.245,109.235,109.242,145
...
```

ファイル名は`CURRENCY_TIMEFRAME_YYYYMMDD-YYYYMMDD.csv`の形式にしてください（例：`USDJPY_5m_20210501-20240430.csv`）。

## データ前処理

収集したデータは、モデル学習に適した形式に前処理する必要があります。

### 自動前処理

MUGEN Systemは、学習プロセスの一部として自動的にデータ前処理を行います。以下のコマンドで前処理のみを実行できます：

```bash
python src/ai_learning/main.py --mode preprocess
```

特定の通貨ペアと時間枠のみを前処理する場合：

```bash
python src/ai_learning/main.py --mode preprocess --currency_pair USDJPY --timeframe 5m
```

### 前処理の設定

前処理の設定は、`src/ai_learning/config/preprocessing_config.json`で調整できます：

```json
{
  "sequence_length": 60,
  "prediction_horizon": 1,
  "features": ["open", "high", "low", "close", "volume"],
  "derived_features": {
    "enable": true,
    "rsi": true,
    "macd": true,
    "bollinger_bands": true,
    "moving_averages": [5, 10, 20, 50]
  },
  "normalization": "min_max",
  "fill_missing": "interpolate",
  "remove_outliers": true,
  "outlier_threshold": 3.0,
  "train_test_split": {
    "test_size": 0.2,
    "validation_size": 0.1,
    "random_seed": 42,
    "chronological": true
  }
}
```

主な設定項目：

- **sequence_length**: 入力シーケンスの長さ（過去何本のローソク足を見るか）
- **prediction_horizon**: 予測する未来の時間（何本先を予測するか）
- **features**: 使用する基本特徴量
- **derived_features**: 派生特徴量（テクニカル指標）の設定
- **normalization**: 正規化方法（min_max, z_score, robust）
- **train_test_split**: 訓練/検証/テストデータの分割方法

### ファンダメンタルズデータの統合

経済指標などのファンダメンタルズデータを統合するには、以下の手順に従います：

1. `src/ai_learning/config/fundamentals_config.json`を編集
2. 使用する経済指標と取得方法を設定
3. 以下のコマンドを実行してファンダメンタルズデータを取得：
   ```bash
   python src/ai_learning/main.py --mode download-fundamentals
   ```
4. 以下のコマンドでファンダメンタルズデータを前処理済みデータと統合：
   ```bash
   python src/ai_learning/main.py --mode integrate-fundamentals
   ```

## モデル構築

MUGEN Systemは、LSTMベースのディープラーニングモデルを使用して価格予測を行います。

### デフォルトモデルアーキテクチャ

デフォルトのモデルアーキテクチャは以下の通りです：

1. 入力層（シーケンス長×特徴数）
2. LSTM層（128ユニット、ドロップアウト0.2）
3. LSTM層（64ユニット、ドロップアウト0.2）
4. バッチ正規化層
5. 全結合層（32ユニット、ReLU活性化）
6. ドロップアウト層（0.2）
7. 全結合層（16ユニット、ReLU活性化）
8. 出力層（1ユニット、シグモイド活性化）

### モデルアーキテクチャのカスタマイズ

モデルアーキテクチャは、`src/ai_learning/config/model_config.json`で調整できます：

```json
{
  "model_type": "lstm",
  "lstm_units": [128, 64],
  "dense_units": [32, 16],
  "dropout_rate": 0.2,
  "use_batch_norm": true,
  "activation": "relu",
  "output_activation": "sigmoid",
  "advanced": {
    "use_attention": false,
    "bidirectional": false,
    "use_residual": false,
    "use_cnn_layers": false
  }
}
```

### カスタムモデルの作成（高度）

より高度なカスタマイズが必要な場合は、`src/ai_learning/models/custom_model.py`を作成し、独自のモデルを定義できます：

```python
import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, Dense, Dropout

def create_custom_model(input_shape, output_shape):
    """カスタムモデルの作成"""
    inputs = Input(shape=input_shape)
    
    # カスタムアーキテクチャを定義
    x = LSTM(256, return_sequences=True)(inputs)
    x = Dropout(0.3)(x)
    x = LSTM(128)(x)
    x = Dense(64, activation='relu')(x)
    x = Dropout(0.2)(x)
    outputs = Dense(output_shape, activation='sigmoid')(x)
    
    model = Model(inputs=inputs, outputs=outputs)
    return model
```

カスタムモデルを使用するには、`src/ai_learning/config/model_config.json`の`model_type`を`custom`に設定します。

## モデル学習

データ収集と前処理が完了したら、モデルの学習を開始できます。

### 基本的な学習実行

すべての通貨ペアと時間枠のモデルを学習するには：

```bash
python src/ai_learning/main.py --mode train
```

特定の通貨ペアと時間枠のみを学習する場合：

```bash
python src/ai_learning/main.py --mode train --currency_pair USDJPY --timeframe 5m
```

### 学習パラメータの設定

学習パラメータは、`src/ai_learning/config/training_config.json`で調整できます：

```json
{
  "batch_size": 64,
  "epochs": 100,
  "learning_rate": 0.001,
  "optimizer": "adam",
  "loss": "binary_crossentropy",
  "metrics": ["accuracy", "precision", "recall", "f1_score"],
  "early_stopping": {
    "enable": true,
    "monitor": "val_loss",
    "patience": 10,
    "restore_best_weights": true
  },
  "learning_rate_scheduler": {
    "enable": true,
    "type": "reduce_on_plateau",
    "patience": 5,
    "factor": 0.5,
    "min_lr": 0.00001
  },
  "class_weights": {
    "enable": false,
    "weight_0": 1.0,
    "weight_1": 1.0
  }
}
```

主な設定項目：

- **batch_size**: バッチサイズ（メモリ使用量に影響）
- **epochs**: 最大エポック数
- **learning_rate**: 学習率
- **optimizer**: 最適化アルゴリズム（adam, sgd, rmsprop）
- **early_stopping**: 早期停止の設定
- **learning_rate_scheduler**: 学習率スケジューラの設定

### 学習の進捗確認

学習の進捗は、リアルタイムで表示されます。また、TensorBoardを使用して詳細な学習状況を可視化できます：

```bash
# TensorBoardの起動
tensorboard --logdir=logs/tensorboard
```

ブラウザで`http://localhost:6006`にアクセスすると、学習の進捗グラフが表示されます。

### 学習の再開

学習が中断された場合、以下のコマンドで再開できます：

```bash
python src/ai_learning/main.py --mode train --resume
```

## ハイパーパラメータ最適化

モデルの性能を向上させるには、ハイパーパラメータの最適化が重要です。

### 自動ハイパーパラメータ最適化

MUGEN Systemは、Kerasチューナーを使用して自動的にハイパーパラメータを最適化できます：

```bash
python src/ai_learning/main.py --mode optimize --currency_pair USDJPY --timeframe 5m
```

### 最適化設定

最適化の設定は、`src/ai_learning/config/optimization_config.json`で調整できます：

```json
{
  "tuner": "bayesian",
  "max_trials": 30,
  "executions_per_trial": 2,
  "objective": "val_accuracy",
  "direction": "max",
  "parameters": {
    "lstm_units": {
      "min": 32,
      "max": 256,
      "step": 32
    },
    "dense_units": {
      "min": 16,
      "max": 128,
      "step": 16
    },
    "dropout_rate": {
      "min": 0.1,
      "max": 0.5,
      "step": 0.1
    },
    "learning_rate": {
      "min": 0.0001,
      "max": 0.01,
      "sampling": "log"
    },
    "batch_size": [32, 64, 128]
  }
}
```

主な設定項目：

- **tuner**: チューニング方法（bayesian, random, hyperband）
- **max_trials**: 試行回数
- **objective**: 最適化する指標
- **parameters**: 最適化するパラメータとその範囲

### 最適化結果の適用

最適化が完了すると、最適なパラメータが`logs/optimization`ディレクトリに保存されます。以下のコマンドで最適なパラメータを適用してモデルを再学習できます：

```bash
python src/ai_learning/main.py --mode train --use-optimized --currency_pair USDJPY --timeframe 5m
```

## モデル評価

学習したモデルの性能を評価するには、以下のコマンドを実行します：

```bash
python src/ai_learning/main.py --mode evaluate --currency_pair USDJPY --timeframe 5m
```

### 評価指標

モデルは以下の指標で評価されます：

- **正解率（Accuracy）**: 正しく予測された割合
- **精度（Precision）**: 上昇と予測したケースのうち、実際に上昇した割合
- **再現率（Recall）**: 実際に上昇したケースのうち、上昇と予測できた割合
- **F1スコア**: 精度と再現率の調和平均
- **混同行列（Confusion Matrix）**: 予測と実際の結果の分布
- **ROC曲線**: 受信者操作特性曲線
- **損益曲線**: 予測に基づいた仮想取引の損益推移

### バックテスト

モデルの実用性を評価するには、バックテストを実行します：

```bash
python src/ai_learning/main.py --mode backtest --currency_pair USDJPY --timeframe 5m
```

バックテストでは、以下の設定が使用されます：

- 初期資金: 100,000円
- エントリー金額: 口座残高の1%
- 勝率目標: 80%以上

### 評価レポートの生成

詳細な評価レポートを生成するには：

```bash
python src/ai_learning/main.py --mode report --currency_pair USDJPY --timeframe 5m
```

レポートは`reports`ディレクトリに保存され、以下の情報が含まれます：

- モデルの概要と構造
- 学習曲線（損失と精度）
- 評価指標の詳細
- バックテスト結果
- 特徴量の重要度分析
- 予測の可視化

## 予測の実行

学習したモデルを使用して予測を行うには、以下のコマンドを実行します：

```bash
python src/ai_learning/main.py --mode predict --currency_pair USDJPY --timeframe 5m
```

### リアルタイム予測

リアルタイムデータを使用して予測を行うには：

```bash
python src/ai_learning/main.py --mode predict-live --currency_pair USDJPY --timeframe 5m
```

### 予測結果の解釈

予測結果は以下の形式で表示されます：

```
予測結果: 上昇 (確信度: 0.8765)
```

確信度が0.5より大きい場合は上昇、小さい場合は下降と予測されます。確信度が高いほど、予測の信頼性が高いことを示します。

### 予測の可視化

予測結果を可視化するには：

```bash
python src/ai_learning/main.py --mode visualize-prediction --currency_pair USDJPY --timeframe 5m
```

これにより、過去の価格チャートと予測結果を組み合わせたグラフが生成されます。

## 自動学習スケジュールの設定

MUGEN Systemは、定期的な再学習を自動化するスケジューリング機能を提供します。

### スケジュール設定

学習スケジュールは、`src/ai_learning/config/ai_learning_integration_config.json`で設定できます：

```json
{
  "enable_auto_learning": true,
  "learning_schedule": {
    "frequency": "weekly",
    "day_of_week": 6,
    "hour": 2,
    "minute": 0
  }
}
```

主な設定項目：

- **enable_auto_learning**: 自動学習の有効/無効
- **frequency**: 頻度（daily, weekly, monthly）
- **day_of_week**: 曜日（0=月曜日, 6=日曜日）
- **hour**: 時（0-23）
- **minute**: 分（0-59）

### スケジュールの適用

スケジュール設定を適用するには、以下のコマンドを実行します：

```bash
python src/ai_learning/integration.py
```

### スケジュール状態の確認

現在のスケジュール状態を確認するには：

```bash
python src/core/mugen_system.py --check-schedules
```

## トラブルシューティング

### 一般的な問題と解決策

#### メモリエラー

**症状**: `MemoryError`や`OOM`（Out of Memory）エラーが発生する

**解決策**:
1. バッチサイズを小さくする: `src/ai_learning/config/training_config.json`の`batch_size`を減らす
2. シーケンス長を短くする: `src/ai_learning/config/preprocessing_config.json`の`sequence_length`を減らす
3. 使用する特徴量を減らす: `derived_features`の一部を無効化する
4. GPUメモリ設定を調整: TensorFlowのメモリ成長を有効にする

```python
# src/ai_learning/init.pyに以下のコードがあることを確認
import tensorflow as tf
gpus = tf.config.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)
```

#### 学習が収束しない

**症状**: 損失が減少せず、精度が向上しない

**解決策**:
1. 学習率を調整: `src/ai_learning/config/training_config.json`の`learning_rate`を小さくする
2. モデル複雑度を調整: より単純なモデルアーキテクチャを試す
3. データの質を確認: 異常値や欠損値の処理を見直す
4. 特徴量の正規化を確認: 適切な正規化方法を選択する
5. クラス不均衡を確認: `class_weights`を有効にする

#### データダウンロードエラー

**症状**: データのダウンロードが失敗する

**解決策**:
1. インターネット接続を確認
2. APIキーと認証情報を確認
3. データソースの制限を確認（リクエスト制限など）
4. プロキシ設定を確認
5. 手動でデータをダウンロードし、`data`ディレクトリに配置

### エラーコードと対処法

| エラーコード | 説明 | 対処法 |
|------------|------|------|
| E101 | データダウンロードエラー | インターネット接続とAPIキーを確認 |
| E102 | データ形式エラー | CSVファイルの形式を確認 |
| E103 | 前処理エラー | 前処理設定を見直し、異常値の処理を確認 |
| E201 | モデル構築エラー | モデル設定を確認、より単純なアーキテクチャを試す |
| E202 | 学習エラー | バッチサイズと学習率を調整 |
| E203 | GPU初期化エラー | CUDAとTensorFlowの互換性を確認 |
| E301 | 最適化エラー | 最適化範囲を狭める、試行回数を減らす |
| E401 | 予測エラー | モデルファイルの存在を確認、再学習を実行 |

## 高度なカスタマイズ

### カスタム特徴量の追加

独自の特徴量を追加するには、`src/ai_learning/features/custom_features.py`を作成します：

```python
import pandas as pd
import numpy as np
import talib

def add_custom_features(df):
    """カスタム特徴量を追加する関数"""
    # 例: Ichimoku Cloud
    df['tenkan_sen'] = talib.SMA(df['close'], timeperiod=9)
    df['kijun_sen'] = talib.SMA(df['close'], timeperiod=26)
    df['senkou_span_a'] = (df['tenkan_sen'] + df['kijun_sen']) / 2
    df['senkou_span_b'] = talib.SMA(df['close'], timeperiod=52)
    
    # 例: Stochastic RSI
    df['stoch_rsi'] = talib.STOCHRSI(df['close'], timeperiod=14)[0]
    
    return df
```

カスタム特徴量を有効にするには、`src/ai_learning/config/preprocessing_config.json`を編集します：

```json
{
  "custom_features": {
    "enable": true,
    "module": "features.custom_features",
    "function": "add_custom_features"
  }
}
```

### カスタム損失関数

トレード固有の損失関数を定義するには、`src/ai_learning/losses/custom_losses.py`を作成します：

```python
import tensorflow as tf
import keras.backend as K

def profit_loss(y_true, y_pred):
    """利益を最大化する損失関数"""
    # 上昇予測時（y_pred > 0.5）に実際に上昇した場合（y_true = 1）は利益
    # 上昇予測時に実際に下降した場合（y_true = 0）は損失
    profit = K.switch(K.greater(y_pred, 0.5),
                      K.switch(K.equal(y_true, 1.0), 1.0, -1.0),
                      K.switch(K.equal(y_true, 0.0), 1.0, -1.0))
    
    # 確信度が高いほど重みを大きくする
    confidence = K.abs(y_pred - 0.5) * 2  # 0.5→0, 0または1→1
    weighted_profit = profit * confidence
    
    # 損失は利益の負値
    return -K.mean(weighted_profit)
```

カスタム損失関数を使用するには、`src/ai_learning/config/training_config.json`を編集します：

```json
{
  "loss": {
    "type": "custom",
    "module": "losses.custom_losses",
    "function": "profit_loss"
  }
}
```

### マルチモデルアンサンブル

複数のモデルを組み合わせて予測精度を向上させるには、`src/ai_learning/config/ensemble_config.json`を作成します：

```json
{
  "enable": true,
  "models": ["lstm", "gru", "cnn_lstm"],
  "voting_method": "weighted",
  "weights": [0.5, 0.3, 0.2]
}
```

アンサンブルモデルを学習するには：

```bash
python src/ai_learning/main.py --mode train-ensemble --currency_pair USDJPY --timeframe 5m
```

## 付録

### コマンドリファレンス

```bash
# 初期化
python src/ai_learning/init.py

# データダウンロード
python src/ai_learning/main.py --mode download
python src/ai_learning/main.py --mode download --currency_pair USDJPY --timeframe 5m

# データ前処理
python src/ai_learning/main.py --mode preprocess
python src/ai_learning/main.py --mode preprocess --currency_pair USDJPY --timeframe 5m

# モデル学習
python src/ai_learning/main.py --mode train
python src/ai_learning/main.py --mode train --currency_pair USDJPY --timeframe 5m
python src/ai_learning/main.py --mode train --resume

# ハイパーパラメータ最適化
python src/ai_learning/main.py --mode optimize --currency_pair USDJPY --timeframe 5m

# モデル評価
python src/ai_learning/main.py --mode evaluate --currency_pair USDJPY --timeframe 5m
python src/ai_learning/main.py --mode backtest --currency_pair USDJPY --timeframe 5m
python src/ai_learning/main.py --mode report --currency_pair USDJPY --timeframe 5m

# 予測実行
python src/ai_learning/main.py --mode predict --currency_pair USDJPY --timeframe 5m
python src/ai_learning/main.py --mode predict-live --currency_pair USDJPY --timeframe 5m
python src/ai_learning/main.py --mode visualize-prediction --currency_pair USDJPY --timeframe 5m

# 統合と自動化
python src/ai_learning/integration.py
python src/core/mugen_system.py --check-schedules

# 完全パイプライン実行
python src/ai_learning/main.py --mode full
```

### 設定ファイル一覧

| ファイルパス | 説明 |
|------------|------|
| src/ai_learning/config/ai_learning_config.json | AI学習の基本設定 |
| src/ai_learning/config/data_sources_config.json | データソースの設定 |
| src/ai_learning/config/preprocessing_config.json | データ前処理の設定 |
| src/ai_learning/config/model_config.json | モデルアーキテクチャの設定 |
| src/ai_learning/config/training_config.json | 学習パラメータの設定 |
| src/ai_learning/config/optimization_config.json | ハイパーパラメータ最適化の設定 |
| src/ai_learning/config/fundamentals_config.json | ファンダメンタルズデータの設定 |
| src/ai_learning/config/ai_learning_integration_config.json | 統合と自動化の設定 |
| src/ai_learning/config/ensemble_config.json | アンサンブルモデルの設定 |

### ディレクトリ構造

```
MUGEN_System/
├── data/                  # データ保存ディレクトリ
│   ├── raw/               # 生データ
│   ├── processed/         # 前処理済みデータ
│   └── fundamentals/      # ファンダメンタルズデータ
├── models/                # 学習済みモデル
│   ├── USDJPY/            # 通貨ペアごとのモデル
│   ├── EURJPY/
│   └── ...
├── logs/                  # ログファイル
│   ├── training/          # 学習ログ
│   ├── optimization/      # 最適化ログ
│   └── tensorboard/       # TensorBoardログ
├── reports/               # 評価レポート
├── src/                   # ソースコード
│   ├── ai_learning/       # AI学習モジュール
│   │   ├── config/        # 設定ファイル
│   │   ├── features/      # 特徴量エンジニアリング
│   │   ├── models/        # モデル定義
│   │   ├── losses/        # 損失関数
│   │   ├── utils/         # ユーティリティ関数
│   │   ├── ai_learning_system.py # メインシステム
│   │   ├── main.py        # コマンドインターフェース
│   │   ├── init.py        # 初期化スクリプト
│   │   └── integration.py # 統合スクリプト
│   └── ...
└── ...
```

---

この手順書に関するご質問や問題がある場合は、サポートまでお問い合わせください。
