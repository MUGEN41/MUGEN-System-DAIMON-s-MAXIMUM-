# MUGEN System（DAIMON's MAXIMUM）取扱説明書

## 目次

1. [システム概要](#システム概要)
2. [システム構成](#システム構成)
3. [基本操作](#基本操作)
4. [各モジュールの使用方法](#各モジュールの使用方法)
5. [設定パラメータの調整](#設定パラメータの調整)
6. [日常運用手順](#日常運用手順)
7. [監視とアラート](#監視とアラート)
8. [トラブルシューティング](#トラブルシューティング)
9. [よくある質問](#よくある質問)
10. [付録](#付録)

## システム概要

MUGEN System（DAIMON's MAXIMUM）は、高度なAI技術を活用した自動取引システムです。複数の通貨ペアと時間枠に対応し、人間の行動パターンをシミュレートすることで検知回避機能を備えています。システムは以下の主要な特徴を持っています：

- **複数プラットフォーム対応**: The Option、Bi-Winning、Bubingaの3つのプラットフォームに対応
- **マルチタイムフレーム分析**: 1分足、3分足、5分足、15分足の全時間枠でのエントリー
- **AI学習機能**: TensorflowとCUDAを活用した高度なディープラーニングモデル
- **人間行動シミュレーション**: 自然な操作パターンと時間間隔を再現
- **検知回避機能**: 勝率自動調整と不自然なパターン回避
- **自動回復機能**: エラー発生時の自動復旧と処理再開
- **通知システム**: LINE通知による重要イベントの報告

## システム構成

MUGEN Systemは以下のモジュールから構成されています：

### コアモジュール

- **mugen_system.py**: システム全体の制御と統合
- **logic_selector.py**: 最適なトレードロジックの選択
- **recovery_system.py**: エラー検出と自動回復
- **fundamentals_monitor.py**: 経済指標と市場環境の監視

### 機能モジュール

- **human_behavior_simulator.py**: 人間らしい操作パターンの生成
- **detection_avoidance_system.py**: 検知回避アルゴリズム
- **browser_automation.py**: ブラウザ自動操作
- **daily_trade_manager.py**: 日次取引管理

### AI学習モジュール

- **ai_learning_system.py**: AI学習の中核機能
- **main.py**: 学習コマンドインターフェース
- **init.py**: 学習環境の初期化
- **integration.py**: コアシステムとの統合

## 基本操作

### システムの起動

MUGEN Systemを起動するには、以下のコマンドを実行します：

```bash
cd /path/to/MUGEN_System
source venv/bin/activate  # 仮想環境を有効化
python src/core/mugen_system.py
```

### システムの停止

実行中のシステムを安全に停止するには、以下のいずれかの方法を使用します：

1. コンソールで `Ctrl+C` を押す
2. 別のターミナルから以下のコマンドを実行：
   ```bash
   python src/core/mugen_system.py --stop
   ```

### システムの状態確認

システムの現在の状態を確認するには、以下のコマンドを実行します：

```bash
python src/core/mugen_system.py --status
```

## 各モジュールの使用方法

### 人間行動シミュレーター

人間行動シミュレーターは、自然な操作パターンと時間間隔を生成し、ブラウザ自動操作に人間らしさを与えます。

#### 基本設定

`src/human_behavior/config/behavior_config.json`で以下の設定が可能です：

```json
{
  "behavior_profile": "normal",  // normal, cautious, aggressive
  "click_delay_range": [0.5, 2.0],  // クリック間の遅延範囲（秒）
  "typing_speed_range": [0.05, 0.2],  // 1文字あたりのタイピング速度範囲（秒）
  "mouse_movement_speed": "medium",  // slow, medium, fast
  "error_probability": 0.05,  // エラー（誤クリックなど）の発生確率
  "correction_behavior": true,  // エラー後の修正行動を有効化
  "idle_periods_enabled": true,  // アイドル期間（休憩）を有効化
  "idle_period_frequency": 0.1,  // アイドル期間の発生頻度
  "idle_period_duration_range": [30, 300]  // アイドル期間の長さ範囲（秒）
}
```

#### 行動プロファイルの切り替え

取引スタイルに応じて行動プロファイルを切り替えるには、以下のコマンドを使用します：

```bash
python src/human_behavior/human_behavior_simulator.py --set-profile cautious
```

利用可能なプロファイル：
- **normal**: 標準的な行動パターン
- **cautious**: 慎重な行動パターン（遅い操作、確認が多い）
- **aggressive**: 積極的な行動パターン（素早い操作、確認が少ない）

### 検知回避システム

検知回避システムは、取引パターンを分析し、検知されるリスクを最小化します。

#### 基本設定

`src/detection_avoidance/config/detection_avoidance_config.json`で以下の設定が可能です：

```json
{
  "target_win_rate": 0.8,  // 目標勝率（0.0〜1.0）
  "win_rate_adjustment_enabled": true,  // 勝率自動調整を有効化
  "consecutive_wins_limit": 10,  // 連勝制限
  "consecutive_losses_limit": 5,  // 連敗制限（これを超えると自動停止）
  "pattern_detection_enabled": true,  // パターン検出を有効化
  "randomization_level": "medium",  // low, medium, high
  "time_variation_enabled": true,  // 時間変動を有効化
  "amount_variation_enabled": true  // 金額変動を有効化
}
```

#### 勝率調整の手動設定

目標勝率を手動で調整するには、以下のコマンドを使用します：

```bash
python src/detection_avoidance/detection_avoidance_system.py --set-win-rate 0.75
```

### ブラウザ自動化

ブラウザ自動化モジュールは、各プラットフォームでの操作を自動化します。

#### プラットフォーム設定

`src/browser_automation/config/browser_automation_config.json`で以下の設定が可能です：

```json
{
  "browser_type": "chrome",  // chrome, firefox
  "headless": false,  // ヘッドレスモード（画面表示なし）
  "default_timeout": 30,  // 要素待機のデフォルトタイムアウト（秒）
  "retry_attempts": 3,  // 操作失敗時の再試行回数
  "screenshot_on_error": true,  // エラー時にスクリーンショットを保存
  "user_agent": "custom",  // default, mobile, custom
  "custom_user_agent": "Mozilla/5.0 ...",  // カスタムユーザーエージェント
  "proxy_enabled": false,  // プロキシの使用
  "proxy_settings": {
    "server": "",
    "username": "",
    "password": ""
  }
}
```

#### プラットフォーム固有の設定

各プラットフォーム固有の設定は以下のファイルで行います：

- The Option: `src/browser_automation/config/the_option_config.json`
- Bi-Winning: `src/browser_automation/config/bi_winning_config.json`
- Bubinga: `src/browser_automation/config/bubinga_config.json`

### 日次取引管理

日次取引管理モジュールは、取引回数や利益の上限を管理します。

#### 基本設定

`src/trade_management/config/trade_rules_config.json`で以下の設定が可能です：

```json
{
  "daily_trade_limit": 100,  // 1日の最大取引回数
  "daily_profit_limit": 600000,  // 1日の最大利益（円）
  "entry_amount_percentage": 1.0,  // 口座残高に対するエントリー金額の割合（%）
  "compound_interest_enabled": true,  // 複利計算を有効化
  "session_start_time": "00:00",  // 取引セッション開始時間
  "session_end_time": "23:59",  // 取引セッション終了時間
  "auto_logout_enabled": true,  // 自動ログアウトを有効化
  "auto_login_enabled": true  // 自動ログインを有効化
}
```

### AI学習モジュール

AI学習モジュールは、市場データを分析し、最適なエントリーポイントを予測します。

#### 学習の実行

新しいデータでモデルを学習するには、以下のコマンドを実行します：

```bash
python src/ai_learning/main.py --mode train
```

特定の通貨ペアと時間枠のみを学習する場合：

```bash
python src/ai_learning/main.py --mode train --currency_pair USDJPY --timeframe 5m
```

#### 予測の実行

学習済みモデルを使用して予測を行うには、以下のコマンドを実行します：

```bash
python src/ai_learning/main.py --mode predict --currency_pair USDJPY --timeframe 5m
```

## 設定パラメータの調整

### システム全体の設定

`src/core/config/system_config.json`で以下の設定が可能です：

```json
{
  "system_name": "MUGEN System (DAIMON's MAXIMUM)",
  "version": "1.0.0",
  "log_level": "info",  // debug, info, warning, error
  "log_file": "logs/mugen_system.log",
  "data_directory": "data",
  "active_platforms": ["the_option", "bi_winning", "bubinga"],
  "default_platform": "the_option",
  "active_currency_pairs": ["USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "EURUSD", "GBPUSD", "AUDUSD", "NZDUSD"],
  "active_timeframes": ["1m", "3m", "5m", "15m"],
  "notification": {
    "line_enabled": true,
    "line_token": "YOUR_LINE_NOTIFY_TOKEN",
    "email_enabled": false,
    "email_settings": {
      "smtp_server": "",
      "smtp_port": 587,
      "username": "",
      "password": "",
      "from_address": "",
      "to_address": ""
    }
  },
  "auto_recovery_enabled": true,
  "max_recovery_attempts": 3,
  "performance_monitoring_enabled": true,
  "memory_limit_mb": 4096,
  "cpu_usage_limit_percent": 80
}
```

### ロジックセレクターの設定

`src/core/logic_selector/config/logic_selector_config.json`で以下の設定が可能です：

```json
{
  "min_win_rate_threshold": 0.8,  // 最小勝率閾値
  "logic_evaluation_period": "1d",  // ロジック評価期間
  "logic_rotation_enabled": true,  // ロジックローテーションを有効化
  "logic_rotation_frequency": "4h",  // ローテーション頻度
  "logic_locking_enabled": true,  // ロジックロックを有効化
  "logic_lock_duration": "24h",  // ロックの持続時間
  "max_lock_count_before_exclusion": 2,  // 除外までのロック回数
  "market_condition_adaptation_enabled": true,  // 市場状況への適応を有効化
  "preferred_logic_types": ["trend_following", "mean_reversion", "breakout"],
  "logic_weights": {
    "recent_performance": 0.6,
    "historical_performance": 0.3,
    "market_condition_match": 0.1
  }
}
```

### 回復システムの設定

`src/core/recovery_system/config/recovery_system_config.json`で以下の設定が可能です：

```json
{
  "error_detection_enabled": true,  // エラー検出を有効化
  "auto_recovery_enabled": true,  // 自動回復を有効化
  "checkpoint_frequency": "10m",  // チェックポイント作成頻度
  "max_recovery_attempts": 3,  // 最大回復試行回数
  "recovery_timeout": 300,  // 回復タイムアウト（秒）
  "critical_errors": [
    "browser_crash",
    "network_disconnect",
    "platform_error"
  ],
  "notification_on_recovery_attempt": true,  // 回復試行時の通知
  "notification_on_recovery_success": true,  // 回復成功時の通知
  "notification_on_recovery_failure": true,  // 回復失敗時の通知
  "log_detailed_recovery_process": true  // 詳細な回復プロセスのログ記録
}
```

## 日常運用手順

### 1. 起動前の確認

システムを起動する前に、以下の点を確認してください：

1. インターネット接続が安定していること
2. 各プラットフォームのメンテナンス情報を確認
3. システムのログファイルに異常がないこと
4. 十分なディスク容量があること

### 2. システム起動

以下の手順でシステムを起動します：

1. ターミナル/コマンドプロンプトを開く
2. MUGEN Systemのディレクトリに移動
3. 仮想環境を有効化
4. システムを起動

```bash
cd /path/to/MUGEN_System
source venv/bin/activate  # Windows: venv\Scripts\activate
python src/core/mugen_system.py
```

### 3. 運用中の監視

システム運用中は、以下の点を定期的に確認してください：

1. ログファイル（`logs/mugen_system.log`）の監視
2. LINE通知の確認
3. 取引状況の確認（`python src/core/mugen_system.py --status`）
4. システムリソース使用状況の確認

### 4. 定期メンテナンス

週に1回程度、以下のメンテナンス作業を行うことを推奨します：

1. ログファイルのアーカイブ/クリーンアップ
2. 不要なスクリーンショットの削除
3. システムアップデートの確認
4. AI学習モデルの再学習

```bash
# ログのアーカイブ
tar -czf logs/archive/logs_$(date +%Y%m%d).tar.gz logs/*.log
rm logs/*.log

# AI学習モデルの再学習
python src/ai_learning/main.py --mode train
```

### 5. システム停止

取引終了後、以下の手順でシステムを安全に停止します：

1. 実行中のターミナルで `Ctrl+C` を押す
2. または別のターミナルから以下のコマンドを実行：
   ```bash
   python src/core/mugen_system.py --stop
   ```
3. ログファイルを確認して正常に停止したことを確認

## 監視とアラート

### LINE通知

MUGEN Systemは、重要なイベントをLINE Notifyを通じて通知します。以下のイベントで通知が送信されます：

1. システム起動/停止
2. 5連敗発生
3. ロジックのロック/解除/除外
4. 日次取引上限/利益上限到達
5. エラー発生と回復試行
6. AI学習の開始/完了/エラー

### 通知設定

LINE通知を設定するには、以下の手順に従います：

1. [LINE Notify](https://notify-bot.line.me/ja/)にアクセスしてトークンを取得
2. `src/core/config/system_config.json`の`notification`セクションにトークンを設定：
   ```json
   "notification": {
     "line_enabled": true,
     "line_token": "YOUR_LINE_NOTIFY_TOKEN",
     ...
   }
   ```

### ログ監視

システムのログファイル（`logs/mugen_system.log`）には、詳細な動作記録が保存されます。ログレベルは以下の4段階です：

- **DEBUG**: 詳細なデバッグ情報
- **INFO**: 一般的な情報メッセージ
- **WARNING**: 警告（軽度の問題）
- **ERROR**: エラー（重大な問題）

ログレベルは`src/core/config/system_config.json`の`log_level`で設定できます。

## トラブルシューティング

### 一般的な問題と解決策

#### システムが起動しない

**症状**: `python src/core/mugen_system.py`を実行してもシステムが起動しない

**解決策**:
1. ログファイルを確認: `cat logs/mugen_system.log`
2. 依存パッケージを再インストール: `pip install -r requirements.txt`
3. 設定ファイルの構文を確認
4. 十分な権限があるか確認

#### ブラウザ自動化が機能しない

**症状**: ブラウザが起動しない、または操作が失敗する

**解決策**:
1. Webドライバーを更新: `python src/browser_automation/update_webdriver.py`
2. ブラウザのバージョンを確認
3. `src/browser_automation/config/browser_automation_config.json`の設定を確認
4. ヘッドレスモードを無効化して動作を確認

#### AI学習エラー

**症状**: AI学習モジュールがエラーで終了する

**解決策**:
1. TensorFlowとCUDAの互換性を確認
2. GPUメモリ使用量を確認
3. バッチサイズを小さくする: `src/ai_learning/config/ai_learning_config.json`の`batch_size`を減らす
4. データの整合性を確認

#### 5連敗で自動停止した場合

**症状**: システムが5連敗で自動停止し、LINE通知が送信される

**解決策**:
1. ロジックの状態を確認: `python src/core/logic_selector.py --status`
2. 市場状況を分析
3. 必要に応じてロジックを手動でリセット: `python src/core/logic_selector.py --reset-locks`
4. システムを再起動

### エラーコードと対処法

| エラーコード | 説明 | 対処法 |
|------------|------|------|
| E101 | ブラウザ起動エラー | Webドライバーを更新、ブラウザを再インストール |
| E102 | 要素検出タイムアウト | タイムアウト設定を増加、ページ構造の変更を確認 |
| E103 | ネットワークエラー | インターネット接続を確認、プロキシ設定を確認 |
| E201 | プラットフォームログインエラー | 認証情報を確認、CAPTCHAの有無を確認 |
| E202 | 取引実行エラー | プラットフォームの状態を確認、残高を確認 |
| E301 | AI予測エラー | モデルファイルの存在を確認、再学習を実行 |
| E401 | システム設定エラー | 設定ファイルの構文と内容を確認 |
| E501 | メモリ不足エラー | 不要なプロセスを終了、メモリ制限を確認 |

## よくある質問

### Q: システムはどのくらいの頻度で取引を行いますか？

A: デフォルト設定では、1日あたり最大100回の取引を行います。この上限は`src/trade_management/config/trade_rules_config.json`の`daily_trade_limit`で調整できます。

### Q: 複数のプラットフォームで同時に取引することはできますか？

A: はい、可能です。`src/core/config/system_config.json`の`active_platforms`に複数のプラットフォームを設定することで、同時に取引を行うことができます。

### Q: システムが自動的に停止した場合、どうすればよいですか？

A: 5連敗などの条件で自動停止した場合は、LINE通知を確認し、状況を分析してください。問題がなければ、`python src/core/mugen_system.py`コマンドでシステムを再起動できます。

### Q: AI学習はどのくらいの頻度で行うべきですか？

A: 市場環境の変化に応じて、週に1回程度の再学習を推奨します。デフォルトでは、日曜日の深夜2時に自動的に学習が実行されるよう設定されています。

### Q: システムのパフォーマンスを向上させるにはどうすればよいですか？

A: 以下の方法でパフォーマンスを向上させることができます：
1. より高性能なGPUを使用する
2. 不要なバックグラウンドプロセスを終了する
3. ヘッドレスモードを有効化する
4. 監視対象の通貨ペアと時間枠を最適化する

## 付録

### コマンドリファレンス

#### コアシステム

```bash
# システム起動
python src/core/mugen_system.py

# システム状態確認
python src/core/mugen_system.py --status

# システム停止
python src/core/mugen_system.py --stop

# テストモード起動
python src/core/mugen_system.py --test

# 設定リロード
python src/core/mugen_system.py --reload-config

# バージョン確認
python src/core/mugen_system.py --version
```

#### ロジックセレクター

```bash
# ロジック状態確認
python src/core/logic_selector.py --status

# ロジックロックのリセット
python src/core/logic_selector.py --reset-locks

# 特定ロジックの強制選択
python src/core/logic_selector.py --force-select LOGIC_ID

# 除外ロジックの確認
python src/core/logic_selector.py --list-excluded
```

#### AI学習モジュール

```bash
# 全データダウンロード
python src/ai_learning/main.py --mode download

# 全モデル学習
python src/ai_learning/main.py --mode train

# 特定モデル学習
python src/ai_learning/main.py --mode train --currency_pair USDJPY --timeframe 5m

# ハイパーパラメータ最適化
python src/ai_learning/main.py --mode optimize --currency_pair USDJPY --timeframe 5m

# 予測実行
python src/ai_learning/main.py --mode predict --currency_pair USDJPY --timeframe 5m

# 完全パイプライン実行
python src/ai_learning/main.py --mode full
```

### ディレクトリ構造

```
MUGEN_System/
├── data/                  # データ保存ディレクトリ
├── logs/                  # ログファイル
├── models/                # 学習済みモデル
├── screenshots/           # エラー時のスクリーンショット
├── src/                   # ソースコード
│   ├── ai_learning/       # AI学習モジュール
│   ├── browser_automation/ # ブラウザ自動化
│   ├── core/              # コアシステム
│   ├── detection_avoidance/ # 検知回避システム
│   ├── human_behavior/    # 人間行動シミュレーター
│   ├── tests/             # テストコード
│   └── trade_management/  # 取引管理
├── venv/                  # 仮想環境
├── INSTALLATION_MANUAL.md # インストール手順書
├── USER_MANUAL.md         # 取扱説明書
├── AI_LEARNING_MANUAL.md  # AI学習手順書
└── requirements.txt       # 依存パッケージリスト
```

### 設定ファイル一覧

| ファイルパス | 説明 |
|------------|------|
| src/core/config/system_config.json | システム全体の設定 |
| src/core/logic_selector/config/logic_selector_config.json | ロジック選択の設定 |
| src/core/recovery_system/config/recovery_system_config.json | 回復システムの設定 |
| src/core/fundamentals_monitor/config/fundamentals_monitor_config.json | ファンダメンタルズ監視の設定 |
| src/human_behavior/config/behavior_config.json | 人間行動シミュレーションの設定 |
| src/human_behavior/config/behavior_profiles.json | 行動プロファイルの定義 |
| src/detection_avoidance/config/detection_avoidance_config.json | 検知回避の設定 |
| src/browser_automation/config/browser_automation_config.json | ブラウザ自動化の基本設定 |
| src/browser_automation/config/the_option_config.json | The Optionプラットフォームの設定 |
| src/browser_automation/config/bi_winning_config.json | Bi-Winningプラットフォームの設定 |
| src/browser_automation/config/bubinga_config.json | Bubingaプラットフォームの設定 |
| src/trade_management/config/trade_rules_config.json | 取引ルールの設定 |
| src/ai_learning/config/ai_learning_config.json | AI学習の設定 |
| src/ai_learning/config/ai_learning_integration_config.json | AI学習統合の設定 |

---

この取扱説明書に関するご質問や問題がある場合は、サポートまでお問い合わせください。
