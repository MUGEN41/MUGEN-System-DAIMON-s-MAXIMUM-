# MUGEN System（DAIMON's MAXIMUM）ファイル一覧

## ディレクトリ構造

```
delivery_package/
├── README.md                     # パッケージ概要と使用方法
├── docs/                         # ドキュメント
│   ├── INSTALLATION_MANUAL.md    # インストール手順書
│   ├── USER_MANUAL.md            # 取扱説明書
│   └── AI_LEARNING_MANUAL.md     # AI学習手順書
├── src/                          # ソースコード
│   ├── ai_learning/              # AI学習モジュール
│   │   ├── ai_learning_system.py # AI学習システム本体
│   │   ├── init.py               # 初期化スクリプト
│   │   ├── integration.py        # 統合スクリプト
│   │   └── main.py               # コマンドラインインターフェース
│   ├── browser_automation/       # ブラウザ自動化モジュール
│   │   ├── browser_automation.py # ブラウザ自動化基本機能
│   │   ├── bubinga_automation.py # Bubingaプラットフォーム対応
│   │   └── bubinga_error_handler.py # エラーハンドリング
│   ├── core/                     # コアシステム
│   │   ├── mugen_system.py       # メインシステム
│   │   ├── logic_selector.py     # ロジック選択機能
│   │   ├── recovery_system.py    # 自動回復システム
│   │   └── fundamentals_monitor.py # ファンダメンタルズ監視
│   ├── detection_avoidance/      # 検知回避システム
│   │   └── detection_avoidance_system.py # 検知回避機能
│   ├── human_behavior/           # 人間行動シミュレーション
│   │   └── human_behavior_simulator.py # 行動シミュレータ
│   ├── trade_management/         # トレード管理
│   │   └── daily_trade_manager.py # 日次取引管理
│   └── utils/                    # ユーティリティ
│       └── human_behavior_simulator.py # 行動シミュレータユーティリティ
├── config/                       # 設定ファイル
│   ├── ai_learning_config.json   # AI学習設定
│   ├── ai_learning_integration_config.json # AI学習統合設定
│   ├── behavior_config.json      # 行動設定
│   ├── behavior_profiles.json    # 行動プロファイル
│   ├── browser_automation_config.json # ブラウザ自動化設定
│   ├── bubinga_config.json       # Bubinga設定
│   ├── detection_avoidance_config.json # 検知回避設定
│   ├── fundamentals_monitor_config.json # ファンダメンタルズ監視設定
│   ├── logic_selector_config.json # ロジック選択設定
│   ├── recovery_system_config.json # 回復システム設定
│   ├── system_config.json        # システム全体設定
│   └── trade_rules_config.json   # 取引ルール設定
└── sample_data/                  # サンプルデータ
    ├── USDJPY_5m_sample.csv      # USDJPYの5分足サンプルデータ
    └── fundamentals_sample.json  # ファンダメンタルズサンプルデータ
```

## 主要ファイル説明

### ドキュメント

- **INSTALLATION_MANUAL.md**: システムのインストール方法、環境構築手順、初期設定方法を解説
- **USER_MANUAL.md**: システムの使用方法、各機能の説明、設定パラメータの調整方法を解説
- **AI_LEARNING_MANUAL.md**: AI学習機能の使用方法、データ収集から学習、評価までの手順を解説

### ソースコード

#### AI学習モジュール
- **ai_learning_system.py**: AI学習の中核機能を実装
- **init.py**: AI学習環境の初期化を行うスクリプト
- **integration.py**: コアシステムとの統合機能を実装
- **main.py**: コマンドラインからAI学習機能を操作するインターフェース

#### ブラウザ自動化モジュール
- **browser_automation.py**: ブラウザ自動操作の基本機能を実装
- **bubinga_automation.py**: Bubingaプラットフォーム専用の自動化機能
- **bubinga_error_handler.py**: Bubinga操作時のエラー処理機能

#### コアシステム
- **mugen_system.py**: システム全体を統括するメインモジュール
- **logic_selector.py**: 複数のトレードロジックから最適なものを選択する機能
- **recovery_system.py**: エラー発生時の自動回復機能
- **fundamentals_monitor.py**: 経済指標などのファンダメンタルズを監視する機能

#### 検知回避システム
- **detection_avoidance_system.py**: 取引パターン検知を回避するための機能を実装

#### 人間行動シミュレーション
- **human_behavior_simulator.py**: 人間らしい操作パターンをシミュレートする機能

#### トレード管理
- **daily_trade_manager.py**: 日次の取引回数や利益管理を行う機能

### 設定ファイル

- **ai_learning_config.json**: AI学習の基本設定
- **behavior_config.json**: 人間行動シミュレーションの基本設定
- **behavior_profiles.json**: 複数の行動プロファイル（慎重型、積極型など）の設定
- **browser_automation_config.json**: ブラウザ自動化の基本設定
- **bubinga_config.json**: Bubingaプラットフォーム固有の設定
- **detection_avoidance_config.json**: 検知回避機能の設定
- **system_config.json**: システム全体の設定
- **trade_rules_config.json**: 取引ルールの設定

### サンプルデータ

- **USDJPY_5m_sample.csv**: USDJPYの5分足チャートデータのサンプル
- **fundamentals_sample.json**: 経済指標などのファンダメンタルズデータのサンプル
